<?php

/**
 * For compatibility with extensions...
 * Will still die on PHP 5.3, of course. :P
 */
class Namespace extends MWNamespace {
	// ..
}

<?php
/** Lower Sorbian (Dolnoserbski)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Dunak
 * @author Dundak
 * @author Michawiki
 * @author Murjarik
 * @author Nepl1
 * @author Pe7er
 * @author Qualia
 * @author Tlustulimu
 * @author Tlustulimu Nepl1
 */

$fallback = 'de';


$namespaceNames = array(
	NS_MEDIA            => 'Medija',
	NS_SPECIAL          => 'Specialne',
	NS_TALK             => 'Diskusija',
	NS_USER             => 'Wužywaŕ',
	NS_USER_TALK        => 'Diskusija_wužywarja',
	NS_PROJECT_TALK     => '$1 diskusija',
	NS_FILE             => 'Dataja',
	NS_FILE_TALK        => 'Diskusija wó dataji',
	NS_MEDIAWIKI        => 'MediaWiki',
	NS_MEDIAWIKI_TALK   => 'MediaWiki_diskusija',
	NS_TEMPLATE         => 'Pśedłoga',
	NS_TEMPLATE_TALK    => 'Diskusija_wó_pśedłoze',
	NS_HELP             => 'Pomoc',
	NS_HELP_TALK        => 'Diskusija_wó_pomocy',
	NS_CATEGORY         => 'Kategorija',
	NS_CATEGORY_TALK    => 'Diskusija_wó_kategoriji',
);

$namespaceAliases = array(
	'Wobraz' => NS_FILE,
	'Diskusija_wó_wobrazu' => NS_FILE_TALK,
);

$datePreferences = array(
	'default',
	'dmy',
	'ISO 8601',
);

$defaultDateFormat = 'dmy';

$dateFormats = array(
	'dmy time' => 'H:i',
	'dmy date' => 'j xg Y',
	'dmy both' => 'H:i, j xg Y',
);

$specialPageAliases = array(
	'DoubleRedirects'           => array( 'Dwójne dalejpósrědnjenja' ),
	'BrokenRedirects'           => array( 'Njefunkcioněrujuce dalejpósrědnjenja' ),
	'Disambiguations'           => array( 'Wótkaze ku rozjasnjenju wopśimjeśa' ),
	'Userlogin'                 => array( 'Pśizjawiś se' ),
	'Userlogout'                => array( 'Wótzjawiś se' ),
	'CreateAccount'             => array( 'Wužywarske konto załožyś' ),
	'Preferences'               => array( 'Nastajenja' ),
	'Watchlist'                 => array( 'Wobglědowańka' ),
	'Recentchanges'             => array( 'Slědne změny' ),
	'Upload'                    => array( 'Uploadowaś' ),
	'Listfiles'                 => array( 'Lisćina datajow' ),
	'Newimages'                 => array( 'Nowe dataje' ),
	'Listusers'                 => array( 'Wužywarje' ),
	'Listgrouprights'           => array( 'Kupkowe pšawa' ),
	'Statistics'                => array( 'Statistika' ),
	'Randompage'                => array( 'Pśipadny bok' ),
	'Lonelypages'               => array( 'Wósyrośone boki' ),
	'Uncategorizedpages'        => array( 'Njekategorizěrowane boki' ),
	'Uncategorizedcategories'   => array( 'Njekategorizěrowane kategorije' ),
	'Uncategorizedimages'       => array( 'Njekategorizěrowane dataje' ),
	'Uncategorizedtemplates'    => array( 'Njekategorizěrowane pśedłogi' ),
	'Unusedcategories'          => array( 'Njewužywane kategorije' ),
	'Unusedimages'              => array( 'Njewužywane dataje' ),
	'Wantedpages'               => array( 'Póžedane boki' ),
	'Wantedcategories'          => array( 'Póžedane kategorije' ),
	'Mostlinked'                => array( 'Boki na kótarež wjeźo nejwěcej wótkazow' ),
	'Mostlinkedcategories'      => array( 'Nejwěcej wužywane kategorije' ),
	'Mostlinkedtemplates'       => array( 'Nejwěcej wužywane pśedłogi' ),
	'Mostcategories'            => array( 'Boki z nejwěcej kategorijami' ),
	'Mostimages'                => array( 'Nejwěcej wužywane dataje' ),
	'Mostrevisions'             => array( 'Nejwěcej wobźěłane boki' ),
	'Fewestrevisions'           => array( 'Nejmjenjej wobźěłane boki' ),
	'Shortpages'                => array( 'Nejkrotše boki' ),
	'Longpages'                 => array( 'Nejdlěše boki' ),
	'Newpages'                  => array( 'Nowe boki' ),
	'Ancientpages'              => array( 'Nejstarše boki' ),
	'Deadendpages'              => array( 'Boki kenž su slěpe gasy' ),
	'Protectedpages'            => array( 'Šćitane boki' ),
	'Protectedtitles'           => array( 'Šćitane title' ),
	'Allpages'                  => array( 'Wšykne boki' ),
	'Prefixindex'               => array( 'Indeks prefiksow' ),
	'Ipblocklist'               => array( 'Blokěrowane IPje' ),
	'Specialpages'              => array( 'Specialne boki' ),
	'Contributions'             => array( 'Pśinoski' ),
	'Emailuser'                 => array( 'E-mail' ),
	'Confirmemail'              => array( 'E-mail wobkšuśiś' ),
	'Whatlinkshere'             => array( 'Lisćina wótkazow' ),
	'Recentchangeslinked'       => array( 'Změny na zalinkowanych bokach' ),
	'Movepage'                  => array( 'Pśesunuś' ),
	'Blockme'                   => array( 'Proksy-blokěrowanje' ),
	'Booksources'               => array( 'Pytaś pó ISBN' ),
	'Categories'                => array( 'Kategorije' ),
	'Export'                    => array( 'Eksportěrowaś' ),
	'Version'                   => array( 'Wersija' ),
	'Allmessages'               => array( 'Systemowe powěsći' ),
	'Log'                       => array( 'Protokole' ),
	'Blockip'                   => array( 'Blokěrowaś' ),
	'Undelete'                  => array( 'Nawrośiś' ),
	'Import'                    => array( 'Importěrowaś' ),
	'Lockdb'                    => array( 'Datowu banku blokěrowaś' ),
	'Unlockdb'                  => array( 'Datowu banku zasej spśistupniś' ),
	'Userrights'                => array( 'Pšawa wužywarjow' ),
	'MIMEsearch'                => array( 'Pytaś pó MIME-typje' ),
	'FileDuplicateSearch'       => array( 'Pytanje datajowych duplikatow' ),
	'Unwatchedpages'            => array( 'Boki kenž njejsu we wobglědowańkach' ),
	'Listredirects'             => array( 'Pśesměrowanja' ),
	'Revisiondelete'            => array( 'Wulašowanje wersijow' ),
	'Unusedtemplates'           => array( 'Njewužywane pśedłogi' ),
	'Randomredirect'            => array( 'Pśipadne pśesměrowanje' ),
	'Mypage'                    => array( 'Mój bok' ),
	'Mytalk'                    => array( 'Mója diskusija' ),
	'Mycontributions'           => array( 'Móje pśinoski' ),
	'Listadmins'                => array( 'Administratory' ),
	'Listbots'                  => array( 'Boty' ),
	'Popularpages'              => array( 'Woblubowane boki' ),
	'Search'                    => array( 'Pytaś' ),
	'Resetpass'                 => array( 'Šćitne gronidło slědk stajiś' ),
	'Withoutinterwiki'          => array( 'Interwikije feluju' ),
	'MergeHistory'              => array( 'Stawizny wersijow zjadnośiś' ),
	'Filepath'                  => array( 'Datajowa sćažka' ),
	'Invalidateemail'           => array( 'E-mail njewobkšuśis' ),
	'Blankpage'                 => array( 'Prozny bok' ),
);

$messages = array(
# User preference toggles
'tog-underline'               => 'Wótkaze pódšmarnuś:',
'tog-highlightbroken'         => 'Wótkaze na njeeksistěrujuce boki formatěrowaś',
'tog-justify'                 => 'Tekst do bloka zrownaś',
'tog-hideminor'               => 'Małe změny schowaś',
'tog-extendwatchlist'         => 'Lisćinu wobglědowańkow wócyniś, aby wšě změny pokazał, nic jano nejnowše',
'tog-usenewrc'                => 'Rozšyrjonu lisćinu aktualnych změnow (JavaScript trěbny) wužywaś',
'tog-numberheadings'          => 'Nadpisma awtomatiski numerěrowaś',
'tog-showtoolbar'             => 'Wobźěłańsku lejstwu pokazaś (JavaScript)',
'tog-editondblclick'          => 'Boki z dwójnym kliknjenim wobźěłaś (JavaScript)',
'tog-editsection'             => 'Wobźěłanje wótstawkow pśez wótkaze [wobźěłaś] zmóžniś',
'tog-editsectiononrightclick' => 'Wobźěłanje wótstawkow pśez kliknjenje z pšaweju tastu myški zmóžniś (JavaScript)',
'tog-showtoc'                 => 'Wopśimjeśe pokazaś, jolic ma bok wěcej nježli 3 nadpisma',
'tog-rememberpassword'        => 'Se stawnje na toś tom computerje pśizjawiś',
'tog-editwidth'               => 'Wobźěłowańske pólo póšyriś, aby se ceła wobrazowka połniła',
'tog-watchcreations'          => 'Boki, kótarež załožyjom, awtomatiski wobglědowaś',
'tog-watchdefault'            => 'Boki, kótarež změnijom, awtomatiski wobglědowaś',
'tog-watchmoves'              => 'Boki, kótarež som pśesunuł, awtomatiski wobglědowaś',
'tog-watchdeletion'           => 'Boki, kótarež som wulašował, awtomatiski wobglědowaś',
'tog-minordefault'            => 'Wšykne móje změny ako małe markěrowaś',
'tog-previewontop'            => 'Zespominanje wušej wobźěłowańskego póla pokazaś',
'tog-previewonfirst'          => 'Pśi prědnem wobźěłanju pśecej zespominanje pokazaś',
'tog-nocache'                 => 'Cache bokow znjemóžniś',
'tog-enotifwatchlistpages'    => 'E-mail pósłaś, jolic se wobglědowany bok změnja',
'tog-enotifusertalkpages'     => 'E-mail pósłaś, změnijo-lic se mój diskusijny bok',
'tog-enotifminoredits'        => 'E-mail teke małych změnow dla pósłaś',
'tog-enotifrevealaddr'        => 'Móju e-mailowu adresu w e-mailowych pówěźeńkach pokazaś',
'tog-shownumberswatching'     => 'Licbu wobglědujucych wužywarjow pokazaś',
'tog-fancysig'                => 'Ze signaturu kaž z wikitekstom wobchadaś (bźez awtomatiskego wótkaza)',
'tog-externaleditor'          => 'Eksterny editor ako standard wužywaś (jano za ekspertow, pomina sebje specialne nastajenja na wašom licadle)',
'tog-externaldiff'            => 'Eksterny diff-program ako standard wužywaś (jano za ekspertow, pominma sebje specialne nastajenja na wašom licadle)',
'tog-showjumplinks'           => 'Wótkaze typa „źi do” zmóžniś',
'tog-uselivepreview'          => 'Live-pśeglěd wužywaś (JavaScript) (eksperimentelnje)',
'tog-forceeditsummary'        => 'Warnowaś, gaž pśi składowanju zespominanje felujo',
'tog-watchlisthideown'        => 'Móje změny na wobglědowańskej lisćinje schowaś',
'tog-watchlisthidebots'       => 'Změny awtomatiskich programow (botow) na wobglědowańskej lisćinje schowaś',
'tog-watchlisthideminor'      => 'Małe změny na wobglědowańskej lisćinje schowaś',
'tog-watchlisthideliu'        => 'Změny pśizjawjonych wužywarjow z wobglědowańki schowaś',
'tog-watchlisthideanons'      => 'Změny anonymnych wužywarjow z wobglědowańki schowaś',
'tog-nolangconversion'        => 'Konwertěrowanje rěcnych wariantow znjemóžniś',
'tog-ccmeonemails'            => 'Kopije e-mailow dostaś, kótarež drugim wužywarjam pósćelom',
'tog-diffonly'                => 'Pśi pśirownowanju wersijow jano rozdźěle pokazaś',
'tog-showhiddencats'          => 'Schowane kategorije pokazaś',
'tog-norollbackdiff'          => 'Rozdźěl pó slědkstajenju zanjechaś',

'underline-always'  => 'pśecej',
'underline-never'   => 'žednje',
'underline-default' => 'pó standarźe browsera',

# Dates
'sunday'        => 'Njeźela',
'monday'        => 'Pónjeźele',
'tuesday'       => 'Wałtora',
'wednesday'     => 'Srjoda',
'thursday'      => 'Stwórtk',
'friday'        => 'Pětk',
'saturday'      => 'Sobota',
'sun'           => 'Nje',
'mon'           => 'Pón',
'tue'           => 'Wał',
'wed'           => 'Srj',
'thu'           => 'Stw',
'fri'           => 'Pět',
'sat'           => 'Sob',
'january'       => 'januar',
'february'      => 'februar',
'march'         => 'měrc',
'april'         => 'apryl',
'may_long'      => 'maj',
'june'          => 'junij',
'july'          => ' julij',
'august'        => 'awgust',
'september'     => 'september',
'october'       => 'oktober',
'november'      => 'nowember',
'december'      => 'december',
'january-gen'   => 'januara',
'february-gen'  => 'februara',
'march-gen'     => 'měrca',
'april-gen'     => 'apryla',
'may-gen'       => 'maja',
'june-gen'      => 'junija',
'july-gen'      => 'julija',
'august-gen'    => 'awgusta',
'september-gen' => 'septembra',
'october-gen'   => 'oktobra',
'november-gen'  => 'nowembra',
'december-gen'  => 'decembra',
'jan'           => 'jan',
'feb'           => 'feb',
'mar'           => 'měr',
'apr'           => 'apr',
'may'           => 'maja',
'jun'           => 'jun',
'jul'           => 'jul',
'aug'           => 'awg',
'sep'           => 'sep',
'oct'           => 'okt',
'nov'           => 'now',
'dec'           => 'dec',

# Categories related messages
'pagecategories'                 => '{{PLURAL:$1|Kategorija|Kategoriji|Kategorije}}',
'category_header'                => 'Nastawki w kategoriji „$1“',
'subcategories'                  => 'Pódkategorije',
'category-media-header'          => 'Dataje w kategoriji „$1“',
'category-empty'                 => "''W toś tej kategoriji njejsu něnto žedne nastawki abo medije.''",
'hidden-categories'              => '{{PLURAL:$1|Schowana kategorija|Schowanej kategoriji|Schowane kategorije|Schowanych kategorijow}}',
'hidden-category-category'       => 'Schowane kategorije', # Name of the category where hidden categories will be listed
'category-subcat-count'          => '{{PLURAL:$2|Toś ta kategorija ma jano slědujucu pódkategoriju.|Toś ta kategorija ma {{PLURAL:$1|slědujucu pódkategoriju|slědujucej $1 pódkategoriji|slědujuce $1 kategorije|slědujucych $1 pódkategorijow}} z dogromady $2.}}',
'category-subcat-count-limited'  => 'Toś ta kategorija ma {{PLURAL:$1|slědujucu pódkategoriju|slědujucej $1 pódkategoriji|slědujuce $1 pódkategorije|slědujucych $1 pódkategorijow}}.',
'category-article-count'         => '{{PLURAL:$2|Toś ta kategorija wopśimujo jano slědujucy bok.|{{PLURAL:$1|Slědujucy bok jo|Slědujucej $1 boka stej|Slědujuce $1 boki su|Slědujucych $1 bokow jo}} w toś tej kategoriji, z dogromady $2.}}',
'category-article-count-limited' => '{{PLURAL:$1|Slědujucy bok jo|Slědujucej $1 boka stej|Slědujuce $1 boki su|Slědujucych $1 bokow jo}} w toś tej kategoriji:',
'category-file-count'            => '{{PLURAL:$2|Toś ta kategorija wopśimujo jano slědujucu dataju:|{{PLURAL:$1|Slědujuca dataja jo|Slědujucej $1 dataji stej|Slědujuce $1 dataje su|Slědujucych $1 datajow jo}} w toś tej kategoriji, z dogromady $2.}}',
'category-file-count-limited'    => '{{PLURAL:$1|Slědujuca dataja jo|Slědujucej $1 dataji stej|Slědujuce $1 dataje su|Slědujucych $1 datajow jo}} w toś tej kategoriji {{PLURAL:$1|wopśimjona|wopśimjonej|wopśimjone|wopsímjone}}:',
'listingcontinuesabbrev'         => 'dalej',

'mainpagetext'      => "<big>'''MediaWiki jo se wuspěšnje instalěrowało.'''</big>",
'mainpagedocfooter' => "Pomoc pśi wužywanju softwary wiki namakajoš pód [http://meta.wikimedia.org/wiki/Help:Contents User's Guide].

== Na zachopjenje ==

* [http://www.mediawiki.org/wiki/Manual:Configuration_settings Konfiguracija lisćiny połoženjow]
* [http://www.mediawiki.org/wiki/Manual:FAQ MediaWiki FAQ (pšašanja a wótegrona)]
* [https://lists.wikimedia.org/mailman/listinfo/mediawiki-announce Lisćina e-mailowych nakładow MediaWiki]",

'about'          => 'Wó',
'article'        => 'Nastawk',
'newwindow'      => '(se wótcynijo w nowem woknje)',
'cancel'         => 'Pśetergnuś',
'qbfind'         => 'Namakaś',
'qbbrowse'       => 'Pśeběraś',
'qbedit'         => 'Pśeměniś',
'qbpageoptions'  => 'Toś ten bok',
'qbpageinfo'     => 'Kontekst',
'qbmyoptions'    => 'Móje boki',
'qbspecialpages' => 'Specialne boki',
'moredotdotdot'  => 'Wěcej…',
'mypage'         => 'Mój bok',
'mytalk'         => 'mója diskusija',
'anontalk'       => 'Diskusija z toś teju IP',
'navigation'     => 'Nawigacija',
'and'            => '&#32;a',

# Metadata in edit box
'metadata_help' => 'Metadaty:',

'errorpagetitle'    => 'Zmólka',
'returnto'          => 'Slědk k boku $1.',
'tagline'           => 'Z {{GRAMMAR:genitiw|{{SITENAME}}}}',
'help'              => 'Pomoc',
'search'            => 'Pytaś',
'searchbutton'      => 'Pytaś',
'go'                => 'Nastawk',
'searcharticle'     => 'Nastawk',
'history'           => 'wersije',
'history_short'     => 'Wersije a awtory',
'updatedmarker'     => 'Změny wót mójogo slědnego woglěda',
'info_short'        => 'Informacija',
'printableversion'  => 'Wersija za śišć',
'permalink'         => 'Wobstawny wótkaz',
'print'             => 'Śišćaś',
'edit'              => 'wobźěłaś',
'create'            => 'Wuźěłaś',
'editthispage'      => 'Bok wobźěłaś',
'create-this-page'  => 'Bok wuźěłaś',
'delete'            => 'Wulašowaś',
'deletethispage'    => 'Toś ten bok wulašowaś',
'undelete_short'    => '{{PLURAL:$1|1 wersiju|$1 wersiji|$1 wersije}} nawrośiś.',
'protect'           => 'Šćitaś',
'protect_change'    => 'změniś',
'protectthispage'   => 'Bok šćitaś',
'unprotect'         => 'Šćitanje wótpóraś',
'unprotectthispage' => 'Šćitanje wótpóraś',
'newpage'           => 'Nowy bok',
'talkpage'          => 'Diskusija',
'talkpagelinktext'  => 'diskusija',
'specialpage'       => 'Specialny bok',
'personaltools'     => 'Wósobinske pomocne srědki',
'postcomment'       => 'Nowy wótrězk',
'articlepage'       => 'Nastawk',
'talk'              => 'Diskusija',
'views'             => 'Naglědy',
'toolbox'           => 'Pomocne srědki',
'userpage'          => 'Wužywarski bok pokazaś',
'projectpage'       => 'Projektowy bok pokazaś',
'imagepage'         => 'Datajowy bok se woglědaś',
'mediawikipage'     => 'Nastawk pokazaś',
'templatepage'      => 'Pśedłogu pokazaś',
'viewhelppage'      => 'Pomocny bok pokazaś',
'categorypage'      => 'Kategoriju pokazaś',
'viewtalkpage'      => 'Diskusija',
'otherlanguages'    => 'W drugich rěcach',
'redirectedfrom'    => '(pósrědnjone z boka „$1”)',
'redirectpagesub'   => 'Dalejpósrědnjenje',
'lastmodifiedat'    => 'Slědna změna boka: $1 w $2 goź.', # $1 date, $2 time
'viewcount'         => 'Toś ten bok jo był woglědany {{PLURAL:$1|jaden raz|$1 raza|$1 raze}}.',
'protectedpage'     => 'Śćitany bok',
'jumpto'            => 'Źi na bok:',
'jumptonavigation'  => 'Nawigacija',
'jumptosearch'      => 'Pytaś',

# All link text and link target definitions of links into project namespace that get used by other message strings, with the exception of user group pages (see grouppage) and the disambiguation template definition (see disambiguations).
'aboutsite'            => 'Wó {{GRAMMAR:lokatiw|{{SITENAME}}}}',
'aboutpage'            => 'Project:Wó_{{GRAMMAR:lokatiw|{{SITENAME}}}}',
'copyright'            => 'Wopśimjeśe stoj pód $1.',
'copyrightpagename'    => '{{SITENAME}} stwóriśelske pšawo',
'copyrightpage'        => '{{ns:project}}:Stwóriśelske pšawo',
'currentevents'        => 'Aktualne tšojenja',
'currentevents-url'    => 'Project:Aktualne tšojenja',
'disclaimers'          => 'Impresum',
'disclaimerpage'       => 'Project:impresum',
'edithelp'             => 'Pomoc pśi wobźěłanju',
'edithelppage'         => 'Help:Pomoc pśi wobźěłanju',
'faq'                  => 'FAQ (pšašanja a wótegrona)',
'faqpage'              => 'Project:FAQ (pšašanja a wótegrona)',
'helppage'             => 'Help:Pomoc',
'mainpage'             => 'Głowny bok',
'mainpage-description' => 'Głowny bok',
'policy-url'           => 'Project:Směrnice',
'portal'               => 'Portal {{GRAMMAR:genitiw|{{SITENAME}}}}',
'portal-url'           => 'Project:portal',
'privacy'              => 'Šćit datow',
'privacypage'          => 'Project:Šćit datow',

'badaccess'        => 'Njamaš trěbnu dowólnosć.',
'badaccess-group0' => 'Njamaš trěbnu dowólnosć za toś tu akciju.',
'badaccess-groups' => 'Akcija, kótaruž sy póžedał, wogranicujo se na wužywarjow w {{PLURAL:$2|kupce|jadnej z kupkow}}: $1.',

'versionrequired'     => 'Wersija $1 softwary MediaWiki trěbna',
'versionrequiredtext' => 'Wersija $1 softwary MediaWiki jo trěbna, aby toś ten bok se mógał wužywaś. Glědaj [[Special:Version|Wersijowy bok]]',

'ok'                      => 'Pytaś',
'retrievedfrom'           => 'Z {{GRAMMAR:genitiw|$1}}',
'youhavenewmessages'      => 'Maš $1 ($2).',
'newmessageslink'         => 'nowe powěsći',
'newmessagesdifflink'     => 'slědna změna',
'youhavenewmessagesmulti' => 'Maš nowe powěsći: $1',
'editsection'             => 'wobźěłaś',
'editold'                 => 'wobźěłaś',
'viewsourceold'           => 'glědaś žrědło',
'editlink'                => 'wobźěłaś',
'viewsourcelink'          => 'Žrědło zwobrazniś',
'editsectionhint'         => 'Wótrězk wobźěłaś: $1',
'toc'                     => 'Wopśimjeśe',
'showtoc'                 => 'pokazaś',
'hidetoc'                 => 'schowaś',
'thisisdeleted'           => '$1 woglědaś abo wobnowiś?',
'viewdeleted'             => '$1 pokazaś?',
'restorelink'             => '{{PLURAL:$1|1 wulašowana wersija|$1 wulašowanej wersiji|$1 wulašowane wersije}}',
'feedlinks'               => 'Nowosći:',
'feed-invalid'            => 'Njepłaśecy typ abonementa.',
'feed-unavailable'        => 'Syndikaciske kanale k dispoziciji njestoje',
'site-rss-feed'           => '$1 RSS Feed',
'site-atom-feed'          => '$1 Atom Feed',
'page-rss-feed'           => '"$1" RSS Feed',
'page-atom-feed'          => '"$1" Atom Feed',
'red-link-title'          => '$1 (bok njeeksistěrujo)',

# Short words for each namespace, by default used in the namespace tab in monobook
'nstab-main'      => 'Nastawk',
'nstab-user'      => 'Wužywarski bok',
'nstab-media'     => 'Medije',
'nstab-special'   => 'Specialny bok',
'nstab-project'   => 'Projektowy bok',
'nstab-image'     => 'Dataja',
'nstab-mediawiki' => 'Powěźeńka',
'nstab-template'  => 'Pśedłoga',
'nstab-help'      => 'Pomoc',
'nstab-category'  => 'Kategorija',

# Main script and global functions
'nosuchaction'      => 'Toś tu akciju njedajo',
'nosuchactiontext'  => 'Akcija, kótaruž URL pódawa, jo njepłaśiwa.
Sy se snaź zapisał pśi zapódaśu URL abo sy slědował wopacnemu wótkazoju.
To by mógło teke programěrowańska zmólka w {{GRAMMAR:lokatiw|{{SITENAME}}}} byś.',
'nosuchspecialpage' => 'Toś ten specialny bok njeeksistěrujo',
'nospecialpagetext' => "<big>'''Toś ten specialny bok w toś tom wikiju njeeksistěrujo'''</big>

Lisćina płaśecych specialnych bokow namakajo se pód [[Special:SpecialPages|{{int:specialpages}}]].",

# General errors
'error'                => 'Zmólka',
'databaseerror'        => 'Zmólka w datowej bance',
'dberrortext'          => 'Syntaktiska zmólka pśi wótpšašowanju datoweje banki.
Slědne wótpšašowanje jo było: <blockquote><tt>$1</tt></blockquote> z funkcije „<tt>$2</tt>“.
MySQL jo zmólku „<tt>$3: $4</tt>“ wrośił.',
'dberrortextcl'        => 'Syntaktiska zmólka pśi wótpšašowanju datoweje banki.
Slědne wótpšašowanje jo było: <blockquote><tt>$1</tt></blockquote> z funkcije „<tt>$2</tt>“.
MySQL jo zmólku „<tt>$3: $4</tt>“ wrośił.',
'noconnect'            => 'Wódaj! Wiki ma někotare techniske śěže a njamóžo žeden zwisk ze serwerom datoweje banki nawězaś.<br />
$1',
'nodb'                 => 'Njejo móžno było, datowu banku $1 wuzwóliś.',
'cachederror'          => 'Slědujuce jo kopija z pufrowaka. Jo toś móžno, až wopśimjeśe jo zestarjone.',
'laggedslavemode'      => 'Glědaj: Jo móžno, až pokazany bok nejaktualnjejše změny njewopśimjejo.',
'readonly'             => 'Datowa banka jo zacynjona',
'enterlockreason'      => 'Pšosym zapódaj pśicynu za zacynjenje datoweje banki a informaciju, ga buźo zasej pśistupna',
'readonlytext'         => 'Datowa banka jo wochylu za nowe zapiski a druge změny zacynjona, nejskerjej dla wótwardowańskich źěłow. Pšosym wopytaj pózdźej hyšći raz.

Administrator, kenž jo ju zacynił, jo pódał toś tu pśicynu: $1',
'missing-article'      => 'Datowa banka njejo namakała tekst boka z mjenim "$1" $2, kótaryž dej se namakaś.

To se zwětšego zawinujo pśez njepłaśiwe wótchylenje abo wótkaz w stawiznach k bokoju, kótaryž jo se južo wulašował.

Jolic to njepśitrjefijo, sy snaź namakał programowu zmólku w softwarje.
Pšosym daj to a pśisłušny URL [[Special:ListUsers/sysop|administratoroju]] k wěsći.',
'missingarticle-rev'   => '(wersija: $1)',
'missingarticle-diff'  => '(rozdźěl: $1, $2)',
'readonly_lag'         => 'Datowa banka jo awtomatiski se zacyniła, aby wótwisne serwery se mógli z głownym serwerom wurownowaś.',
'internalerror'        => 'Interna zmólka',
'internalerror_info'   => 'Interna zmólka: $1',
'filecopyerror'        => 'Njejo było móžno dataju „$1” k „$2” kopěrowaś.',
'filerenameerror'      => 'Njejo było móžno dataju „$1” do „$2” pśemjenjowaś.',
'filedeleteerror'      => 'Njejo było móžno dataju „$1” wulašowaś.',
'directorycreateerror' => 'Njejo było móžno, zapis „$1“ wutwóriś.',
'filenotfound'         => 'Njejo było móžno dataju „$1” namakaś.',
'fileexistserror'      => 'Njejo było móžno do dataje "$1" pisaś: Wóna južo eksistěrujo.',
'unexpected'           => 'Njewócakowana gódnota: „$1“=„$2“.',
'formerror'            => 'Zmólka: Njejo móžno formular wótpósłaś.',
'badarticleerror'      => 'Akcija njedajo se na toś tom boku wuwjasć.',
'cannotdelete'         => 'Njejo móžno wuzwólony bok abo dataju wulašowaś. Snaź jo to južo něchten drugi cynił.',
'badtitle'             => 'Njepłaśecy nadpis',
'badtitletext'         => 'Nadpis pominanego boka jo był njepłaśecy, prozny abo njekorektny nadpis, póchadajucy z mjazyrěcnego abo interwikijowego wótkaza. Snaź wopśimjejo jadno abo wěcej znamuškow, kótarež njejsu w nadpisach dowólone.',
'perfcached'           => 'Toś te daty póchadaju z pufrowaka a mógu toś njeaktualne byś.',
'perfcachedts'         => 'Toś te daty póchadaju z pufrowaka, slědna aktualizacija: $1',
'querypage-no-updates' => 'Aktualizěrowanje toś togo boka jo se znjemóžniło. Daty how se nejžpjerwjej raz njeaktualizěruju.',
'wrong_wfQuery_params' => 'Njedobre parametery za wfQuery()<br />
Funkcija: $1<br />
Wótpšašanje: $2',
'viewsource'           => 'Žrědłowy tekst wobglědaś',
'viewsourcefor'        => 'za $1',
'actionthrottled'      => 'Akcije limitowane',
'actionthrottledtext'  => 'Ako napšawa pśeśiwo spamoju, móžoš toś tu akciju jano někotare raze we wěstym case wuwjasć. Sy toś ten limit dośěgnuł. Pšosym wopytaj za někotare minuty hyšći raz.',
'protectedpagetext'    => 'Wobźěłanje toś togo boka jo se znjemóžniło.',
'viewsourcetext'       => 'Žrědłowy tekst togo boka móžoš se woglědaś a kopěrowaś:',
'protectedinterface'   => 'Toś ten bok wopśimujo tekst za rěcny zwjerch softwary. Jogo wobźěłowanje jo se znjemóžniło, aby se znjewužywanjeju zadorało.',
'editinginterface'     => "'''Warnowanje:''' Wobźěłujoš bok, kótaryž se wužywa, aby se tekst za pówjerch software MediaWiki k dispoziciji stajił. Změny na toś tom boku buźo wuglědanje wužywarskego pówjercha za drugich wužywarjow wobwliwowaś. Wužywaj pšosym za pśełožki [http://translatewiki.net/wiki/Main_Page?setlang=dsb translatewiki.net], projekt MediaWiki za lokalizacije.",
'sqlhidden'            => '(Wótpšašanje SQL schowane)',
'cascadeprotected'     => 'Za toś ten bok jo se wobźěłowanje znjemóžniło, dokulaž jo zawězany do {{PLURAL:$1|slědujucego boka|slědujuceju bokowu|slědujucych bokow}}, {{PLURAL:$1|kótaryž jo|kótarejž stej|kótarež su}} pśez kaskadowu opciju {{PLURAL:$1|šćitany|šćitanej|šćitane}}: $2',
'namespaceprotected'   => "Njejsy wopšawnjony, boki w rumje: '''$1''' wobźěłaś.",
'customcssjsprotected' => 'Toś te boki njesmějoš wobźěłaś, dokulaž wopśimjeju wósobinske dataje drugego wužywarja.',
'ns-specialprotected'  => 'Njejo móžno, boki w rumje {{ns:special}} wobźěłaś.',
'titleprotected'       => "Bok z toś tym mjenim bu wót [[User:$1|$1]] pśeśiwo napóranjeju šćitany. Pśicyna jo ''$2''.",

# Virus scanner
'virus-badscanner'     => "Špatna konfiguracija: njeznaty wirusowy scanner: ''$1''",
'virus-scanfailed'     => 'Scannowanje jo se njeraźiło (kod $1)',
'virus-unknownscanner' => 'njeznaty antiwirus:',

# Login and logout pages
'logouttitle'                => 'Wužywarja wótzjawiś',
'logouttext'                 => "'''Sy se něnto wótzjawił.'''
Móžoš {{SITENAME}} anomymnje dalej wužywaś abo móžoš [[Special:UserLogin|se znowego pśizjawiś]] ako samski abo hynakšy wužywaŕ.
Źiwaj na to, až někotare boki se dalej tak zwobraznjuju ako by hyšći pśizjawjeny był, až njewuproznijoš cache swójego wobglědowaka.",
'welcomecreation'            => '== Witaj, $1! ==

Twójo konto jo se załožyło. Njezabydni změniś swóje [[Special:Preferences|nastajenja {{SITENAME}}]].',
'loginpagetitle'             => 'Wužywarja pśizjawiś',
'yourname'                   => 'mě wužywarja',
'yourpassword'               => 'šćitne gronidło:',
'yourpasswordagain'          => 'Šćitne gronidło hyšći raz zapódaś:',
'remembermypassword'         => 'Šćitne gronidło na toś tom computerje składowaś',
'yourdomainname'             => 'Twója domejna',
'externaldberror'            => 'Abo jo wustupiła eksterna zmólka awtentifikacije datoweje banki, abo njesmějoš swójo eksterne wužywarske konto aktualizěrowaś.',
'login'                      => 'Pśizjawiś se',
'nav-login-createaccount'    => 'Pśizjawiś se',
'loginprompt'                => 'Za pśizjawjenje do boka {{SITENAME}} muse se cookije dopušćiś.',
'userlogin'                  => 'Pśizjawiś se',
'logout'                     => 'Wótzjawiś se',
'userlogout'                 => 'Wótzjawiś se',
'notloggedin'                => 'Njepśizjawjony(a)',
'nologin'                    => 'Njamaš wužywarske konto? $1.',
'nologinlink'                => 'Nowe wužywarske konto załožyś',
'createaccount'              => 'Wužywarske konto załožyś',
'gotaccount'                 => 'Maš južo wužywarske konto? $1.',
'gotaccountlink'             => 'Pśizjawiś se',
'createaccountmail'          => 'z e-mailku',
'badretype'                  => 'Šćitnej gronidle, kótarejž sy zapódał, se njemakajotej.',
'userexists'                 => 'Toś to wužywarske mě słuša južo drugemu wužywarjeju, pšosym wuzwól se druge.',
'youremail'                  => 'E-mail:',
'username'                   => 'Wužywarske mě:',
'uid'                        => 'ID wužywarja:',
'prefs-memberingroups'       => 'Cłonk {{PLURAL:$1|wužywarskeje skupiny|wužywarskeju kupkowu|wužywarskich kupkow|wužiwarskich kupkow}}:',
'yourrealname'               => 'Realne mě *:',
'yourlanguage'               => 'Rěc:',
'yourvariant'                => 'Warianta:',
'yournick'                   => 'Pódpismo:',
'badsig'                     => 'Signatura njejo dobra; pšosym HTML pśekontrolěrowaś.',
'badsiglength'               => 'Twója signatura jo pśedłujka. Musy mjenjej ako $1 {{PLURAL:$1|znamješko|znamješce|znamješka|znamješkow}} měś.',
'email'                      => 'E-mail',
'prefs-help-realname'        => 'Realne mě jo opcionalne. Jolic až jo zapódajośo wužywa se za pódpisanje wašych pśinoskow.',
'loginerror'                 => 'Zmólka pśi pśizjawjenju',
'prefs-help-email'           => 'E-mailowa adresa jo opcionalna, ale zmóžnja śi nowe gronidło emailowaś, jolic sy zabył swójo gronidło.  Móžoš teke drugim dowóliś se z tobu stajiś do zwiska pśez waš wužywarski abo diskusijny bok, bźez togo až dejš wótekšyś swóju identitu.',
'prefs-help-email-required'  => 'E-mailowa adresa trjebna.',
'nocookiesnew'               => 'Wužywarske konto jo se južo wutwóriło, ale wužywaŕ njejo pśizjawjony. {{SITENAME}} wužywa cookije za pśizjawjenja. Jo notne, cookije zmóžniś a se wótnowotki pśizjawiś.',
'nocookieslogin'             => '{{SITENAME}} wužywa cookije za pśizjawjenja. Jo notne, cookije zmóžniś a se wótnowotki pśizjawiś.',
'noname'                     => 'Njejsy žedno płaśece wužywarske mě zapódał.',
'loginsuccesstitle'          => 'Pśizjawjenje wuspěšne',
'loginsuccess'               => "'''Sy něnto ako „$1” w {{GRAMMAR:lokatiw|{{SITENAME}}}} pśizjawjony.'''",
'nosuchuser'                 => 'Wužywaŕ z mjenim „$1“ njeeksistěrujo. Wužywarske mjenja źiwaju na wjelikopisanje.
Pśeglěduj pšawopis abo [[Special:UserLogin/signup|załož nowe konto]].',
'nosuchusershort'            => 'Wužywarske mě „<nowiki>$1</nowiki>“ njeeksistěrujo. Pśeglěduj pšawopis.',
'nouserspecified'            => 'Pšosym pódaj wužywarske mě.',
'wrongpassword'              => 'Zapódane šćitne gronidło njejo pšawe. Pšosym wopytaj hyšći raz.',
'wrongpasswordempty'         => 'Šćitne gronidło jo było prozne. Pšosym zapódaj jo hyšći raz.',
'passwordtooshort'           => 'Twójo gronidło jo njepłaśiwe abo pśeliš krotke. Wóno dej nanejmjenjej {{PLURAL:$|1 pismik|$1 pismika|$1 pismiki|$1 pismikow}} měś a njesmějo se z wužywarskim mjenim makaś.',
'mailmypassword'             => 'Nowe gronidło pśipósłaś',
'passwordremindertitle'      => 'Nowe nachylne pótajmne słowo za {{SITENAME}}',
'passwordremindertext'       => 'Něchten z IP-adresu $1 (nejskerjej ty) jo se wupšosył nowe gronidło za {{SITENAME}} ($4).
Nachylne gronidło za wužywarja "$2" jo se napórało a jo něnto "$3". Jolic jo to twój wótglěd było, musyš se něnto pśijawiś a wubraś nowe gronidło. 

Jolic jo něchten drugi wó nowe šćitne gronidło pšosył abo ty sy se zasej dopomnjeł na swójo gronidło  a njocoš wěcej jo změniś, móžoš toś tu powěsć ignorěrowaś a swójo stare gronidło dalej wužywaś.',
'noemail'                    => 'Wužywaŕ „$1“ njejo e-mailowu adresu zapódał.',
'passwordsent'               => 'Nowe šćitne gronidło jo se wótpósłało na e-mailowu adresu wužywarja „$1“.
Pšosym pśizjaw se zasej, gaž jo dostanjoš.',
'blocked-mailpassword'       => 'Twója IP-adresa jo se za wobźěłowanje bokow blokěrowała a teke pśipósłanje nowego šćitnego gronidła jo se znjemóžniło, aby se znjewužywanjeju zadorało.',
'eauthentsent'               => 'Wobkšuśenje jo se na e-mailowu adresu wótposłało.

Nježli až wótpósćelo se dalšna e-mail na to wužywarske konto, dejš slědowaś instrukcije w powěsći a tak wobkšuśiś, až konto jo wót wěrnosći twójo.',
'throttled-mailpassword'     => 'W běgu {{PLURAL:$1|slědneje $1 góźiny|slědnjeju $1 góźinowu|slědnych $1 góźinow}} jo se južo raz wó nowe šćitne gronidło pšosyło. Aby se znjewužywanje wobinuło, wótpósćelo se jano jadno šćitne gronidło w běgu {{PLURAL:$1|$1 góźiny|$1 góźinowu|$1 góźinow}}.',
'mailerror'                  => 'Zmólka pśi wótpósłanju e-maila: $1',
'acct_creation_throttle_hit' => 'Woglědowarje toś togo wikija, kótarež wužywaju twóju IP-adresu su napórali {{PLURAL:$1|1 konto|$1 konśe|$1 konta|$1 kontow}} slědny źeń. To jo maksimalna dowólona licba za toś tu periodu.
Woglědowarje, kótarež wužywaju toś tu IP-adresu njamógu tuchylu dalšne konta napóraś.',
'emailauthenticated'         => 'Twója e-mailowa adresa jo se $2 $3 goź. wobkšuśiła.',
'emailnotauthenticated'      => 'Twója e-mailowa adresa njejo hyšći wobkšuśona. E-mailowe funkcije móžoš aklej pó wuspěšnem wobkšuśenju wužywaś.',
'noemailprefs'               => 'Zapódaj e-mailowu adresu w swójich nastajenjach, aby toś te funkcije stali k dispoziciji.',
'emailconfirmlink'           => 'Wobkšuś swóju e-mailowu adresu.',
'invalidemailaddress'        => 'Toś ta e-mailowa adresa njamóžo se akceptěrowaś, dokulaž zda se, až jo njepłaśiwy format. Pšošym zapódaj adresu w korektnem formaśe abo wuprozń to pólo.',
'accountcreated'             => 'Wužywarske konto jo se wutwóriło.',
'accountcreatedtext'         => 'Wužywarske konto $1 jo se wutwóriło.',
'createaccount-title'        => 'Wužywarske konto za {{SITENAME}} nawarjone',
'createaccount-text'         => 'Něchten jo konto za twóje e-mailowu adresu na {{GRAMMAR:lokatiw|{{SITENAME}}}} ($4) z mjenim "$2", z pótajmnym słowom "$3", wutwórił. Dejš se pśizjawiś a swóje pótajmne słowo něnt změniś.

Móžoš toś te zdźělenje ignorowaś, jolic toś te konto jo se jano zamólnje wutwóriło.',
'login-throttled'            => 'Sy pśecesto wopytał gronidło konta zapódaś. Pócakaj pšosym, nježli až wopytajoš znowego.',
'loginlanguagelabel'         => 'Rěc: $1',

# Password reset dialog
'resetpass'                 => 'Gronidło změniś',
'resetpass_announce'        => 'Sy z nachylnym e-mailowym šćitnym gronidłom pśizjawjony. Aby pśizjawjenje zakóńcył, zapódaj how nowe šćitne gronidło:',
'resetpass_text'            => '<!-- Dodaj how tekst -->',
'resetpass_header'          => 'Kontowe gronidło změniś',
'oldpassword'               => 'Stare šćitne gronidło:',
'newpassword'               => 'Nowe šćitne gronidło:',
'retypenew'                 => 'Nowe šćitne gronidło (hyšći raz):',
'resetpass_submit'          => 'Šćitne gronidło nastajiś a se pśizjawiś',
'resetpass_success'         => 'Twójo nowe šćitne gronidło jo nastajone. Něnto se pśizjaw …',
'resetpass_bad_temporary'   => 'Nachylne e-mailowe šćitne gronidło njejo korektne. Sy swójo šćitne gronidło južo pśeměnił(a) abo wó nowe nachylne gronidło pšošył(a).',
'resetpass_forbidden'       => 'Gronidła njedaju se změniś',
'resetpass-no-info'         => 'Dejš pśizjawjony byś, aby direktny pśistup na toś ten bok měł.',
'resetpass-submit-loggedin' => 'Gronidło změniś',
'resetpass-wrong-oldpass'   => 'Njepłaśiwe nachylne abo aktualne gronidło.
Sy snaź swójo gronidło južo wuspěšnje změnił abo nowe nachylne gronidło pominał.',
'resetpass-temp-password'   => 'Nachylne gronidło:',

# Edit page toolbar
'bold_sample'     => 'Tucny tekst',
'bold_tip'        => 'Tucny tekst',
'italic_sample'   => 'Kursiwny tekst',
'italic_tip'      => 'Kursiwny tekst',
'link_sample'     => 'Tekst wótkaza',
'link_tip'        => 'Interny wótkaz',
'extlink_sample'  => 'http://www.example.com nadpismo wótkaza',
'extlink_tip'     => 'Eksterny wótkaz (źiwaś na http://)',
'headline_sample' => 'Nadpismo',
'headline_tip'    => 'Nadpismo rowniny 2',
'math_sample'     => 'Zapódaj how formulu',
'math_tip'        => 'Matematiska formula (LaTeX)',
'nowiki_sample'   => 'Zapódaj how njeformatěrowany tekst',
'nowiki_tip'      => 'Wiki-syntaksu ignorěrowaś',
'image_sample'    => 'Pokazka.jpg',
'image_tip'       => 'Zasajźona dataja',
'media_sample'    => 'pokazka.ogg',
'media_tip'       => 'Datajowy wótkaz',
'sig_tip'         => 'Twója signatura z casowym kołkom',
'hr_tip'          => 'Horicontalna linija (rědko wužywaś)',

# Edit pages
'summary'                          => 'Zespominanje:',
'subject'                          => 'Tema/Nadpismo:',
'minoredit'                        => 'Snadna změna',
'watchthis'                        => 'Toś ten bok wobglědowaś',
'savearticle'                      => 'Bok składowaś',
'preview'                          => 'Pśeglěd',
'showpreview'                      => 'Pśeglěd pokazaś',
'showlivepreview'                  => 'Livepśeglěd',
'showdiff'                         => 'Pśeměnjenja pokazaś',
'anoneditwarning'                  => "'''Warnowanje:''' Njejsy pśizjawjony. Změny w stawiznach togo boka składuju se z twójeju IP-adresu.",
'missingsummary'                   => "'''Pokazka:''' Njejsy žedno zespominanje zapódał. Gaž kliknjoš na \"Składowaś\" składujo se bok bźez zespominanja.",
'missingcommenttext'               => 'Pšosym zespominanje zapódaś.',
'missingcommentheader'             => "'''WARNOWANJE:''' Njejsy žedno nadpismo zapódał. Gaž kliknjoš na \"Składowaś\", składujo se twójo wobźěłanje mimo nadpisma.",
'summary-preview'                  => 'Pśeglěd zespominanja:',
'subject-preview'                  => 'Pśeglěd nadpisma:',
'blockedtitle'                     => 'Wužywaŕ jo se blokěrował',
'blockedtext'                      => "<big>'''Twójo wužywarske mě abo IP-adresa stej se blokěrowałej.'''</big>

Blokěrowanje pśez $1. 
Pódana pśicyna: ''$2''.

* Zachopjeńk blokěrowanja: $8
* Kóńc blokěrowanja: $6
* Blokěrowany wužywaŕ: $7

Móžoš $1 abo drugego [[{{MediaWiki:Grouppage-sysop}}|administratora]] kontaktěrowaś, aby wó blokěrowanju diskutěrował.
Njamóžoš funkciju 'Toś tomu wužywarjeju e-mail pósłaś' wužywaś, snaźkuli płaśiwa e-mailowa adresa jo pódana w swójich kontowych [[Special:Preferences|nastajenjach]] a njeblokěrujos se ju wužywaś.
Twója IP-adresa jo $3, a ID blokěrowanja jo #$5. 
Pšosym zapśimjej wše górjejcne drobonosći do napšašowanjo, kótarež cyniš.",
'autoblockedtext'                  => 'Twója IP-adresa jo se awtomatiski blokěrowała, dokulaž jo se wót drugego wužywarja wužywała, kótaryž jo był wót $1 blokěrowany.
Pśicyna:

:\'\'$2\'\'

* Zachopjeńk blokěrowanja: $8
* Kóńc blokěrowanja: $6
* Blokěrowany wužywaŕ: $7

Ty móžoš wužywarja $1 abo jadnogo z drugich [[{{MediaWiki:Grouppage-sysop}}|administratorow]] kontaktěrowaś, aby wó blokaźe diskutěrował.

Wobmysli, až njamóžoš funkciju "Toś tomu wužywarjeju e-mail pósłaś" wužywaś, až njezapódajoš płaśecu adresu na boku wužywarskich [[Special:Preferences|nastajenjow]] a až se njeblokěrujoš ju wužywaś.

Twója aktualna IP-adresa jo $3 a ID blokěrowanja jo #$5.
Zapśimjejśo pšosym wše górjejce pomjenjowane drobnosći do wšych napšašowanjow, kótarež cyniš.',
'blockednoreason'                  => 'Pśicyna njejo dana',
'blockedoriginalsource'            => "Žrědłowy tekst boka '''$1''':",
'blockededitsource'                => "Žrědłowy tekst '''Twójich pśinoskow''' do '''$1''' jo:",
'whitelistedittitle'               => 'Za wobźěłanje dejš se pśizjawiś',
'whitelistedittext'                => 'Musyš se $1, aby mógał boki wobźěłowaś.',
'confirmedittitle'                 => 'Za wobźěłanje jo wobkšuśenje e-mailki notne.',
'confirmedittext'                  => 'Nježli až móžoš źěłaš, musyš swóju e-mailowu adresu wobkšuśiś. Pšosym dodaj a wobkšuś swóju e-mailowu adresu w [[Special:Preferences|nastajenjach]].',
'nosuchsectiontitle'               => 'Wótrězk njeeksistěrujo.',
'nosuchsectiontext'                => 'Sy wopytał wobźěłaś njeeksistěrujucy wótrězk $1. Dokulaž taki wótrězk njeeksistěrujo, njamóžoš swójo wobźěłanje niźi składowaś.',
'loginreqtitle'                    => 'Pśizjawjenje trěbne',
'loginreqlink'                     => 'se pśizjawiś',
'loginreqpagetext'                 => 'Dejš se $1, aby mógł boki pšawje cytaś.',
'accmailtitle'                     => 'Šćitne gronidło jo se wótpósłało.',
'accmailtext'                      => 'Šćitne gronidło za wužywarja "$1" jo na adresu $2 se wótpósłało.',
'newarticle'                       => '(Nowy nastawk)',
'newarticletext'                   => 'Sy slědował wótkaz na bok, kótaryž hyšći njeeksistěrujo.
Aby bok wutwórił, ga napiš do kašćika spózy.
(Dokradnjejše informacije pód: [[{{MediaWiki:Helppage}}|help page]]).',
'anontalkpagetext'                 => "---- ''Toś jo diskusijny bok za anonymnego wužywarja, kótaryž njejo dotychměst žedno wužywarske konto załožył abo swójo konto njewužywa. Togodla dejmy numerisku IP-adresu wužywaś, aby jogo/ju identificěrowali. Taka IP-adresa dajo se wót wšakich wužywarjow wužywaś. Jolic sy anonymny wužywaŕ a se mysliš, až su se njerelewantne komentary na tebje měrili, [[Special:UserLogin/signup|załož konto]] abo [[Special:UserLogin|pśizjaw se]], aby se w pśichoźe zmuśenje z drugimi anonymnymi wužywarjami wobinuł.''",
'noarticletext'                    => 'Dotychměst toś ten bok hyšći njewopśimujo žeden tekst. Móžoš w drugich bokach [[Special:Search/{{PAGENAME}}|titel togo boka pytaś]], <span class="plainlinks">[{{fullurl:Special:Log|page={{urlencode:{{FULLPAGENAME}}}}}} wótpowědne protokole pytaś] abo [{{fullurl:{{FULLPAGENAME}}|action=edit}} toś ten bok wobźěłaś]</span>.',
'userpage-userdoesnotexist'        => 'Wužywarske konto "$1" njejo zregistrěrowane. Pšosym pśeglědaj, lěc coš toś ten bok wopšawdu napóraś/wobźěłaś.',
'clearyourcache'                   => "'''Pokazka: Jo móžno, až dejš wuprozniś cache wobglědowaka, aby změny wiźeł.'''
'''Mozilla/Firefox/Safari:''' Źarź ''Umsch'' tłocony, mjaztym až kliknjoš ''Znowego'' abo tłoc pak ''Strg-F5'' pak ''Strg-R'' (''Command-R'' na Makintošu); '''Konqueror: '''Klikni ''' na ''Aktualisieren'' abo tłoc ''F5;'' '''Opera:''' wuprozni cache w ''Extras -> Eisntellungen;'' '''Internet Explorer:''' źarź ''Strg'' tłocony, mjaztym až kliknjoš na ''Aktualisieren'' abo tłoc ''Strg-F5.''",
'usercssjsyoucanpreview'           => "'''Pokazka:''' Wužywaj tłocydło \"Pśeglěd\", aby swój nowy css/js testował, nježli až jen składujoš.",
'usercsspreview'                   => "'''Źiwaj na to, až wobglědujoš se jano pśeglěd swójogo wužywarskego CSS. Njejo se hyšći składował!'''",
'userjspreview'                    => "== Pśeglěd Wašogo wužywarskego JavaScripta ==
'''Glědaj:''' Pó składowanju musyš swójomu browseroju kazaś, aby nowu wersiju pokazał: '''Mozilla/Firefox:''' ''Strg-Shift-R'', '''Internet Explorer:''' ''Strg-F5'', '''Opera:''' ''F5'', '''Safari:''' ''Cmd-Shift-R'', '''Konqueror:''' ''F5''.",
'userinvalidcssjstitle'            => "'''Warnowanje:''' Njeeksistěrujo šat „$1“. Pšosym mysli na to, až wužywaju .css- a .js-boki mały pismik, na pś. ''{{ns:user}}:Pśikładowa/monobook.css'' město ''{{ns:user}}:Pśikładowa/Monobook.css''.",
'updated'                          => '(Zaktualizěrowane)',
'note'                             => "'''Pokazka:'''",
'previewnote'                      => "'''To jo jano pśeglěd, bok njejo hyšći składowany!'''",
'previewconflict'                  => 'Toś ten pśeglěd wótbłyšćujo tekst górjejcnego póla. Bok buźo tak wuglědaś, jolic jen něnto składujoš.',
'session_fail_preview'             => "'''Wódaj! Twójo wobźěłanje njejo se mógało składowaś, dokulaž su daty twójogo pósejźenja se zgubili. Pšosym wopytaj hyšći raz. Jolic až to pón pśecej hyšći njejźo, wopytaj se wótzjawiś a zasej pśizjawiś.'''",
'session_fail_preview_html'        => "'''Wódaj! Twójo wobźěłanje njejo se mógało składowaś, dokulaž su daty twójogo pósejźenja se zgubili.'''

''Dokulaž {{SITENAME}} ma cysty html aktiwizěrowany, jo pśeglěd se zacynił - ako šćit pśeśiwo JavaScriptowym atakam.''

'''Jo-lic to legitiměrowane wobźěłanje, wopytaj hyšći raz. Gaž to zasej njejźo, wopytaj se wót- a zasej pśizjawiś.'''",
'token_suffix_mismatch'            => "'''Twójo wobźěłanje jo se wótpokazało, dokulaž jo twój browser znamuška we wobźěłańskem tokenje rozsekał. Składowanje by mógało wopśimjeśe boka znicyś. Take casy se źejo, gaž wužywaš web-bazěrowanu, zmólkatu, anonymnu proksy-słužbu.'''",
'editing'                          => 'Wobźěłanje boka $1',
'editingsection'                   => 'Wobźěłanje boka $1 (wótrězk)',
'editingcomment'                   => '$1 (nowy wótrězk) se wobźěłujo',
'editconflict'                     => 'Wobźěłański konflikt: $1',
'explainconflict'                  => "Něchten drugi jo bok změnił, pó tym, až sy zachopił jen wobźěłaś.
Górjejcne tekstowe pólo wopśimjejo tekst boka, ako tuchylu eksistěrujo.
Twóje změny pokazuju se w dołojcnem tekstowem pólu.
Pšosym zapódaj twóje změny do górjejcnego tekstowego póla.
'''Jano''' wopśimjeśe górjejcnego tekstowego póla se składujo, gaž tłocyš na \"składowaś\".",
'yourtext'                         => 'Twój tekst',
'storedversion'                    => 'Składowana wersija',
'nonunicodebrowser'                => "'''Glědaj:''' Twój browser njamóžo unicodowe znamuška pšawje pśeźěłaś. Pšosym wužywaj hynakšy browser.",
'editingold'                       => "'''Glědaj: Wobźěłajoš staru wersiju toś togo boka. Gaž składujoš, zgubiju se wšykne nowše wersije.'''",
'yourdiff'                         => 'Rozdźěle',
'copyrightwarning'                 => "Pšosym buź se togo wědobny, až wšykne pśinoski na {{SITENAME}} se wózjawiju pód $2 (za detajle glědaj $1). Jolic až njocoš, až twój tekst se mimo zmilnosći wobźěłujo a za spódobanim drugich redistribuěrujo, pón njeskładuj jen how.<br />
Ty teke wobkšuśijoš, až sy tekst sam napisał abo sy jen wót public domainy resp. wót pódobneje lichotneje resursy kopěrował.

'''NJEWÓZJAW WÓT COPYRIGHTA ŠĆITANE ŹĚŁA MIMO DOWÓLNOSĆI!'''",
'copyrightwarning2'                => "Pšosym buź se togo wědobny, až wšykne pśinoski na {{SITENAME}} mógu wót drugich wužywarjow se wobźěłaś, narownaś abo wulašowaś. Jolic až njocoš, až twój tekst se mimo zmilnosći wobźěłujo, ga pón jen how njeskładuj.<br /> Ty teke wobkšuśijoš, až sy tekst sam napisał abo sy jen wót public domainy resp. wót pódobneje lichotneje resursy kopěrował (glědaj $1 za dalše detaile). '''NJEWÓZJAW WÓT COPYRIGHTA ŠĆITANE ŹĚŁA MIMO DOWÓLNOSĆI!'''",
'longpagewarning'                  => "'''GLĚDAJ: Toś ten bok wopśimjejo $1 kilobajtow; někotare wobglědowaki mógu měś problemy z wobźěłowanim bokow, kótarež su wětše ako 32 kb.
Pšosym pśemysli, jolic njamóžo se bok na mjeńše wótrězki rozdźěliś.'''",
'longpageerror'                    => "'''Zmólka: Tekst, kótaryž coš składowaś jo $1 KB wjeliki. To jo wěcej, ako dowólony maksimum ($2 KB). Składowanje njejo móžno.'''",
'readonlywarning'                  => "'''WARNOWANJE: Datowa banka jo se za wótwardowanje zacyniła, togodla njebuźo tuchylu móžno, twóje změny składowaś. Jolic až coš, ga móžoš tekst do tekstoweje dataje kopěrowaś a pózdźej składowaś.'''

Administrator, kenž jo ju zastajił, su toś tu pśicynu pódał: $1",
'protectedpagewarning'             => "'''Glědaj: Toś ten bok jo se zakazał, tak až jano sysopowe wužywarje mógu jen wobźěłaś.'''",
'semiprotectedpagewarning'         => "'''Markuj:''' Toś ten bok jo se zakazał, tak až jano registrěrowane wužywarje mógu jen wobźěłaś.",
'cascadeprotectedwarning'          => "'''Glědaj: Toś ten bok jo se zakazał, tak až jano wužywarje ze sysopowymi priwiliegijami mógu jen wobźěłaś, dokulaž jo zawězana do {{PLURAL:$1|slědujucego boka|slědujuceju bokowu|slědujucych bokow}}, {{PLURAL:$1|kótaryž jo šćitany|kótarejž stej šćitanej|kótarež su šćitane}} z pomocu kaskadoweje zakazanskeje opcije.'''",
'titleprotectedwarning'            => "'''WARNOWANJE: Toś ten bok bu zakazany, tak až [[Special:ListGroupRights|wósebne pšawa]] su trěbne, aby jen napórał.'''",
'templatesused'                    => 'Za toś ten bok su se slědujuce pśedłogi wužywali:',
'templatesusedpreview'             => 'Za toś ten pśeglěd su slědujuce pśedłogi se wužywali:',
'templatesusedsection'             => 'W toś tom wótrězku su slědujuce pśedłogi se wužywali:',
'template-protected'               => '(šćitane)',
'template-semiprotected'           => '(poł šćitane)',
'hiddencategories'                 => 'Toś ten bok jo jadna z {{PLURAL:$1|1 schowaneje kategorije|$1 schowaneju kategorijow|$1 schowanych kategorijow|$1 schowanych kategorijow}}:',
'edittools'                        => '<!-- Tekst how buźo wiźeś pód wobźěłowańskimi a upload-formularami. -->',
'nocreatetitle'                    => 'Załožowanje nowych bokow jo se wobgranicowało.',
'nocreatetext'                     => 'Na {{GRAMMAR:lokatiw|{{SITENAME}}}} jo se załoženje nowych bokow wót serwera wobgranicowało. Móžoš hyś slědk a eksistěrujucy bok wobźěłaś, abo se [[Special:UserLogin|pśizjawiś]].',
'nocreate-loggedin'                => 'Njamaš pšawo nowe boki napóraś.',
'permissionserrors'                => 'Problem z pšawami',
'permissionserrorstext'            => 'Njamaš pšawo to cyniś. {{PLURAL:$1|Pśicyna|Pśicynje|Pśicyny}}:',
'permissionserrorstext-withaction' => 'Z {{PLURAL:$1|slědujuceje pśicyny|slědujuceju pśicynowu|slědujucych pśicynow|slědujucych pśicynow}} njamaš pšawo $2:',
'recreate-deleted-warn'            => "'''Glědaj: Ty wótžywijoš bok, kótaryž jo pjerwjej se wulašował.'''

Pšosym pśespytuj kradosćiwje, lic wótpowědujo dalšne wótnowjenje bokow směrnicam.
Aby se mógał informěrowaś, slědujo how wulašowanski log-zapis, w kótaremž namakajoš teke pśicyny wulašowanja.",
'deleted-notice'                   => 'Toś ten bok jo se wulašował. Protokol wulašowanjow za toś ten bok pódawa se dołojce ako referenca.',
'deletelog-fulllog'                => 'Dopołny protokol se wobglědaś',
'edit-hook-aborted'                => 'Wobźěłanje pśez kokulu pśetergnjony.
Njejo žedne wujasnjenje.',
'edit-gone-missing'                => 'Njejo móžno było bok aktualizěrowaś.
Zda sem až jo wulašowany.',
'edit-conflict'                    => 'Wobźěłański konflikt.',
'edit-no-change'                   => 'Wašo wobźěłanje jo se ignorěrowało, dokulaž tekst njejo se změnił.',
'edit-already-exists'              => 'Njejo móžno było nowy bok napóraś.
Eksistěrujo južo.',

# Parser/template warnings
'expensive-parserfunction-warning'        => 'Warnowanje: Toś ten bok wopśimujo pśewjele wołanjow parserowych funkcijow wupominajucych wusoke wugbaśe.

Njesmějo daś wěcej nježli $2 {{PLURAL:$2|wołanja|wołanjowu|wołanjow|wołanjow}}, něnto {{PLURAL:$1|jo $1 wołanje|stej $1 wołani|su $1 wołanja|jo $1 wołanjow}}.',
'expensive-parserfunction-category'       => 'Boki z pśewjele paerserowymi funkcijami, kótarež pominaju sebje wusoke wugbaśe.',
'post-expand-template-inclusion-warning'  => 'Warnowanje: Wjelikosć zapśěgnjonych pśedłogow jo pśewjelika. Někotare pśedłogi se njezapśěgu.',
'post-expand-template-inclusion-category' => 'Boki, w kótarychž maksimalna wjelikosć zapśěgnjonych pśedłogow jo pśekšocona.',
'post-expand-template-argument-warning'   => 'Warnowanje: Toś ten bok wopśimujo nanejmjenjej jaden argument w pśedłoze, kótaryž jo pśwjeliki pó ekspanděrowanju. Toś te argumenty se wuwóstajiju.',
'post-expand-template-argument-category'  => 'Boki, kótarež wuwóstajone pśedłogowe argumenty wopśimuju',
'parser-template-loop-warning'            => 'Pśedłogowa šlejfa namakana: [[$1]]',
'parser-template-recursion-depth-warning' => 'Limit rekursijneje dłymi pśedłogi pśekšocony ($1)',

# "Undo" feature
'undo-success' => 'Wobźěłanje móžo se wótpóraś. Pšosym pśeglěduj dołojcne pśirownowanje aby se wěsty był, až to wót wěrnosći coš, a pón składuj změny, aby se wobźěłanje doskóńcnje wótpórało.',
'undo-failure' => 'Změna njejo se mógała wótpóraś, dokulaž jo něchten pótrjefjony wótrězk mjaztym změnił.',
'undo-norev'   => 'Změna njeda se wótwrośiś, dokulaž njeeksistěčujo abo jo se wulašowała.',
'undo-summary' => 'Wersija $1 wót [[Special:Contributions/$2|$2]] ([[User talk:$2|Diskusija]]) jo se anulěrowała',

# Account creation failure
'cantcreateaccounttitle' => 'Njejo móžno wužywarske konto wutwóriś',
'cantcreateaccount-text' => "Wutwórjenje wužywarskego konta z toś teje IP adresy ('''$1''') jo blokěrowane pśez [[User:$3|$3]].

Pśicyna, kótaruž $3 jo zapódał, jo ''$2''.",

# History pages
'viewpagelogs'           => 'Protokole boka pokazaś',
'nohistory'              => 'Stawizny wobźěłanja za toś ten bok njeeksistěruju.',
'currentrev'             => 'Aktualna wersija',
'currentrev-asof'        => 'Aktualna wersija wót $1',
'revisionasof'           => 'Wersija z $1',
'revision-info'          => 'Wersija z $1 wót wužywarja $2', # Additionally available: $3: revision id
'previousrevision'       => '← Zachadna rewizija',
'nextrevision'           => 'Pśiduca wersija →',
'currentrevisionlink'    => 'Aktualna wersija',
'cur'                    => 'aktualny',
'next'                   => 'pśiduce',
'last'                   => 'zachadne',
'page_first'             => 'zachopjeńk',
'page_last'              => 'kóńc',
'histlegend'             => 'Aby se změny pokazali, dejtej se pśirownanskej wersiji wuzwóliś. Pón dej se "enter" abo dołojcne tłocanko (button) tłocyś.<br />

Legenda:
* (Aktualne) = Rozdźěl k aktualnej wersiji, (pśedchadna) = rozdźěl k pśedchadnej wersiji
* Cas/datum = W toś tom casu aktualna wersija, wužywarske mě/IP-adresa wobźěłarja, D = drobna změna',
'history-fieldset-title' => 'W stawiznach pytaś',
'deletedrev'             => '[wulašowane]',
'histfirst'              => 'nejstarše',
'histlast'               => 'nejnowše',
'historysize'            => '({{PLURAL:$1|1 byte|$1 byta|$1 byty}})',
'historyempty'           => '(prozne)',

# Revision feed
'history-feed-title'          => 'Stawizny wersijow',
'history-feed-description'    => 'Stawizny wersijow za toś ten bok w {{GRAMMAR:lokatiw|{{SITENAME}}}}',
'history-feed-item-nocomment' => '$1 na $2', # user at time
'history-feed-empty'          => 'Pominany bok njeeksistěrujo.
Snaź jo se z wiki wulašował abo hynac pómjenił.
[[Special:Search|Pśepytaj]] {{SITENAME}} za relewantnymi bokami.',

# Revision deletion
'rev-deleted-comment'         => '(Komentar wulašowany)',
'rev-deleted-user'            => '(Wužywarske mě wulašowane)',
'rev-deleted-event'           => '(protokolowa akcija wulašowana)',
'rev-deleted-text-permission' => '<div class="mw-warning plainlinks">Toś ta wersija jo ze zjawnych archiwow se wulašowała. Dalšne informacije wó wulašowanju a pśicynu wulašowanja namakaju se we [{{fullurl:Special:Log/delete|page={{FULLPAGENAMEE}}}} wulašowańskej log-lisćinje].</div>',
'rev-deleted-text-view'       => '<div class="mw-warning plainlinks">Toś ta wersija jo ze zjawnych archiwow se wulašowała. Ako administrator móžoš je dalej wiźeś. Dalšne informacije wó wulašowanju a pśicyna wulašowanja namakaju se w [{{fullurl:Special:Log/delete|page={{FULLPAGENAMEE}}}} wulašowańskej lisćinje].</div>',
'rev-delundel'                => 'pokazaś/schowaś',
'revisiondelete'              => 'Wersije wulašowaś/wótnowiś',
'revdelete-nooldid-title'     => 'Njepłaśiwa celowa wersija',
'revdelete-nooldid-text'      => 'Njejsy pak žednu celowu wersiju pódał, aby se toś ta funkcija wuwjadła, pódana funkcija njeeksistěrujo pak wopytujoš aktualnu wersiju chowaś.',
'revdelete-selected'          => "'''{{PLURAL:$2|Wuzwólona wersija|Wuzwólonej wersiji|Wuzwólone wersije}} wót [[:$1]].'''",
'logdelete-selected'          => "'''{{PLURAL:$1|Wuzwólony protokolowe tšojenje|Wuzwólonej protokolowe tšojeni|wuzwólone protokolowe tšojenja}}:'''",
'revdelete-text'              => "'''Wulašowane wersije a tšojenja budu se dalej w stawiznach boka a w protokolach pokazaś, ale źěle jich wopśimjeśa njebudu pśistupne za zjawnosć.'''

Dalšne administratory na {{GRAMMAR:lokatiw|{{SITENAME}}}} mógu ale pśecej hyšći pśistup na schowane wopśimjeśe měś a mógu jo pśez samki interfejs wótnowiś,  snaźkuli su pśidatne wobgranicowanja.
Pšosym wobkšuś, až coš to cyniś, až rozmějoš slědy a až cyniš to wótpowědujucy [[{{MediaWiki:Policy-url}}|zasadam]].",
'revdelete-legend'            => 'wobgranicowanja widobnosći póstajiś',
'revdelete-hide-text'         => 'Tekst wersije schowaś',
'revdelete-hide-name'         => 'Akciju log-lisćiny schowaś',
'revdelete-hide-comment'      => 'Komentar wobźěłanja schowaś',
'revdelete-hide-user'         => 'mě/IP-adresu wobźěłarja schowaś',
'revdelete-hide-restricted'   => 'Daty wót administratorow ako teke te drugich wužywarjow pódtłocyś',
'revdelete-suppress'          => 'Pśicynu wulašowanja teke za administratorow schowaś',
'revdelete-hide-image'        => 'Wopśimjeśe dataje schowaś',
'revdelete-unsuppress'        => 'Wobgranicowanja za wótnowjone wersije zasej zwignuś.',
'revdelete-log'               => 'Komentar w log-lisćinje:',
'revdelete-submit'            => 'We wuzwólonej wersiji nałožyś',
'revdelete-logentry'          => 'Woglědanje wersije změnjone za [[$1]]',
'logdelete-logentry'          => 'wiźobnosć za [[$1]] změnjona.',
'revdelete-success'           => "'''Wiźobnosć wersije jo se z wuspěchom změniła.'''",
'logdelete-success'           => "'''Wiźobnosć log-lisćiny z wuspěchom změnjona.'''",
'revdel-restore'              => 'Widobnosć změniś',
'pagehist'                    => 'stawizny boka',
'deletedhist'                 => 'wulašowane stawizny',
'revdelete-content'           => 'wopśimjeśe',
'revdelete-summary'           => 'Zespominanje wobźěłanja',
'revdelete-uname'             => 'wužywarske mě',
'revdelete-restricted'        => 'Wobgranicowanja se teke na administratorow nałožuju',
'revdelete-unrestricted'      => 'Wobgranicowanja za administratorow wótpórane',
'revdelete-hid'               => 'schowa $1',
'revdelete-unhid'             => 'zasej wótkšy $1',
'revdelete-log-message'       => '$1 za $2 {{PLURAL:$2|wersiju|wersiji|wersije|wersijow}}',
'logdelete-log-message'       => '$1 za $2 {{PLURAL:$2|tšojenje|tšojeni|tšojenja|tšojenjow}}',

# Suppression log
'suppressionlog'     => 'Protokol pódłocowanjow',
'suppressionlogtext' => 'To jo lisćina wulašowanjow a blokěrowanjow, kótaraž ma wopśimjeśe, kótarež jo za administratorow schowane. Glědaj  [[Special:IPBlockList|lisćinu blokěrowanjow IP]] za lisćinu aktualnych wugnanjow a blokěrowanjow.',

# History merging
'mergehistory'                     => 'Zwězaś stawizny bokow',
'mergehistory-header'              => 'Z toś tym bokom móžoš historiju wersijow žrědłowego boka z tej celowego boka zjadnośiś.
Zaruc, až historija wersijow nastawka jo njepśetergnjona.',
'mergehistory-box'                 => 'Zwězaś wersjiowu toś teju bokowo:',
'mergehistory-from'                => 'Žrědłowy bok:',
'mergehistory-into'                => 'Celowy bok:',
'mergehistory-list'                => 'Wersije, kótarež móžoš zjadnośiś',
'mergehistory-merge'               => 'Slědujuce wersije wót [[:$1]] móžoš z [[:$2]] zjadnośiś. Markěruj wersiju, až k tej se wersije deje pśenjasć. Glědaj pšosym, až wužywanje nawigaciskich wótkazow wuběrk slědk stajijo.',
'mergehistory-go'                  => 'Wersije, kótarež daju se zjadnośiś, pokazaś',
'mergehistory-submit'              => 'Wersije zjadnośiś',
'mergehistory-empty'               => 'Njadaju se žedne wersije zjadnośiś.',
'mergehistory-success'             => '$3 {{PLURAL:$3|wersija|wersiji|wersije|wersijow}} wót [[:$1]] wuspěšnje do [[:$2]] {{PLURAL:$3|zjadnośona|zjadnośonej|zjadnośone|zjadnośone}}.',
'mergehistory-fail'                => 'Njemóžno stawizny zjadnośiś, pśeglědaj pšosym bok a casowe parametry.',
'mergehistory-no-source'           => 'Žrědłowy bok $1 njeeksistěruje.',
'mergehistory-no-destination'      => 'Celowy bok $1 njeeksistěruje.',
'mergehistory-invalid-source'      => 'Žrědłowy bok musy měś dobre nadpismo.',
'mergehistory-invalid-destination' => 'Celowy bok musy měś dobre nadpismo.',
'mergehistory-autocomment'         => '„[[:$1]]“ do „[[:$2]]“ zjadnośeny',
'mergehistory-comment'             => '„[[:$1]]“ do „[[:$2]]“ zjadnośeny: $3',
'mergehistory-same-destination'    => 'Žrědłowy bok a celowy bok njesmějotej identiskej byś',

# Merge log
'mergelog'           => 'Protokol zjadnośenja',
'pagemerge-logentry' => 'zjadnośi [[$1]] do [[$2]] (Wersije až do $3)',
'revertmerge'        => 'Zjadnośenje anulěrowaś',
'mergelogpagetext'   => 'Dołojce jo lisćina nejnowejšych zjadnośenjow historije boka z drugej.',

# Diffs
'history-title'           => 'Stawizny wersijow boka „$1“',
'difference'              => '(rozdźěle mjazy wersijoma/wersijami)',
'lineno'                  => 'Rědka $1:',
'compareselectedversions' => 'Wuzwólonej wersiji pśirownaś',
'visualcomparison'        => 'Wizuelne pśirownanje',
'wikicodecomparison'      => 'Pśirownanje wikiteksta',
'editundo'                => 'wótwrośiś',
'diff-multi'              => '(Pśirownanje wersijow(u) wopśimjejo teke {{PLURAL:$1|mjaz tutyma lažecu wersiju|$1 mjaz tutyma lažecej wersiji|$1 mjaz tutyma lažece wersije}}.)',
'diff-movedto'            => 'pśesunjony do $1',
'diff-styleadded'         => 'Stil $1 pśidany',
'diff-added'              => '$1 pśidany',
'diff-changedto'          => 'pśeměnjony do $1',
'diff-movedoutof'         => 'pśesunjony z $1',
'diff-styleremoved'       => 'Stil $1 wótwónoźony',
'diff-removed'            => '$1 wótwónoźony',
'diff-changedfrom'        => 'pśeměnjony z $1',
'diff-src'                => 'žrědło',
'diff-withdestination'    => 'z celom $1',
'diff-with'               => '&#32;z $1 $2',
'diff-with-final'         => '&#32;a $1 $2',
'diff-width'              => 'šyrokosć',
'diff-height'             => 'wusokosć',
'diff-p'                  => "'''wótstawk'''",
'diff-blockquote'         => "'''blokowy citat'''",
'diff-h1'                 => "'''nadpismo (1. rownina)'''",
'diff-h2'                 => "'''nadpismo (2. rownina)'''",
'diff-h3'                 => "'''nadpismo (3. rownina)'''",
'diff-h4'                 => "'''nadpismo (4. rownina)'''",
'diff-h5'                 => "'''nadpismo (5. rownina)'''",
'diff-pre'                => "'''předpformatěrowany blok'''",
'diff-div'                => "'''blokowy element'''",
'diff-ul'                 => "'''njenumerěrowana lisćina'''",
'diff-ol'                 => "'''numerěrowana lisćina'''",
'diff-li'                 => "'''lisćinowy zapisk'''",
'diff-table'              => "'''tabela'''",
'diff-tbody'              => "'''tabelowe wopśimjeśe'''",
'diff-tr'                 => "'''rěd'''",
'diff-td'                 => "'''cela'''",
'diff-th'                 => "'''słupowe nadpismo'''",
'diff-br'                 => "'''łamanje'''",
'diff-hr'                 => "'''horicontalna linija'''",
'diff-code'               => "'''blok z komputerowym kodom'''",
'diff-dl'                 => "'''definiciska lisćina'''",
'diff-dt'                 => "'''definiciske zapśimjeśe'''",
'diff-dd'                 => "'''definicija'''",
'diff-input'              => "'''zapódaśe'''",
'diff-form'               => "'''formular'''",
'diff-img'                => "'''wobraz'''",
'diff-span'               => "'''smužkowy element'''",
'diff-a'                  => "'''wótkaz'''",
'diff-i'                  => "'''kursiwny'''",
'diff-b'                  => "'''tucny'''",
'diff-strong'             => "'''mócny'''",
'diff-em'                 => "'''wuzwignjenje'''",
'diff-font'               => "'''pismowa družyna'''",
'diff-big'                => "'''wjeliki'''",
'diff-del'                => "'''wulašowany'''",
'diff-tt'                 => "'''kšuta šyrokosć'''",
'diff-sub'                => "'''dłymoko stajony'''",
'diff-sup'                => "'''wusoko stajony'''",
'diff-strike'             => "'''pśešmarnuś'''",

# Search results
'searchresults'                    => 'Wuslědki pytanja',
'searchresults-title'              => 'Pytańske wuslědki za "$1"',
'searchresulttext'                 => 'Za wěcej informacijow wó pśepytowanju {{GRAMMAR:genitiw|{{SITENAME}}}} glědaj [[{{MediaWiki:Helppage}}|{{int:help}}]].',
'searchsubtitle'                   => 'Sy pytał za \'\'\'[[:$1]]\'\'\' ([[Special:Prefixindex/$1|wše boki, kótarež zachopiju se z "$1"]]{{int:pipe-separator}}[[Special:WhatLinksHere/$1|wše wótkaze, kótarež wótkazuju do "$1"]])',
'searchsubtitleinvalid'            => 'Ty sy pytał „$1“.',
'noexactmatch'                     => "'''Bok z napismom „$1“ njeeksistěrujo.'''
Móžoš bok ale teke [[:$1|sam załožyś]].",
'noexactmatch-nocreate'            => "'''Njama boka z nadpismom \"\$1\".'''",
'toomanymatches'                   => 'Pśewjele pytańskich wuslědkow, pšosym wopytaj druge wótpšašanje.',
'titlematches'                     => 'boki z wótpowědujucym napismom',
'notitlematches'                   => 'Boki z wótpowědujucym napismom njeeksistěruju.',
'textmatches'                      => 'Boki z wótpowědujucym tekstom',
'notextmatches'                    => 'Boki z wótpowědujucym tekstom njeeksistěruju.',
'prevn'                            => 'zachadne $1',
'nextn'                            => 'pśiduce $1',
'viewprevnext'                     => 'Pokazaś ($1) ($2) ($3).',
'searchmenu-legend'                => 'Pytańske opcije',
'searchmenu-exists'                => "'''Jo bok z mjenim \"[[\$1]]\" na toś tom wikiju'''",
'searchmenu-new'                   => "'''Napóraj bok \"[[:\$1|\$1]]\" na toś tom wikiju!'''",
'searchhelp-url'                   => 'Help:Pomoc',
'searchmenu-prefix'                => '[[Special:PrefixIndex/$1|Boki z toś tym prefiksom pśepytaś]]',
'searchprofile-articles'           => 'Wopśimjeśowe boki',
'searchprofile-articles-and-proj'  => 'Wopśimjeśowe & projektowe boki',
'searchprofile-project'            => 'Projektowe boki',
'searchprofile-images'             => 'Dataje',
'searchprofile-everything'         => 'Wšykno',
'searchprofile-advanced'           => 'Rozšyrjony',
'searchprofile-articles-tooltip'   => 'W $1 pytaś',
'searchprofile-project-tooltip'    => 'W $1 pytaś',
'searchprofile-images-tooltip'     => 'Za datajami pytaś',
'searchprofile-everything-tooltip' => 'Cełe wopsímjeśe pśepytaś (inkluziwnje diskusijne boki)',
'searchprofile-advanced-tooltip'   => 'W swójskich mjenjowych rumach pytaś',
'prefs-search-nsdefault'           => 'Ze standardnymi nastajenjami pytaś',
'prefs-search-nscustom'            => 'Swójske mjenjowe rumy pśepytaś:',
'search-result-size'               => '$1 ({{PLURAL:$2|1 słowow|$2 słowje|$2 słowa|$2 słowow}})',
'search-result-score'              => 'Relewanca: $1 %',
'search-redirect'                  => '(pśesměrowanje $1)',
'search-section'                   => '(sekcija $1)',
'search-suggest'                   => 'Měnijašo: $1?',
'search-interwiki-caption'         => 'Sotšine projekty',
'search-interwiki-default'         => '$1 wuslědki:',
'search-interwiki-more'            => '(wěcej)',
'search-mwsuggest-enabled'         => 'z naraźenjami',
'search-mwsuggest-disabled'        => 'žedne naraźenja',
'search-relatedarticle'            => 'swójźbne',
'mwsuggest-disable'                => 'Naraźenja pśez AJAX znjemóžniś',
'searchrelated'                    => 'swójźbne',
'searchall'                        => 'wše',
'showingresults'                   => "How {{PLURAL:|jo '''1''' wuslědk|stej '''$1''' wuslědka|su '''$1''' wuslědki}} wót cysła '''$2'''.",
'showingresultsnum'                => "How {{PLURAL:$3|jo '''1''' wuslědk|stej '''$3''' wuslědka|su '''$3''' wuslědki}} wót cysła '''$2'''.",
'showingresultstotal'              => "{{PLURAL:$4|Slědujo wuslědk '''$1''' z '''$3'''|Slědujotej wuslědka '''$1 – $2''' z '''$3'''|Slěduju wuslědki '''$1 – $2''' z '''$3'''|Slědujo wuslědkow '''$1 – $2''' z '''$3'''}}",
'nonefound'                        => "'''Pokazka''': Jano někótare mjenjowe rumy se standarnje pytaju. Wopytaj za swóje wótpšašanje prefiks ''all:'' wužywać, aby cełe wopśimjeśe pytał (inkluziwnje diskusijnych bokow, pśedłogi atd.) abo wužyj póžedany mjenjowy rum ako prefiks.",
'search-nonefound'                 => 'Njejsu se wuslědki namakali, kótarež wótpowěduju napšašowanjeju.',
'powersearch'                      => 'Rozšyrjone pytanje',
'powersearch-legend'               => 'Rozšyrjone pytanje',
'powersearch-ns'                   => 'W mjenjowych rumach pytaś:',
'powersearch-redir'                => 'Dalejpósrědnjenja nalistowaś',
'powersearch-field'                => 'Pytaś za:',
'search-external'                  => 'Eksterne pytanje',
'searchdisabled'                   => 'Pytanje we {{SITENAME}} jo se deaktiwěrowało. Tak dłujko móžoš w googlu pytaś. Pšosym wobmysli, až móžo pytanski indeks za {{SITENAME}} njeaktualny byś.',

# Preferences page
'preferences'               => 'Nastajenja',
'mypreferences'             => 'móje nastajenja',
'prefs-edits'               => 'Licba wobźěłanjow:',
'prefsnologin'              => 'Njejsy pśizjawjony',
'prefsnologintext'          => 'Musyš se <span class="plainlinks">[{{fullurl:Special:UserLogin|returnto=$1}} pśizjawiś]</span>, aby mógał swóje nastajenja změniś.',
'prefsreset'                => 'Nastajenja su ze składa se wótnowili. Twóje změny njejsu se składowali.',
'qbsettings'                => 'Bocna lejstwa',
'qbsettings-none'           => 'Žedne',
'qbsettings-fixedleft'      => 'nalěwo fiksěrowane',
'qbsettings-fixedright'     => 'napšawo fiksěrowane',
'qbsettings-floatingleft'   => 'nalěwo se znosujuce',
'qbsettings-floatingright'  => 'napšawo se znosujuce',
'changepassword'            => 'Šćitne gronidło změniś',
'skin'                      => 'Šat',
'skin-preview'              => 'Pśeglěd',
'math'                      => 'Math',
'dateformat'                => 'Format datuma',
'datedefault'               => 'Standard',
'datetime'                  => 'Datum a cas',
'math_failure'              => 'Zmólka',
'math_unknown_error'        => 'njeznata zmólka',
'math_unknown_function'     => 'njeznata funkcija',
'math_lexing_error'         => 'leksikaliska zmólka',
'math_syntax_error'         => 'syntaktiska zmólka',
'math_image_error'          => 'PNG-konwertěrowanje njejo se raźiło. Glědaj, lic su latex, dvips gs abo konwertěruj pšawje instalěrowane.',
'math_bad_tmpdir'           => 'Njejo móžno temporarny zapisk za matematiske formule załožyś resp. do njogo pisaś.',
'math_bad_output'           => 'Njejo móžno celowy zapisk za matematiske formule załožyś resp. do njogo pisaś.',
'math_notexvc'              => 'Program texvc felujo. Pšosym glědaj do math/README.',
'prefs-personal'            => 'Wužywarski profil',
'prefs-rc'                  => 'Aktualne změny',
'prefs-watchlist'           => 'Wobglědowańka',
'prefs-watchlist-days'      => 'Licba dnjow, kenž maju se we wobglědowańkach pokazaś:',
'prefs-watchlist-days-max'  => '(maksimalnje 7 dnjow)',
'prefs-watchlist-edits'     => 'Maksimalna licba změnow, kenž maju w rozšyrjonej lisćinje wobglědowańkow se pokazaś:',
'prefs-watchlist-edits-max' => '(maksimalna licba: 1000)',
'prefs-misc'                => 'Wšake nastajenja',
'prefs-resetpass'           => 'Gronidło změniś',
'saveprefs'                 => 'Składowaś',
'resetprefs'                => 'Njeskłaźone změny zachyśiś',
'textboxsize'               => 'Wobźěłaś',
'prefs-edit-boxsize'        => 'Wjelikosć wobźěłowańskego wokna',
'rows'                      => 'Rědki:',
'columns'                   => 'Słupy:',
'searchresultshead'         => 'Pytaś',
'resultsperpage'            => 'Wuslědki na bok:',
'contextlines'              => 'Rědki na wuslědk:',
'contextchars'              => 'Znamuška na rědku:',
'stub-threshold'            => 'Formatěrowanje  <a href="#" class="stub">wótkaza na zarodk</a> (w bytach):',
'recentchangesdays'         => 'Licba dnjow, kenž se pokazuju w "slědnych změnach":',
'recentchangesdays-max'     => '(maksimalnje $1 {{PLURAL:$1|źeń|dnja|dny|dnjow}})',
'recentchangescount'        => 'Licba změnow w „Aktualne změny“, stawiznach boka a w protokolach pó standarźe:',
'savedprefs'                => 'Twóje nastajenja su se składowali.',
'timezonelegend'            => 'Casowa cona',
'timezonetext'              => '¹Pódaj licbu góźinow, kótarež laže mjazy twójeju casoweju conu a UTC.',
'localtime'                 => 'Městny cas:',
'timezoneselect'            => 'Casowa cona',
'timezoneuseserverdefault'  => 'Standard serwera wužywaś',
'timezoneuseoffset'         => 'Drugi (pódaj wótchylenje)',
'timezoneoffset'            => 'Rozdźěl¹:',
'servertime'                => 'Cas serwera:',
'guesstimezone'             => 'Z browsera pśewześ',
'allowemail'                => 'Dostawanje e-mailow drugich wužywarjow zmóžniś.',
'prefs-searchoptions'       => 'Pytańske opcije',
'prefs-namespaces'          => 'Mjenjowe rumy',
'defaultns'                 => 'Standardnje ma se w toś tych mjenjowych rumach pytaś:',
'default'                   => 'Standard',
'files'                     => 'Dataje',

# User rights
'userrights'                  => 'Zastojanje wužywarskich pšawow', # Not used as normal message but as header for the special page itself
'userrights-lookup-user'      => 'Wužywarske kupki zastojaś',
'userrights-user-editname'    => 'Wužywarske mě:',
'editusergroup'               => 'Wužywarske kupki wobźěłaś.',
'editinguser'                 => "Změnjaju se wužywarske pšawa wužywarja '''[[User:$1|$1]]''' ([[User talk:$1|{{int:talkpagelinktext}}]]{{int:pipe-separator}}[[Special:Contributions/$1|{{int:contribslink}}]])",
'userrights-editusergroup'    => 'Pšawa wužywarskich kupkow wobźěłaś',
'saveusergroups'              => 'Wužywarske kupki składowaś',
'userrights-groupsmember'     => 'Cłonk kupki:',
'userrights-groups-help'      => 'Móžoš kupki, w kótarychž wužywaŕ jo, změniś:
* Markěrowany kašćik wóznamjenijo, až wužywaŕ jo w toś tej kupce.
* Njemarkěrowany kašćik woznamjenijo, až wužywaŕ njejo w toś tej kupce.
* * pódawa, až njamóžoš kupku wótwónoźeś, gaž sy ju pśidał abo nawopak.',
'userrights-reason'           => 'Pśicyna změny:',
'userrights-no-interwiki'     => 'Njamaš pšawo wužywarske pšawa w drugich wikijach změniś.',
'userrights-nodatabase'       => 'Datowa banka $1 njeeksistěrujo abo njejo lokalna.',
'userrights-nologin'          => 'Musyš se z administratorowym kontom [[Special:UserLogin|pśizjawiś]], aby wužywarske pšawa změnił.',
'userrights-notallowed'       => 'Twóje konto njama pšawa, aby wužywarske pšawa změniło.',
'userrights-changeable-col'   => 'Kupki, kótarež móžoš změniś',
'userrights-unchangeable-col' => 'Kupki, kótarež njamóžoš změniś',

# Groups
'group'               => 'Kupka:',
'group-user'          => 'Wužywarje',
'group-autoconfirmed' => 'Wobkšuśone wužywarje',
'group-bot'           => 'awtomatiske programy (boty)',
'group-sysop'         => 'Administratory',
'group-bureaucrat'    => 'Běrokraty',
'group-suppress'      => 'Doglědowanja',
'group-all'           => '(wše)',

'group-user-member'          => 'Wužywaŕ',
'group-autoconfirmed-member' => 'Wobkšuśony wužywaŕ',
'group-bot-member'           => 'awtomatiski program (bot)',
'group-sysop-member'         => 'administrator',
'group-bureaucrat-member'    => 'Běrokrat',
'group-suppress-member'      => 'Doglědowanje',

'grouppage-user'          => '{{ns:project}}:Wužywarje',
'grouppage-autoconfirmed' => '{{ns:project}}:Awtomatiski wobkšuśone wužywarje',
'grouppage-bot'           => '{{ns:project}}:awtomatiske programy (boty)',
'grouppage-sysop'         => '{{ns:project}}:Administratory',
'grouppage-bureaucrat'    => '{{ns:project}}:Běrokraty',
'grouppage-suppress'      => '{{ns:project}}:Doglědowanje',

# Rights
'right-read'                 => 'cytaś boki',
'right-edit'                 => 'wobźěłaś boki',
'right-createpage'           => 'Boki napóraś (mimo diskusijnych bokow)',
'right-createtalk'           => 'natwóriś diskusijny bok',
'right-createaccount'        => 'Nowe wužywarske konta załožyś',
'right-minoredit'            => 'Změny ako snadne markěrowaś',
'right-move'                 => 'pśesunuś boki',
'right-move-subpages'        => 'Boki ze swójimi pódbokami pśesunuś',
'right-move-rootuserpages'   => 'Głowne wužywarske boki pśesunuś',
'right-movefile'             => 'Dataje pśesunuś',
'right-suppressredirect'     => 'Pśi pśesunjenju žedne dalejpósrědnjenje ze starego mjenja napóraś',
'right-upload'               => 'lódowaś dataje',
'right-reupload'             => 'Eksistěrujucu dataju pśepisaś',
'right-reupload-own'         => 'Dataju nagratu wót togo samogo wužywarja pśepisaś',
'right-reupload-shared'      => 'Dataje w zgromadnje wužywanem repozitoriju lokalnje pśepisaś',
'right-upload_by_url'        => 'Dataju z URL-adrese nagraś',
'right-purge'                => 'Sedłowy cache za bok bźez wobkšuśenja prozniś',
'right-autoconfirmed'        => 'Połšćitane boki wobźěłaś',
'right-bot'                  => 'Wobchadanje ako awtomatiski proces',
'right-nominornewtalk'       => 'Snadne změny na diskusijnych bokach njedowjedu k pokazanjeju "Nowe powěsći"',
'right-apihighlimits'        => 'Wuše limity w API-wótpšašanjach wužywaś',
'right-writeapi'             => 'writeAPI wužywaś',
'right-delete'               => 'lašowaś boki',
'right-bigdelete'            => 'lašowaś boki, kótarež maju wjelike stawizny',
'right-deleterevision'       => 'Specifiske boki lašowaś a wótnowiś',
'right-deletedhistory'       => 'Wulašowane wersiji w stawiznach se bśez pśisłušnego teksta wobglědaś',
'right-browsearchive'        => 'Wulašowane boki pytaś',
'right-undelete'             => 'Bok wótnowiś',
'right-suppressrevision'     => 'Wersije, kótarež su pśed admibnistratorami schowane, pśeglědaś a wótnowiś',
'right-suppressionlog'       => 'Priwatne protokole se wobglědowaś',
'right-block'                => 'Drugim wužywarjam wobźěłowanje zawoboraś',
'right-blockemail'           => 'Wužywarjoju słanje emailow zawoboraś',
'right-hideuser'             => 'Wužywarske mě blokěrowaś a schowaś',
'right-ipblock-exempt'       => 'Blokěrowanja IP, awtomatiske blokěrowanja a blokěrowanja wobcerkow se wobinuś',
'right-proxyunbannable'      => 'Awtomatiske blokěrowanje proksyjow se wobinuś',
'right-protect'              => 'Šćitowe schójźeńki změniś a šćitane boki wobźěłaś',
'right-editprotected'        => 'Šćitane boki wobźěłaś (bśez kaskadowego šćita)',
'right-editinterface'        => 'Wužywański pówjerch wobźěłaś',
'right-editusercssjs'        => 'Dataje CSS a JS drugich wužywarjow wobźěłaś',
'right-rollback'             => 'Spěšne anulěrowanje změnow slědnego wužywarja, kótaryž jo dany bok wobźěłał',
'right-markbotedits'         => 'Spěšnje anulěrowane změny ako botowe změny markěrowaś',
'right-noratelimit'          => 'Pśez žedne limity wobgranicowany',
'right-import'               => 'Boki z drugich wikijow importowaś',
'right-importupload'         => 'Boki pśez nagraśe datajow importowaś',
'right-patrol'               => 'Změny ako doglědowane markěrowaś',
'right-autopatrol'           => 'Swójske změny awtomatiski ako doglědowane markěrowane',
'right-patrolmarks'          => 'Kontrolne wobznamjenja w aktualnych změnach',
'right-unwatchedpages'       => 'Lisćinu njewobglědowanych bokow woglědaś',
'right-trackback'            => 'Trackback wótpósłaś',
'right-mergehistory'         => 'Stawizny wersijow bokow zjadnośiś',
'right-userrights'           => 'Wšykne wužywarske pšawa wobźěłaś',
'right-userrights-interwiki' => 'Wužywarske pšawa w drugich wikijach wobźěłaś',
'right-siteadmin'            => 'Datowu banku zastajiś a zastajenje wótpóraś',

# User rights log
'rightslog'      => 'Protokol wužywarskich pšawow',
'rightslogtext'  => 'To jo protokol wužywarskich pšawow.',
'rightslogentry' => 'Pśisłušnosć ku kupce jo se za „[[$1]]“ změniła wót „$2“ na „$3“.',
'rightsnone'     => '(nic)',

# Associated actions - in the sentence "You do not have permission to X"
'action-read'                 => 'toś ten bok cytaś',
'action-edit'                 => 'toś ten bok wobźěłaś',
'action-createpage'           => 'Boki napóraś',
'action-createtalk'           => 'Diskusijne boki napóraś',
'action-createaccount'        => 'Toś to wužywarske konto napóraś',
'action-minoredit'            => 'toś tu změnu ako snadnu markěrowaś',
'action-move'                 => 'toś ten bok pśesunuś',
'action-move-subpages'        => 'toś ten bok a jogo pódboki pśesunuś',
'action-move-rootuserpages'   => 'głowne wužywarske boki pśesunuś',
'action-movefile'             => 'Toś tu dataju pśesunuś',
'action-upload'               => 'toś tu dataju nagraś',
'action-reupload'             => 'toś tu eksistěrujucu dataju pśepisaś',
'action-reupload-shared'      => 'toś tu dataju w zgroamdnem repozitoriumje pśepisaś',
'action-upload_by_url'        => 'toś tu dataju z webadrese (URL) nagraś',
'action-writeapi'             => 'API za pisanje wužywaś',
'action-delete'               => 'Toś ten bok lasowaś',
'action-deleterevision'       => 'Toś tu wersiju lašowaś',
'action-deletedhistory'       => 'Stawizny wulašowanjow toś togo boka zwobrazniś',
'action-browsearchive'        => 'wulašowane boki pytaś',
'action-undelete'             => 'Toś ten bok wótnowiś',
'action-suppressrevision'     => 'schowanu wersiju pśeglědaś a wótnowiś',
'action-suppressionlog'       => 'toś ten priwatny protokol zwobrazniś',
'action-block'                => 'Toś tomu wužiwarjeju wobźěłowanje zawoboraś',
'action-protect'              => 'Šćitowe stopnje za toś ten bok změniś',
'action-import'               => 'toś ten bok z drugego wikija importěrowaś',
'action-importupload'         => 'toś ten bok z datajowego nagraśa importěrowaś',
'action-patrol'               => 'změny drugich wužywarjow ako doglědowane markěrowaś',
'action-autopatrol'           => 'twóju změnu ako doglědowanu markěrowaś daś',
'action-unwatchedpages'       => 'lisćinu njewobglědowanych bokow zwobrazniś',
'action-trackback'            => 'trackback pósłaś',
'action-mergehistory'         => 'Stawizny toś togo boka zjadnośiś',
'action-userrights'           => 'wše wužywarske pšawa wobźěłaś',
'action-userrights-interwiki' => 'wužywarske pšawa wužywarjow w drugich wikijach wobźěłaś',
'action-siteadmin'            => 'datowu banku zastajiś abo wótworiś',

# Recent changes
'nchanges'                          => '$1 {{PLURAL:$1|změna|změnje|změny}}',
'recentchanges'                     => 'Aktualne změny',
'recentchanges-legend'              => 'Opcije aktualnych změnow',
'recentchangestext'                 => "How móžoš slědne změny we '''{{GRAMMAR:lokatiw|{{SITENAME}}}}''' slědowaś.",
'recentchanges-feed-description'    => 'Slěduj z toś tym zapódaśim nejaktualnjejše změny we {{GRAMMAR:lokatiw|{{SITENAME}}}}.',
'rcnote'                            => "Dołojce {{PLURAL:$1|jo '''1''' změna|stej slědnej '''$1''' změnje|su slědne '''$1''' změny}} w {{PLURAL:$2|slědnem dnju|slědnyma '''$2''' dnjoma|slědnych '''$2''' dnjach}}, staw wót $4, $5.",
'rcnotefrom'                        => "Dołojce pokazuju se změny wót '''$2''' (maks. '''$1''' zapisow).",
'rclistfrom'                        => 'Nowe změny wót $1 pokazaś.',
'rcshowhideminor'                   => 'Snadne změny $1',
'rcshowhidebots'                    => 'awtomatiske programy (boty) $1',
'rcshowhideliu'                     => 'pśizjawjone wužywarje $1',
'rcshowhideanons'                   => 'anonymne wužywarje $1',
'rcshowhidepatr'                    => 'kontrolěrowane změny $1',
'rcshowhidemine'                    => 'móje pśinoski $1',
'rclinks'                           => 'Slědne $1 změny slědnych $2 dnjow pokazaś<br />$3',
'diff'                              => 'rozdźěl',
'hist'                              => 'wersije',
'hide'                              => 'schowaś',
'show'                              => 'pokazaś',
'minoreditletter'                   => 'S',
'newpageletter'                     => 'N',
'boteditletter'                     => 'B',
'number_of_watching_users_pageview' => '[$1 {{PLURAL:$1|wobglědowaŕ|wobglědowarja|wobglědowarje}}]',
'rc_categories'                     => 'Jano boki z kategorijow (źělone z pomocu „|“):',
'rc_categories_any'                 => 'wše',
'newsectionsummary'                 => 'Nowy wótrězk /* $1 */',
'rc-enhanced-expand'                => 'Drobnosći pokazaś (pomina se JavaScript)',
'rc-enhanced-hide'                  => 'Drobnosći schowaś',

# Recent changes linked
'recentchangeslinked'          => 'Změny w zwězanych bokach',
'recentchangeslinked-title'    => 'Změny na bokach, kótarež su z „$1“ zalinkowane',
'recentchangeslinked-noresult' => 'Zalinkowane boki njejsu we wuzwólonem casu se změnili.',
'recentchangeslinked-summary'  => "To jo lisćina slědnych změnow, kótarež buchu na wótkazanych bokach cynjone (resp. pśi wěstych kategorijach na cłonkach kategorije).
Boki na [[Special:Watchlist|wobglědowańce]] su '''tucne'''.",
'recentchangeslinked-page'     => 'mě boka:',
'recentchangeslinked-to'       => 'Změny pokazaś, kótarež město togo na dany bok wótkazuju.',

# Upload
'upload'                      => 'Dataju pósłaś',
'uploadbtn'                   => 'Dataju pósłaś',
'reupload'                    => 'Dataju hyšći raz pósłaś.',
'reuploaddesc'                => 'Upload pśetergnuś a slědk k uploadowemu formularoju',
'uploadnologin'               => 'Njepśizjawjony(a)',
'uploadnologintext'           => 'Dejš se [[Special:UserLogin|pśizjawiś]], aby mógał dataje uploadowaś.',
'upload_directory_missing'    => 'Nagrawański zapis ($1) felujo a njejo se pśez webserwer napóraś dał.',
'upload_directory_read_only'  => 'Seśowy serwer njamóžo do uploadowego zapisa ($1) pisaś.',
'uploaderror'                 => 'Zmólka pśi uploadowanju',
'uploadtext'                  => "Wužyj toś ten formular za nagraśe nowych datajow.

Źi na [[Special:FileList|lisćinu nagratych datajow]], aby mógł južo nagrate dataje se wobglědaś abo pytaś, nagraśa protokolěruju se w [[Special:Log/upload|protokolu nagraśow]], wulašowanja w [[Special:Log/upload|protokolu wulašowanjow]].

Aby dataju do boka zapśimjeł, wužyj wótkaz slědujuceje formy
* '''<tt><nowiki>[[</nowiki>{{ns:file}}<nowiki>:Dataja.jpg]]</nowiki></tt>''', aby wužywał połnu wersiju dataje
* '''<tt><nowiki>[[</nowiki>{{ns:file}}<nowiki>:Dataja.png|200px|thumb|left|alternatiwny tekst]]</nowiki></tt>''', aby wužywał wobraz we wjelikosću 200 pikselow w kašćiku na lěwej kšomje z alternatiwnym tekstom ako wopisanje
* '''<tt><nowiki>[[</nowiki>{{ns:media}}<nowiki>:Dataja.ogg]]</nowiki></tt>''', aby direktnje na dataju wótkazował, bźez togo až dataja se zwobraznijo.",
'upload-permitted'            => 'Dowolone datajowe typy: $1.',
'upload-preferred'            => 'Preferěrowane datajowe typy: $1.',
'upload-prohibited'           => 'Njedowolone datajowe typy: $1.',
'uploadlog'                   => 'datajowy protokol',
'uploadlogpage'               => 'Datajowy protokol',
'uploadlogpagetext'           => 'Dołojce jo lisćina nejnowšych datajowych nagraśow.
Glědaj [[Special:NewFiles|galeriju nowych datajow]] za wizuelny pśeglěd.',
'filename'                    => 'Mě dataje',
'filedesc'                    => 'Zespominanje',
'fileuploadsummary'           => 'Zespominanje:',
'filestatus'                  => 'Status copyrighta:',
'filesource'                  => 'Žrědło:',
'uploadedfiles'               => 'Uploadowane dataje',
'ignorewarning'               => 'Warnowanje ignorěrowaś a dataju składowaś',
'ignorewarnings'              => 'Wše warnowanja ignorěrowaś',
'minlength1'                  => 'Mjenja datajow muse wopśimjeś nanejmjenjej jaden pismik.',
'illegalfilename'             => 'Datajowe mě „$1“ wopśimjejo njedowólone znamuška. Pšosym pśemjeni dataju a wopytaj ju wótnowotki uploadowaś.',
'badfilename'                 => 'Mě dataje jo se změniło na „$1“.',
'filetype-badmime'            => 'Dataje z MIME-typom „$1“ njesměju se uploadowaś.',
'filetype-bad-ie-mime'        => 'Toś ta dataja njedajo se nagraś, dokulaž Internet Explorer by ju ako "$1" interpretěrował, kótaryž jo njedowólony a potencielnje tšachotny datajowy typ.',
'filetype-unwanted-type'      => "'''„.$1“''' jo njewitany datajowy typ. 
{{PLURAL:$3|Dowólony datajowy typ jo|Dowólonej datajowej typa stej|Dowólene datajowe typy su}}: $2.",
'filetype-banned-type'        => "'''„.$1“''' jo njedowólony datajowy typ. 
{{PLURAL:$3|Dowólony datajowy typ jo|Dowólenej datajowej typa stej|Dowólone datajowe typy su}} $2.",
'filetype-missing'            => 'Dataja njama žedno rozšyrjenje (na pś. „.jpg“).',
'large-file'                  => 'Pó móžnosći njedejała dataja wětša byś ako $1. Toś ta dataja jo $2 wjelika.',
'largefileserver'             => 'Dataja jo wětša ako serwer dopušćijo.',
'emptyfile'                   => 'Dataja jo prozna. Pśicyna togo móžo byś zmólka w mjenju dataje. Kontrolěruj pšosym, lic coš dataju napšawdu uploadowaś.',
'fileexists'                  => "Dataja z toś tym mjenim južo eksistěrujo. Tłocyš-lic na \"Dataju składowaś\", ga se dataja pśepišo. Pšosym kontrolěruj '''<tt>\$1</tt>''', gaž njejsy se kradu wěsty.",
'filepageexists'              => "Wopisański bok za toś tu dataju bu južo na '''<tt>$1</tt>''' napórany, ale dataja z toś tym mjenim njeeksistěrujo. Zespominanje, kótarež sy zapódał, se na wopisańskem boku njezjawijo. Aby se twóje zespominanje tam zjawiło, dejš jen manuelnje wobźěłaś.",
'fileexists-extension'        => "Eksistěrujo južo dataja z pódobnym mjenim:<br />
Mě dataje, kótaraž dej se uploadowaś: '''<tt>$1</tt>'''<br />
Mě eksistěrujuceje dataje: '''<tt>$2</tt>'''<br />
Wuzwól nowe mě, jolic až sy se wěsty, až dataji njejstej identiskej.",
'fileexists-thumb'            => "<center>'''Eksistěrujucy wobraz'''</center>",
'fileexists-thumbnail-yes'    => "Zazdaśim ma wobraz reducěrowanu wjelikosć ''(thumbnail)''. Kontrolěruj pšosym dataju '''<tt>$1</tt>'''.<br />
Jadna-lic se wó wobraz w originalnej wjelikosći, pón njejo notne, separatny pśeglědowy wobraz uploadowaś.",
'file-thumbnail-no'           => "Mě dataje zachopijo z '''<tt>$1</tt>'''. Zda se, až to jo wobraz z reducěrowaneju wjelikosću. ''(thumbnail)''.
Jolic maš toś ten wobraz w połnem rozeznaśu, nagraj jen, howac změń pšosym mě dataje.",
'fileexists-forbidden'        => 'Dataja z toś tym mjenim južo eksistěrujo a njedajo se pśepisaś. Jolic coš hyšći swóju dataju nagraś, źi pšosym slědk a wuž nowe mě. [[File:$1|thumb|center|$1]]',
'fileexists-shared-forbidden' => 'Dataja z toś tym mjenim južo eksistěrujo w zgromadnej chowarni. Jolic hyšći coš nagraś swóju dataju, źi pšosym slědk a wužyj nowe mě.
[[File:$1|thumb|center|$1]]',
'file-exists-duplicate'       => 'Toś ta dataja jo duplikat {{PLURAL:$1|slědujuceje dataje|slědujuceju datajow|slědujucych datajow|slědujucych datajow}}:',
'file-deleted-duplicate'      => 'Dataja, kótaraž jo identiska z toś teju dataju ([[$1]]) jo se pjerwjej wulašowała. Ty měł stawizny wulašowanja toś teje dataje pśeglědaś, pjerwjej až pokšacujoš z jeje zasejnagrawanjom.',
'successfulupload'            => 'Upload jo był wuspěšny.',
'uploadwarning'               => 'Warnowanje',
'savefile'                    => 'Dataju składowaś',
'uploadedimage'               => 'Dataja "[[$1]]" jo uploadowana.',
'overwroteimage'              => 'Nowa wersija "[[$1]]" jo se uploadowała.',
'uploaddisabled'              => 'Uploadowanje jo se znjemóžniło.',
'uploaddisabledtext'          => 'Nagraśa datajow su znjemóžnjone.',
'uploadscripted'              => 'Toś ta dataja wopśimjejo HTML abo script code, kótaryž móžo wót browsera se zamólnje wuwjasć.',
'uploadcorrupt'               => 'Dataja jo skóńcowana abo ma njekorektnu kóńcowku. Pšosym kontrolěruj dataju a uploaduj hyšći raz.',
'uploadvirus'                 => 'Toś ta dataja ma wirus! Nadrobnosći: $1',
'sourcefilename'              => 'Mě žrědłoweje dataje:',
'destfilename'                => 'Celowe mě:',
'upload-maxfilesize'          => 'Maksimalna datajowa wjelikosć: $1',
'watchthisupload'             => 'Toś tu dataju wobglědowaś',
'filewasdeleted'              => 'Dataja z toś tym mjenim jo była južo raz uploadowana a mjaztym zasej wulašowana. Pšosym kontrolěruj pjerwjej $1, nježli až dataju napšawdu składujoš.',
'upload-wasdeleted'           => "'''Glědaj: Nagrawaš dataju, kótaraž jo južo raz se wulašowała.'''

Pšosym kontrolěruj, lic wótpowědujo nowe nagraśe směrnicam.
Aby se mógał informěrowaś jo how protokol z pśicynu wulašowanja:",
'filename-bad-prefix'         => "Mě dataje, kótaruž uploadujoš, zachopijo na '''„$1“'''. Take mě jo wót digitalneje kamery pśedpódane a toś wjele njewugroni. Pšosym pómjeni dataju tak, aby mě wěcej wó jeje wopśimjeśu wugroniło.",
'filename-prefix-blacklist'   => ' #<!-- Njezměń nic na toś tej rědce! --> <pre>
# Syntaksa jo slědujuca:
#   * Wšykno wót "#" znamuška až ku kóńcoju rědki jo komentar.
#   * Kužda njeprozna smužka jo prefiks za typiske datajowe mjenja, kótarež se awtomatiski wót digitalnych kamerow dodawaju.
CIMG # Casio
DSC_ # Nikon
DSCF # Fuji
DSCN # Nikon
DUW # some mobil phones
IMG # generic
JD # Jenoptik
MGP # Pentax
PICT # misc.
 #</pre> <!-- Njezměń nic na toś tej rědce! -->',

'upload-proto-error'      => 'Njekorektny protokol',
'upload-proto-error-text' => 'URL musy zachopiś z <code>http://</code> abo <code>ftp://</code>.',
'upload-file-error'       => 'Interna zmólka',
'upload-file-error-text'  => 'Pśi napóranju temporarneje dataje na serwerje jo nastała interna zmólka. Pšosym staj se ze [[Special:ListUsers/sysop|systemowym administratorom]] do zwiska.',
'upload-misc-error'       => 'Njeznata zmólka pśi uploadowanju.',
'upload-misc-error-text'  => 'Pśi nagrawanju jo nastała njeznata zmólka. Kontrolěruj pšosym, lěc URL jo płaśiwy a pśistupny a wopytaj hyšći raz. Jolic problem dalej eksistěrujo, staj se z [[Special:ListUsers/sysop|administratorom]] do zwiska.',

# Some likely curl errors. More could be added from <http://curl.haxx.se/libcurl/c/libcurl-errors.html>
'upload-curl-error6'       => 'URL njejo pśistupna.',
'upload-curl-error6-text'  => 'Pódana URL njejo pśistupna. Pśeglěduj URL na zmólki a kontrolěruj online-status boka.',
'upload-curl-error28'      => 'Pśi uploadowanju jo cas se pśekšocył.',
'upload-curl-error28-text' => 'Bok pśedłujko njejo wótegronił. Kontrolěruj, lic jo bok online, pócakaj wokognuśe a wopytaj pón hyšći raz. Móžo byś zmysłapołne, w drugem casu hyšći raz proběrowaś.',

'license'            => 'Licenca:',
'nolicense'          => 'Nic njejo wuzwólone.',
'license-nopreview'  => '(Pśeglěd njejo móžny.)',
'upload_source_url'  => ' (płaśeca, zjawnje pśistupna URL)',
'upload_source_file' => ' (dataja na twójom kompjuterje)',

# Special:ListFiles
'listfiles-summary'     => 'Toś ten specialny bok nalicyjo wšykne uploadowane dataje. Normalnje pokazuje se te dataje, ako su slědne se uploadowali, ako prědne w lisćinje. Tłocenje na napise špaltow změnijo sortěrowanje.',
'listfiles_search_for'  => 'Za medijowym mjenim pytaś:',
'imgfile'               => 'dataja',
'listfiles'             => 'Lisćina datajow',
'listfiles_date'        => 'datum',
'listfiles_name'        => 'mě dataje',
'listfiles_user'        => 'wužywaŕ',
'listfiles_size'        => 'Wjelikosć (byte)',
'listfiles_description' => 'Zespominanje',
'listfiles_count'       => 'Wersije',

# File description page
'filehist'                       => 'Stawizny dataje',
'filehist-help'                  => 'Tłoc na datum/cas aby tencasna wersija se lodowała.',
'filehist-deleteall'             => 'Wšykno wulašowaś',
'filehist-deleteone'             => 'Lašowaś',
'filehist-revert'                => 'Slědk wześ',
'filehist-current'               => 'něntejšny',
'filehist-datetime'              => 'datum/cas',
'filehist-thumb'                 => 'Pśeglědowy wobraz',
'filehist-thumbtext'             => 'Pśeglědowy wobraz za wersiju wót $1',
'filehist-nothumb'               => 'Žeden pśeglědowy wobraz',
'filehist-user'                  => 'Wužywaŕ',
'filehist-dimensions'            => 'rozměry',
'filehist-filesize'              => 'Wjelikosć dataje',
'filehist-comment'               => 'Komentar',
'imagelinks'                     => 'Datajowe wótkaze',
'linkstoimage'                   => '{{PLURAL:$1|Slědujucy bok wótkazujo|Slědujucej $1 boka wótkazujotej|Slědujuce $1 boki wótkazuju|Slědujucych $1 bokow wótkazujo}} na toś tu dataju:',
'linkstoimage-more'              => 'Wěcej nježli $1 {{PLURAL:$1|bok wótkazujo|boka wótkazujotej|boki wótkazuju|bokow wótkazujo}} na toś tu dataju.
Slědujuca lisćina pokazujo jano {{PLURAL:$1|prědny wótkaz|prědnej $1 wótkaza|prědne $1 wótkaze|prědnych $1 wótkazow}} k toś tej dataji.
[[Special:WhatLinksHere/$2|Dopołna lisćina]] stoj k dispoziciji.',
'nolinkstoimage'                 => 'Žedne boki njewótkazuju na toś tu dataju.',
'morelinkstoimage'               => '[[Special:WhatLinksHere/$1|Dalšne wótkazy]] k toś tej dataji wobglědaś.',
'redirectstofile'                => '{{PLURAL:$1|Slědujuca dataja dalej pósrědnja|Slědujucej $1 dataji dalej pósrědnjatej|slědujuce $1 dataje dalej póšrědnjaju|Slědujucych $1 datajow dalej pósrědnja}} k toś tej dataji:',
'duplicatesoffile'               => '{{PLURAL:$1|Slědujuca dataja jo duplikat|Slědujucej $1 dataji stej duplikata|Slědujuce dataje $1 su duplikaty|Slědujucych $1 datajow jo duplikaty}} toś teje dataje ([[Special:FileDuplicateSearch/$2|dalšne drobnostki]])::',
'sharedupload'                   => 'Toś ta dataja se gromaźe wužywa - snaź teke w drugich projektach.',
'shareduploadwiki'               => 'Za dalšne informacije glědaj $1.',
'shareduploadwiki-desc'          => 'Wopisanje na $1 se dołojce pókazujo.',
'shareduploadwiki-linktext'      => 'boku wopisanja dataje',
'shareduploadduplicate'          => 'Toś ta dataja jo duplikat $1 z gromaźe wužywaneje chowarnje.',
'shareduploadduplicate-linktext' => 'druga dataja',
'shareduploadconflict'           => 'Toś ta dataja ma to same mě kaž $1 z gromaźe wužywaneje chowarnje.',
'shareduploadconflict-linktext'  => 'druga dataja',
'noimage'                        => 'Dataja z takim mjenim njeeksistěrujo, ale móžoš ju $1.',
'noimage-linktext'               => 'nagraś',
'uploadnewversion-linktext'      => 'Uploaduj nowu wersiju toś teje dataje.',
'imagepage-searchdupe'           => 'Za duplikatnymi datajami pytaś',

# File reversion
'filerevert'                => 'Slědk wześ $1',
'filerevert-legend'         => 'Dataju nawrośiś',
'filerevert-intro'          => "Nawrośijoš dataju '''[[Media:$1|$1]]''' na [$4 wersiju wót $2, $3 góź.].",
'filerevert-comment'        => 'Komentar:',
'filerevert-defaultcomment' => 'Nawrośona na wersiju wót $1, $2 góź.',
'filerevert-submit'         => 'Slědk wześ',
'filerevert-success'        => "'''[[Media:$1|$1]]''' jo se nawrośiło na [$4 wersiju wót $2, $3 góź.].",
'filerevert-badversion'     => 'Za pódany cas njeeksistěrujo žedna wersija dataje.',

# File deletion
'filedelete'                  => 'Wulašowaś $1',
'filedelete-legend'           => 'Wulašowaś dataje',
'filedelete-intro'            => "Lašujoš dataju '''[[Media:$1|$1]]''' gromaźe z jeje cełymi stawiznami.",
'filedelete-intro-old'        => "Wulašujoš [$4 wersiju wót $2, $3 góź.] dataje '''„[[Media:$1|$1]]“'''.",
'filedelete-comment'          => 'Komentar:',
'filedelete-submit'           => 'Wulašowaś',
'filedelete-success'          => "'''$1''' wulašowane.",
'filedelete-success-old'      => "Wersija wót $2, $3 góź. dataje '''[[Media:$1|$1]]''' jo se wulašowała.",
'filedelete-nofile'           => "'''$1''' njeekistěrujo.",
'filedelete-nofile-old'       => "Njejo archiwowana wersija '''$1''' z pódanymi atributami.",
'filedelete-otherreason'      => 'Druga/pśidatna pśicyna:',
'filedelete-reason-otherlist' => 'Druga pśicyna',
'filedelete-reason-dropdown'  => '*Powšykne pśicyny za lašowanja
** Pśekśiwjenje stworiśelskego pšawa
** Dwójna dataja',
'filedelete-edit-reasonlist'  => 'Pśicyny za lašowanje wobźěłaś',

# MIME search
'mimesearch'         => 'MIME-typ pytaś',
'mimesearch-summary' => 'Na toś tom specialnem boku mógu se dataje pó MIME-typu filtrowaś. Zapódaśe dej wopśimjeś stawnje typ medija a subtyp: <tt>image/jpeg</tt>.',
'mimetype'           => 'Typ MIME:',
'download'           => 'Ześěgnuś',

# Unwatched pages
'unwatchedpages' => 'Njewobglědowane boki',

# List redirects
'listredirects' => 'Lisćina dalejpósrědnjenjow',

# Unused templates
'unusedtemplates'     => 'Njewužywane pśedłogi',
'unusedtemplatestext' => 'Toś ten bok nalicujo wšykne boki w mjenjowom rumje {{ns:template}}, kótarež njejsu do žednego drugego boka zawězane. Pšosym kontrolěruj dalšne wótkaze, nježli až je wulašujoš.',
'unusedtemplateswlh'  => 'Druge wótkaze',

# Random page
'randompage'         => 'Pśipadny nastawk',
'randompage-nopages' => 'W mjenjowem rumje "$1" njejsu žedne boki.',

# Random redirect
'randomredirect'         => 'Pśipadne dalejpósrědnjenje',
'randomredirect-nopages' => 'W mjenjowem rumje "$1" njejsu dalejpósrědnjenja.',

# Statistics
'statistics'                   => 'Statistika',
'statistics-header-pages'      => 'Statistika bokow',
'statistics-header-edits'      => 'Statistika změnow',
'statistics-header-views'      => 'Statistiku zwobrazniś',
'statistics-header-users'      => 'Statistika wužywarjow',
'statistics-articles'          => 'Wopśimjeśowe boki',
'statistics-pages'             => 'Boki',
'statistics-pages-desc'        => 'Wše boki w toś tom wikiju, inkluziwnje diskusijne boki, dalejpósrědnjenja atd.',
'statistics-files'             => 'Nagrate dataje',
'statistics-edits'             => 'Změny bokow wót załoženja {{SITENAME}}',
'statistics-edits-average'     => 'Změny na bok w pśerězku',
'statistics-views-total'       => 'Zwobraznjenja dogromady',
'statistics-views-peredit'     => 'Zwobraznjenja na změnu',
'statistics-jobqueue'          => 'Dłujkosć [http://www.mediawiki.org/wiki/Manual:Job_queue Job queue]',
'statistics-users'             => 'Zregistrěrowane [[Special:ListUsers|wužywarje]]',
'statistics-users-active'      => 'Aktiwne wužywarje',
'statistics-users-active-desc' => 'Wužywarje, kótarež su {{PLURAL:$1|cora|w slědnyma $1 dnjoma|w slědnych $1 dnjach|w slědnych $1 dnjach}} aktiwne byli',
'statistics-mostpopular'       => 'Nejwěcej woglědane boki',

'disambiguations'      => 'Rozjasnjenja zapśimjeśow',
'disambiguationspage'  => 'Template:Rozjasnjenje zapśimjeśow',
'disambiguations-text' => 'Slědujuce boki wótkazuju na bok za rozjasnjenje zapśimjeśow.
Wótkazujśo lubjej na pótrjefjony bok.<br />
Bok wobjadnawa se ako bok wujasnjenja zapśimjeśa, gaž wótkazujo na nju [[MediaWiki:Disambiguationspage]].',

'doubleredirects'            => 'Dwójne dalejpósrědnjenja',
'doubleredirectstext'        => 'Toś ten bok nalicujo dalejpósrědnjenja, kótarež wótkazuju na druge dalejpósrědnjenja. Kužda smužka wopśimjejo wótkaze na prědne a druge dalejpósrědnjenje a teke na cyl drugego dalejpósrědnjenja, což jo w normalnem paźe wótmyslony cylowy bok, na kótaryž dejał južo prědne dalejpósrědnjenje wótkazowaś.',
'double-redirect-fixed-move' => '[[$1]] jo se pśesunuł, jo něnto dalejposrědnjenje do [[$2]]',
'double-redirect-fixer'      => 'Pórěźaŕ dalejpósrědnjenjow',

'brokenredirects'        => 'Skóńcowane dalejpósrědnjenja',
'brokenredirectstext'    => 'Slědujuce dalejpósrědnjenja wótkazuju na njeeksistěrujuce boki:',
'brokenredirects-edit'   => '(wobźěłaś)',
'brokenredirects-delete' => '(wulašowaś)',

'withoutinterwiki'         => 'Boki na kótarychž njejsu žedne wótkaze na druge rěcy',
'withoutinterwiki-summary' => 'Slědujuce boki njewótkazuju na druge rěcne wersije:',
'withoutinterwiki-legend'  => 'Prefiks',
'withoutinterwiki-submit'  => 'Pokazaś',

'fewestrevisions' => 'Boki z nejmjenjej wersijami',

# Miscellaneous special pages
'nbytes'                  => '$1 {{PLURAL:$1|byte|byta|byty}}',
'ncategories'             => '$1 {{PLURAL:$1|kategorija|kategoriji|kategorije}}',
'nlinks'                  => '$1 {{PLURAL:$1|wótkaz|wótkaza|wótkaze}}',
'nmembers'                => '$1 {{PLURAL:$1|zapis|zapisa|zapise}}',
'nrevisions'              => '$1 {{PLURAL:$1|wobźěłanje|wobźěłani|wobźěłanja}}',
'nviews'                  => '$1 {{PLURAL:$1|wótpšašanje|wótpšašani|wótpšašanja}}',
'specialpage-empty'       => 'Toś ten bok njewopśimjejo tuchylu žedne zapise.',
'lonelypages'             => 'Wósyrośone boki',
'lonelypagestext'         => 'Slědujuce boki njejsu wótkazowe cele drugich bokow abo njezapśimuju se do drugich bokow w
{{GRAMMAR:lokatiw|{{SITENAME}}}}.',
'uncategorizedpages'      => 'Boki bźez kategorijow',
'uncategorizedcategories' => 'Njekategorizěrowane kategorije',
'uncategorizedimages'     => 'Njekategorizěrowane dataje.',
'uncategorizedtemplates'  => 'Njekategorizěrowane pśedłogi',
'unusedcategories'        => 'Njewužywane kategorije',
'unusedimages'            => 'Njewužywane dataje',
'popularpages'            => 'Woblubowane boki',
'wantedcategories'        => 'Póžedane kategorije',
'wantedpages'             => 'Póžedane boki',
'wantedfiles'             => 'Póžedane dataje',
'wantedtemplates'         => 'Brachujuce pśedłogi',
'mostlinked'              => 'Nejcesćej zalinkowane boki',
'mostlinkedcategories'    => 'Nejcesćej wužywane kategorije',
'mostlinkedtemplates'     => 'Nejcesćej wužywane psedłogi',
'mostcategories'          => 'Boki z nejwěcej kategorijami',
'mostimages'              => 'Nejcesćej wótkazane dataje',
'mostrevisions'           => 'Boki z nejwěcej wersijami',
'prefixindex'             => 'Wšykne boki z prefiksom',
'shortpages'              => 'Krotke nastawki',
'longpages'               => 'Dłujke nastawki',
'deadendpages'            => 'Nastawki bźez wótkazow',
'deadendpagestext'        => 'Slědujuce boki njewótkazuju na druge boki we {{GRAMMAR:lokatiw|{{SITENAME}}}}.',
'protectedpages'          => 'Šćitane boki',
'protectedpages-indef'    => 'Jano boki pokazaś, kótarež su na njewěsty cas šćitane',
'protectedpages-cascade'  => 'Jano boki z kaskadowym šćitom',
'protectedpagestext'      => 'Slědujuce boki njamgu se mimo wósebnych pšawow wobźěłaś resp. pśesuwaś',
'protectedpagesempty'     => 'Z toś tymi parametrami njejsu tuchylu žedne boki šćitane.',
'protectedtitles'         => 'Šćitane titele',
'protectedtitlestext'     => 'Slědujuce titele su pśeśiwo twórjenjoju šćitane.',
'protectedtitlesempty'    => 'Tuchylu njejsu žedne boki z pódanych parametrami šćitane.',
'listusers'               => 'Lisćina wužywarjow',
'listusers-editsonly'     => 'Jano wužywarjow ze změnami pokazaś',
'usereditcount'           => '$1 {{PLURAL:$1|změna|změnje|změny|změnow}}',
'newpages'                => 'Nowe boki',
'newpages-username'       => 'Wužywarske mě:',
'ancientpages'            => 'Nejstarše boki',
'move'                    => 'Pśesunuś',
'movethispage'            => 'Bok pśesunuś',
'unusedimagestext'        => 'Pšosym glědaj na to, až ewtl. druge websedła móžu k drugej dataji z direktnym URL wótkazaś a móžo togodla how nalicona byś, lěcrownož se rowno wužywa.',
'unusedcategoriestext'    => 'Toś ten specialny bok pokazujo wšykne njekategorizěrowane kategorije.',
'notargettitle'           => 'Žeden celowy bok njejo zapódany.',
'notargettext'            => 'Njejsy zapódał celowy bok, źož dejała funkcija se wugbaś.',
'nopagetitle'             => 'Žeden taki celowy bok',
'nopagetext'              => 'Celowy bok, kótaryž sćo pódał, njeeksistěrujo.',
'pager-newer-n'           => '{{PLURAL:$1|nowšy 1|nowšej $1|nowše $1|nowšych $1}}',
'pager-older-n'           => '{{PLURAL:$1|staršy 1|staršej $1|starše $1|staršych $1}}',
'suppress'                => 'Doglědowanje',

# Book sources
'booksources'               => 'Pytanje pó ISBN',
'booksources-search-legend' => 'Knigłowe žrědła pytaś',
'booksources-go'            => 'Pytaś',
'booksources-text'          => 'To jo lisćina z wótkazami na internetowe boki, kótarež pśedawaju nowe a trjebane knigły. Tam mógu teke dalšne informacije wó knigłach byś. {{SITENAME}} njezwisujo góspodarski z žednym z toś tych póbitowarjow.',
'booksources-invalid-isbn'  => 'Pódane ISBN-cysło njezda se płaśiwe byś; pséglědaj za zmólkami, z tym až kopěrujoš z originalnego žrědła.',

# Special:Log
'specialloguserlabel'  => 'Wužywaŕ:',
'speciallogtitlelabel' => 'Nadpismo:',
'log'                  => 'Protokole',
'all-logs-page'        => 'Wšykne protokole',
'alllogstext'          => 'To jo kombiněrowane zwobraznjenje wšyknych we {{GRAMMAR:lokatiw|{{SITENAME}}}} k dispoziciji stojecych protokolow. Móžoš naglěd pśez wubraśe protokolowego typa, wužywarskego mjenja (pód źiwanim wjelikopisanja) abo pótrjefjonego boka (teke pód źiwanim wjelikopisanja) wobgranicowaś.',
'logempty'             => 'Žedne se góźece zapise njeeksistěruju.',
'log-title-wildcard'   => 'Pytaś nadpismo, kótarež zachopijo z ...',

# Special:AllPages
'allpages'          => 'Wšykne boki',
'alphaindexline'    => '$1 do $2',
'nextpage'          => 'Slědujucy bok ($1)',
'prevpage'          => 'Pśedchadny bok ($1)',
'allpagesfrom'      => 'Boki pokazaś wót:',
'allpagesto'        => 'Boki zwobrazniś, kótarež kóńce se na:',
'allarticles'       => 'Wšykne nastawki',
'allinnamespace'    => 'Wšykne boki (mjenjowy rum: $1)',
'allnotinnamespace' => 'Wšykne boki (nic w mjenjowem rumje $1)',
'allpagesprev'      => 'Pśedchadne',
'allpagesnext'      => 'Slědujuce',
'allpagessubmit'    => 'Pokazaś',
'allpagesprefix'    => 'Boki pokazaś (z prefiksom):',
'allpagesbadtitle'  => 'Zapódane mě boka njejo płaśece: Jo móžno, až ma pśedstajonu rěcnu resp. interwikijowu krotceńku abo wopśimjejo jadno abo wěcej znamuškow, kótarež njamgu se za mjenja bokow wužywaś.',
'allpages-bad-ns'   => 'Mjenjowy rum „$1“ w {{SITENAME}} njeeksistěrujo.',

# Special:Categories
'categories'                    => 'Kategorije',
'categoriespagetext'            => 'Slědujuce kategorije wopśimuju boki abo medije. [[Special:UnusedCategories|Njewužywane kategorije]] se how njepokazuju. Glědaj teke [[Special:WantedCategories|póžedane kategorije]].',
'categoriesfrom'                => 'Kategorije pokazaś, zachopinajucy z:',
'special-categories-sort-count' => 'pśewuběrowaś pó licbje',
'special-categories-sort-abc'   => 'pśewuběrowaś pó alfabeśe',

# Special:DeletedContributions
'deletedcontributions' => 'Wulašowane wužywarske pśinoski',

# Special:LinkSearch
'linksearch'       => 'Eksterne wótkaze',
'linksearch-pat'   => 'Pytański muster:',
'linksearch-ns'    => 'Mjenjowy rum:',
'linksearch-ok'    => 'Pytaś',
'linksearch-text'  => 'Jo móžno zastupne znamješka kaž "*.wikipedia.org" wužywaś.<br />
Pódpěrane protokole: <tt>$1</tt>',
'linksearch-line'  => '$1 wótkazany z $2',
'linksearch-error' => 'Zasupne znamješko daju se jano na zachopjeńku URL wužywaś.',

# Special:ListUsers
'listusersfrom'      => 'Pokaž wužywarjow wót:',
'listusers-submit'   => 'Pokazaś',
'listusers-noresult' => 'Žeden wužywaŕ njejo se namakał.',

# Special:Log/newusers
'newuserlogpage'              => 'Protokol nowych wužywarjow',
'newuserlogpagetext'          => 'To jo protokol wó nowych wužywarskich kontow.',
'newuserlog-byemail'          => 'Pótajne słowo bu pśez e-mail pósłane.',
'newuserlog-create-entry'     => 'Nowy wužywaŕ',
'newuserlog-create2-entry'    => 'Nowe konto za $1 napórane.',
'newuserlog-autocreate-entry' => 'Wužywarske konto bu awtomatiski napórane',

# Special:ListGroupRights
'listgrouprights'                 => 'Pšawa wužywarskeje kupki',
'listgrouprights-summary'         => 'To jo lisćina wužywarskich kupkow definěrowanych w toś tom wikiju z jich zwězanymi pśistupnymi pšawami. Móžo [[{{MediaWiki:Listgrouprights-helppage}}|pśidatne informacije]] wó jadnotliwych pšawach daś.',
'listgrouprights-group'           => 'Kupka',
'listgrouprights-rights'          => 'Pšawa',
'listgrouprights-helppage'        => 'Help:Kupkowe pšawa',
'listgrouprights-members'         => '(lisćina cłonkow)',
'listgrouprights-addgroup'        => 'Móžo pśidaś {{PLURAL:$2|kupku|kupce|kupki|kupkow}}: $1',
'listgrouprights-removegroup'     => 'Móžo wótwónoźeś {{PLURAL:$2|kupku|kupce|kupki|kupkow}}: $1',
'listgrouprights-addgroup-all'    => 'Móžo pśidaś wšykne kupki',
'listgrouprights-removegroup-all' => 'Móžo wótwónoźeś wšykne kupki',

# E-mail user
'mailnologin'      => 'Njejo móžno e-mailku pósłaś.',
'mailnologintext'  => 'Dejš [[Special:UserLogin|pśizjawjony]] byś a płaśiwu e-mailowu adresu w swójich [[Special:Preferences|nastajenjach]] měś, aby drugim wužywarjam e-mail pósłał.',
'emailuser'        => 'Toś tomu wužywarjeju e-mail pósłaś',
'emailpage'        => 'E-mail wužywarjeju',
'emailpagetext'    => 'Móžoš slědujucy formular wužywaś, aby toś tomu wužywarjeju e-mail pósłał.
E-mailowa adresa, kótaruž sy zapódał w [[Special:Preferences|swójich wužywarskich nastajenjach]], zjawi se ako adresa w pólu "Wót" e-maile, aby dostawaŕ móžo śi direktnje wótegroniś.',
'usermailererror'  => 'E-mailowy objekt jo zmólku wrośił.',
'defemailsubject'  => '{{SITENAME}} e-mail',
'noemailtitle'     => 'E-mailowa adresa felujo.',
'noemailtext'      => 'Toś ten wužywaŕ njejo pódał płaśiwu e-mailowu adresu.',
'nowikiemailtitle' => 'Žedna e-mail dowólona',
'nowikiemailtext'  => 'Toś ten wužywaŕ njoco žednu e-mail wót drugich wužywarjow dostaś.',
'email-legend'     => 'Drugemu wužywarjeju {{SITENAME}} e-mail pósłaś',
'emailfrom'        => 'Wót:',
'emailto'          => 'Komu:',
'emailsubject'     => 'Tema:',
'emailmessage'     => 'Powěsć:',
'emailsend'        => 'Wótpósłaś',
'emailccme'        => 'Pósćel mě kopiju e-maila.',
'emailccsubject'   => 'Kopija Twójeje powěsći na $1: $2',
'emailsent'        => 'e-mail wótposłany',
'emailsenttext'    => 'Twój e-mail jo se wótpósłał.',
'emailuserfooter'  => 'Toś ta e-mailka jo se z pomocu funkcije "Toś tomu wužywarjeju e-mail pósłaś" na {{SITENAME}} wót $1 do $2 pósłała.',

# Watchlist
'watchlist'            => 'Wobglědowańka',
'mywatchlist'          => 'mója wobglědowańka',
'watchlistfor'         => "(za wužywarja '''$1''')",
'nowatchlist'          => 'Žedne zapise w Twójich wobglědowańkach.',
'watchlistanontext'    => 'Dejš se $1, aby mógał swóje wobglědowańka wiźeś abo zapise w nich wobźěłaś.',
'watchnologin'         => 'Njepśizjawjony(a)',
'watchnologintext'     => 'Musyš byś [[Special:UserLogin|pśizjawjony]], aby mógał swóje wobglědowańka wobźěłaś.',
'addedwatch'           => 'Jo k wobglědowańkam se dodało',
'addedwatchtext'       => 'Bok „<nowiki>$1</nowiki>“ jo k twójim [[Special:Watchlist|wobglědowańkam]] se dodał.

Pózdźejšne změny na toś tom boku a w pśisłušecej diskusiji se tam nalicuju a w pśeglěźe [[Special:RecentChanges|slědnych změnow]] tucnje wóznamjeniju.

Coš-lic bok zasej z twójich wobglědowańkow wulašowaś, kliknij na wótpowědujucem boce na "dalej njewobglědowaś".',
'removedwatch'         => 'Jo z wobglědowańkow se wulašowało',
'removedwatchtext'     => 'Bok „<nowiki>$1</nowiki>“ jo z twójich wobglědowańkow wulašowany.',
'watch'                => 'Wobglědowaś',
'watchthispage'        => 'Bok wobglědowaś',
'unwatch'              => 'Dalej njewobglědowaś',
'unwatchthispage'      => 'Dalej njewobglědowaś',
'notanarticle'         => 'To njejo žeden nastawk',
'notvisiblerev'        => 'Wersija bu wulašowana',
'watchnochange'        => 'Žeden wót tebje wobglědowany bok njejo se we wótpowědujucem casu wobźěłał.',
'watchlist-details'    => 'Wobglědujoš {{PLURAL:$1|$1 bok|$1 boka|$1 boki|$1 bokow}}, bźez diskusijnych bokow.',
'wlheader-enotif'      => '* E-mailowe powěsće su aktiwizěrowane.',
'wlheader-showupdated' => "* Boki, kótarež su wót twójogo slědnego woglěda se změnili, pokazuju se '''tucnje'''.",
'watchmethod-recent'   => 'Kontrolěrowanje slědnych wobźěłanjow we wobglědowańkach',
'watchmethod-list'     => 'Pśepytanje wobglědowańkow za slědnymi wobźěłanjami',
'watchlistcontains'    => 'Twóje wobglědowańka wopśimjeju $1 {{PLURAL:$1|bok|boka|boki}}.',
'iteminvalidname'      => 'Problem ze zapisom „$1“, njepłaśece mě.',
'wlnote'               => "{{PLURAL:$1|Slědujo slědna změna|slědujotej '''$1''' slědnej změnje|slěduju slědne '''$1''' změny}} {{PLURAL:$2|slědneje góźiny|slědneju '''$2''' góźinowu|slědnych '''$2''' góźinow}}.",
'wlshowlast'           => 'Pokaž změny slědnych $1 góźinow, $2 dnjow abo $3 (w slědnych 30 dnjach).',
'watchlist-options'    => 'Opcije wobglědowańki',

# Displayed when you click the "watch" button and it is in the process of watching
'watching'   => 'Wobglědowaś …',
'unwatching' => 'Njewobglědowaś …',

'enotif_mailer'                => '{{SITENAME}} e-mailowe powěsći',
'enotif_reset'                 => 'Wšykne boki ako woglědane markěrowaś',
'enotif_newpagetext'           => 'To jo nowy bok.',
'enotif_impersonal_salutation' => '{{SITENAME}}-wužywaŕ',
'changed'                      => 'změnjone',
'created'                      => 'wutwórjone',
'enotif_subject'               => '[{{SITENAME}}] Bok "$PAGETITLE" jo se wót $PAGEEDITOR $CHANGEDORCREATED',
'enotif_lastvisited'           => 'Wšykne změny na jadno póglědnjenje: $1',
'enotif_lastdiff'              => 'Za toś tu změnu glědaj w $1.',
'enotif_anon_editor'           => 'anonymny wužywaŕ $1',
'enotif_body'                  => 'Luby/a $WATCHINGUSERNAME,

{{SITENAME}} bok "$PAGETITLE" jo se wót $PAGEEDITOR $PAGEEDITDATE $CHANGEDORCREATED.

Aktualna wersija: $PAGETITLE_URL

$NEWPAGE

Zespominanje wobźěłarja: $PAGESUMMARY $PAGEMINOREDIT

Kontakt z wobźěłarjom:
E-Mail: $PAGEEDITOR_EMAIL
Wiki: $PAGEEDITOR_WIKI

Dalšne e-mailowe powěsći se tak dłujko njepósćelu, až njejsy bok zasej woglědał. W swójich wobglědowańkach móžoš wšykne powěsćowe markery zasej slědk stajiś.

             Twój pśijaśelny {{SITENAME}} powěsćowy system
--
Aby nastajenja twójich wobglědowańkow změnił, woglědaj: {{fullurl:Special:Watchlist/edit}}',

# Delete
'deletepage'             => 'Bok wulašowaś',
'confirm'                => 'Wobkšuśiś',
'excontent'              => "wopśimjeśe jo było: '$1'",
'excontentauthor'        => "wopśimjeśe jo było: '$1' (a jadnučki wobźěłaŕ jo był '[[Special:Contributions/$2|$2]]')",
'exbeforeblank'          => "Wopśimjeśe do wuprozdnjenja jo było: '$1'",
'exblank'                => 'bok jo był prozny',
'delete-confirm'         => '„$1“ lašowaś',
'delete-legend'          => 'Lašowaś',
'historywarning'         => 'Glědaj! Bok, kótaryž coš wulašowaś, ma stawizny:',
'confirmdeletetext'      => 'Coš bok abo dataju ze wšyknymi pśisłušnymi wersijami na pśecej wulašowaś. Pšosym wobkšuś, až sy se wědobny, kake konsekwency móžo to měś, a až jadnaš pó [[{{MediaWiki:Policy-url}}|směrnicach]].',
'actioncomplete'         => 'Akcija jo se wugbała.',
'deletedtext'            => '„<nowiki>$1</nowiki>“ jo se wulašował(a/o). W $2 namakajoš lisćinu slědnych wulašowanjow.',
'deletedarticle'         => 'wulašowane "[[$1]]"',
'suppressedarticle'      => '"[[$1]]" pódtłocony',
'dellogpage'             => 'Protokol wulašowanjow',
'dellogpagetext'         => 'How jo protokol wulašowanych bokow a datajow.',
'deletionlog'            => 'protokol wulašowanjow',
'reverted'               => 'Nawrośone na staršu wersiju',
'deletecomment'          => 'Pśicyna wulašowanja:',
'deleteotherreason'      => 'Druga/pśidatna pśicyna:',
'deletereasonotherlist'  => 'Druga pśicyna',
'deletereason-dropdown'  => '* Powšykne pśicyny za lašowanja
** Žycenje awtora
** Pśekśiwjenje stworiśelskego pšawa
** Wandalizm',
'delete-edit-reasonlist' => 'Pśicyny za lašowanje wobźěłaś',
'delete-toobig'          => 'Toś ten bok ma z wěcej nježli $1 {{PLURAL:$1|wersiju|wersijomaj|wersijami|wersijami}} dłujku historiju. Lašowanje takich bokow bu wobgranicowane, aby wobškoźenju {{GRAMMAR:genitiw|{{SITENAME}}}} z pśigódy zajźowało.',
'delete-warning-toobig'  => 'Toś ten bok ma z wěcej ako $1 {{PLURAL:$1|wersiju|wersijomaj|wersijami|wersijami}} dłujke stawizny. Jich wulašowanje móžo źěło datoweje banki na {{SITENAME}} kazyś;
póstupujśo z glědanim.',

# Rollback
'rollback'         => 'Wobźěłanja slědk wześ',
'rollback_short'   => 'anulěrowaś',
'rollbacklink'     => 'anulěrowaś',
'rollbackfailed'   => 'Slědkwześe njejo se raźiło.',
'cantrollback'     => 'Njejo móžno změnu slědk wześ, slědny pśinosowaŕ jo jadnučki awtor boka.',
'alreadyrolled'    => 'Njejo móžno slědnu změnu w nastawku [[:$1]] wót [[User:$2|$2]] ([[User talk:$2|diskusija]]{{int:pipe-separator}}[[Special:Contributions/$2|{{int:contribslink}}]]) slědk wześ; drugi wužywaŕ jo mjaztym bok změnił abo južo slědk stajił .

Slědnu změnu k bokoju jo pśewjadł [[User:$3|$3]] ([[User talk:$3|diskusija]]{{int:pipe-separator}}[[Special:Contributions/$3|{{int:contribslink}}]]).',
'editcomment'      => "Zapominanje k slědnej změnje jo było: \"''\$1''\".", # only shown if there is an edit comment
'revertpage'       => 'Změny wužywarja [[Special:Contributions/$2|$2]] ([[User talk:$2|Diskusija]]) su se wótwrośili a slědna wersija wužywarja [[User:$1|$1]] jo se wótnowiła.', # Additionally available: $3: revid of the revision reverted to, $4: timestamp of the revision reverted to, $5: revid of the revision reverted from, $6: timestamp of the revision reverted from
'rollback-success' => 'Změny wót $1 su se slědk wzeli a slědna wersija wót $2 jo zasej se nawrośiła.',
'sessionfailure'   => 'Problem z twójim wužywarskim pósejźenim jo se wujawił.
Wěstoty dla jo akcija se pśetergnuła, aby se zadorało wopacnemu pśirědowanjoju twójeje změny drugemu wužywarjeju.
Pšosym nawroś se na bok, wót kótaregož sy pśišeł a wopytaj hyšći raz.',

# Protect
'protectlogpage'              => 'Protokol šćitanych bokow.',
'protectlogtext'              => 'To jo protokol šćitanych bokow. Glědaj do [[Special:ProtectedPages|lisćiny šćitanych bokow]], aby wiźeł wšykne aktualnje šćitane boki.',
'protectedarticle'            => 'Bok „[[$1]]“ jo se šćitał.',
'modifiedarticleprotection'   => 'Šćitanska rownina za „[[$1]]“ jo se změniła.',
'unprotectedarticle'          => 'Šćit za „[[$1]]“ jo se wótpórał.',
'movedarticleprotection'      => 'šćitowe nastajenja z "[[$2]]" do "[[$1]]" psésunjone',
'protect-title'               => 'Šćit boka „$1“ změniś',
'prot_1movedto2'              => '„[[$1]]“ pśesunjone na „[[$2]]“',
'protect-legend'              => 'Šćitanje wobkšuśiś',
'protectcomment'              => 'Komentar:',
'protectexpiry'               => 'cas wótběžy:',
'protect_expiry_invalid'      => 'Zapódany cas jo njekorektny.',
'protect_expiry_old'          => 'Zapódany cas jo wótběžał.',
'protect-unchain'             => 'Šćit pśed pśesunjenim změniś',
'protect-text'                => "How móžoš status šćita boka '''<nowiki>$1</nowiki>''' wobglědowaś a jen změniś.",
'protect-locked-blocked'      => "Njamóžoš status šćita togo boka změniś, dokulaž jo twójo wužywarske konto se blokěrowało. How su aktualne nastajenja šćita za bok '''„$1“:'''.",
'protect-locked-dblock'       => "Datowa banka jo zamknjona a toś njejo móžno šćit boka změniś. How su aktualne nastajenja šćita za bok '''„$1“:'''.",
'protect-locked-access'       => "Wašo wužywarske konto njama notne pšawa za změnu šćita toś togo boka. How su aktualne nastajenja šćita boka '''„$1“:'''.",
'protect-cascadeon'           => 'Toś ten bok jo tuchylu šćitany, dokulaž jo zawězany do {{PLURAL:$1|slědujucego boka|slědujuceju bokowu|slědujucych bokow}}, źož kaskadowy šćit jo aktiwěrowany. Status šćita móžo se za toś ten bok změniś, to ale njewówliwujo kaskadowy šćit:',
'protect-default'             => 'Wšyknym wužywarjam dowóliś',
'protect-fallback'            => 'Slědujuce pšawo jo notne: „$1“.',
'protect-level-autoconfirmed' => 'Nowych a njeregistrěrowanych wužywarjow blokěrowaś',
'protect-level-sysop'         => 'Jano administratory',
'protect-summary-cascade'     => 'kaskaděrujucy',
'protect-expiring'            => 'kóńcy $1 (UTC)',
'protect-expiry-indefinite'   => 'njewobgranicowany',
'protect-cascade'             => 'Kaskaděrujucy šćit – wšykne pśedłogi, kótarež su zawězane do toś togo boka, tejerownosći se zamknu.',
'protect-cantedit'            => 'Njamóžoš šćitne rowniny toś tego boka změniś, dokulaž njamaš dowólnosć toś ten bok wobźěłaś.',
'protect-othertime'           => 'Drugi cas:',
'protect-othertime-op'        => 'drugi cas',
'protect-existing-expiry'     => 'Eksistěrujucy cas pśepadnjenja: $2, $3',
'protect-otherreason'         => 'Druga/pśidatna pśicyna:',
'protect-otherreason-op'      => 'Druga/pśidatna pśicyna',
'protect-dropdown'            => '*Powšykne šćitowe pśicyny
** Ekscesiwny wanadalizm
** Ekscesiwne spamowanje
** Wobźěłańska wójna
** Bok z wusokim datowym wobchadom',
'protect-edit-reasonlist'     => 'Šćitne pśicyny wobźěłaś',
'protect-expiry-options'      => '1 góźina:1 hour,1 źeń:1 day,1 tyźeń:1 week,2 tyźenja:2 weeks,1 mjasec:1 month,3 mjasece:3 months,6 mjasecy:6 months,1 lěto:1 year,na nimjer:infinite', # display1:time1,display2:time2,...
'restriction-type'            => 'Status šćita',
'restriction-level'           => 'Rownina šćita:',
'minimum-size'                => 'Minimalna wjelikosć',
'maximum-size'                => 'maksimalna wjelikosć:',
'pagesize'                    => '(byty)',

# Restrictions (nouns)
'restriction-edit'   => 'wobźěłaś',
'restriction-move'   => 'pśesunuś',
'restriction-create' => 'Natwóriś',
'restriction-upload' => 'lódowaś',

# Restriction levels
'restriction-level-sysop'         => 'połnje šćitane',
'restriction-level-autoconfirmed' => 'poł šćitane',
'restriction-level-all'           => 'wšykne',

# Undelete
'undelete'                     => 'Wulašowane boki woglědaś',
'undeletepage'                 => 'Wulašowane boki pokazaś a nawrośiś.',
'undeletepagetitle'            => "'''Slědujuce wudaśe wobstoj z wulašowanych wersijow wót [[:$1|$1]]'''.",
'viewdeletedpage'              => 'Wulašowane boki pokazaś',
'undeletepagetext'             => '{{PLURAL:$1|Slědujucy bok jo se wulašował, ale jo|Slědujucej $1 boka stej se wulašowałej, ale stej|Slědujuce $1 boki su se wulašowali, ale su|Slědujucych $1 bokow jo se wulašowało, ale jo}} hyšći w archiwje a {{PLURAL:$1|dajo|dajotej|daju|dajo}} se nawrośiś.
Archiw dajo se periodiski wuprozniś.',
'undelete-fieldset-title'      => 'Wersije wótnowiś',
'undeleteextrahelp'            => "Aby wšyknymi wersijami boka nawrośiś, wóstaj wšykne kontrolowe kašćiki prozne a klikni na zapódaj '''''Nawrośíś'''''.
Aby jano wěste wersije nawrośił, wubjeŕ kašćiki, kótarež wótpowěduju wersijam, kótarež maju se nawrośiś a klikni na '''''Nawrośiś'''''.
Kliknjenje na '''''Pśetergnuś''''' wuprozni komentarne pólo a wšykne kontrolowe kašćiki.",
'undeleterevisions'            => '$1 {{PLURAL:$1|wersija archiwěrowana|wersiji archiwěrowanej|wersije archiwěrowane}}',
'undeletehistory'              => 'Jolic nawrośijoš bok, nawrośiju se wšykne wersije stawiznow.
Joli až jo se wutwórił nowy bok ze samskim mjenim wót casa wulašowanja, nawrośone wersije zjawiju se w  pjerwješnych stawiznach.',
'undeleterevdel'               => 'Nawrośenje njejo móžne, gaž wjeźo k nejwušemu bokoju abo datajowej wersiji, kótaraž se pó źělach lašujo. 
W takich padach dejš nejnowše wulašowane wersije markěroanje abo schowanje wótpóraś.',
'undeletehistorynoadmin'       => 'Toś ten bok jo se wulašował. Pśicyna wulašowanja pokazujo se w zespominanju. Tam stoje teke nadrobnosći wó wužywarjach, kótarež su bok pśed wulašowanim wobźěłali. Aktualny tekst toś tych wulašowanych wersijow jo jano administratoram pśistupny.',
'undelete-revision'            => 'Wulašowana wersija boka $1 (wót $4, $5) wót $3:',
'undeleterevision-missing'     => 'Njepłaśeca abo felujuca wersija. Snaź jo link wopacny abo wersija jo z archiwa se nawrośiła resp. wulašowała.',
'undelete-nodiff'              => 'Žedne něgajšne wersije',
'undeletebtn'                  => 'Wulašowaś',
'undeletelink'                 => 'woglědaś se/wótnowiś',
'undeletereset'                => 'Slědk wześ',
'undeleteinvert'               => 'Wuběrk pśewobrośiś',
'undeletecomment'              => 'Wobtwarźenje:',
'undeletedarticle'             => 'bok „[[$1]]“ nawrośony',
'undeletedrevisions'           => '{{PLURAL:$1|1 wersija jo se nawrośiła|$1 wersiji stej se nawrośiłej|$1 wersije su se nawrośili}}.',
'undeletedrevisions-files'     => '{{PLURAL:$1|1 wersija|$1 wersiji|$1 wersije}} a {{PLURAL:$2|1 dataja|$2 dataji|$2 dataje}} {{PLURAL:$2|jo se nawrośiła|stej se nawrośiłej|su se nawrośili}}.',
'undeletedfiles'               => '{{PLURAL:$1|1 dataja jo se nawrośiła|$1 dataji stej se nawrośiłej|$1 dataje su se nawrośili}}.',
'cannotundelete'               => 'Nawrośenje njejo se zglucyło; něchten drugi jo bok južo nawrośił.',
'undeletedpage'                => "Bok '''$1''' jo se nawrośił.

W [[Special:Log/delete|log-lisćinje wulašowanjow]] namakajoš pśeglěd wulašowanych a nawrośonych bokow.",
'undelete-header'              => 'Gano wulašowane boki wiźiš w [[Special:Log/delete|log-lisćinje wulašowanjow]].',
'undelete-search-box'          => 'Wulašowane boki pytaś',
'undelete-search-prefix'       => 'Pokaž boki, kótarež zachopiju z:',
'undelete-search-submit'       => 'Pytaś',
'undelete-no-results'          => 'W archiwje wulašowanych bokow žeden bok pytanemu słowoju njewótpowědujo.',
'undelete-filename-mismatch'   => 'Njejo móžno było, datajowu wersiju z casowym kołkom $1 nawrośiś: Datajowej mjeni se njemakatej.',
'undelete-bad-store-key'       => 'Njejo móžno było, wersiju z casowym kołkom $1 nawrośiś: Dataja južo pśed wulašowanim njejo eksistěrowała.',
'undelete-cleanup-error'       => 'Zmólka pśi wulašowanju njewužywaneje archiwneje dataje $1.',
'undelete-missing-filearchive' => 'Njejo móžno, archiwnu dataju ID $1 nawrośiś. Wóna južo w datowej bance njejo. Snaź jo južo raz se nawrośiła.',
'undelete-error-short'         => 'Zmólka pśi nawrośenju dataje: $1',
'undelete-error-long'          => 'Zmólki pśi nawrośenju dataje:

$1',
'undelete-show-file-confirm'   => 'Coš se napšawdu wulašowanu wersiju dataje "<nowiki>$1</nowiki>" wót $2 $3 woglědaś?',
'undelete-show-file-submit'    => 'Jo',

# Namespace form on various pages
'namespace'      => 'Mjenjowy rum:',
'invert'         => 'Wuběr wobrośiś',
'blanknamespace' => '(Nastawki)',

# Contributions
'contributions'       => 'Wužywarske pśinoski',
'contributions-title' => 'Wužywarske pśinoski wót $1',
'mycontris'           => 'Móje pśinoski',
'contribsub2'         => 'Za $1 ($2)',
'nocontribs'          => 'Za toś te kriterije njejsu žedne změny se namakali.',
'uctop'               => '(aktualny)',
'month'               => 'wót mjaseca (a jěsnjej):',
'year'                => 'wót lěta (a jěsnjej):',

'sp-contributions-newbies'       => 'Pśinoski jano za nowych wužywarjow pokazaś',
'sp-contributions-newbies-sub'   => 'Za nowackow',
'sp-contributions-newbies-title' => 'Wužywarske pśinoski nowych kontow',
'sp-contributions-blocklog'      => 'Protokol blokěrowanjow',
'sp-contributions-search'        => 'Pśinoski pytaś',
'sp-contributions-username'      => 'IP-adresa abo wužywarske mě:',
'sp-contributions-submit'        => 'Pytaś',

# What links here
'whatlinkshere'            => 'Wótkaze na toś ten bok',
'whatlinkshere-title'      => 'Boki, kótarež wótkazuju na "$1"',
'whatlinkshere-page'       => 'bok:',
'linkshere'                => "Toś te boki wótkazuju na '''„[[:$1]]“''':",
'nolinkshere'              => "Žedne boki njewótkazuju na '''[[:$1]]'''.",
'nolinkshere-ns'           => "Žedne boki we wubranem mjenjowem rumje njewótkazuju na '''[[:$1]]'''.",
'isredirect'               => 'dalejpósrědnjujucy bok',
'istemplate'               => 'zawězanje pśedłogi',
'isimage'                  => 'Datajowy wótkaz',
'whatlinkshere-prev'       => '{{PLURAL:$1|zachadny|zachadnej|zachadne $1}}',
'whatlinkshere-next'       => '{{PLURAL:$1|pśiducy|pśiducej|pśiduce $1}}',
'whatlinkshere-links'      => '← wótkaze',
'whatlinkshere-hideredirs' => '$1 pśesměrowań',
'whatlinkshere-hidetrans'  => 'Zapśěgnjenja $1',
'whatlinkshere-hidelinks'  => '$1 wótkazow',
'whatlinkshere-hideimages' => 'Datajowe wótkaze $1',
'whatlinkshere-filters'    => 'filtry',

# Block/unblock
'blockip'                         => 'Wužywarja blokěrowaś',
'blockip-legend'                  => 'Wužywarja blokěrowaś',
'blockiptext'                     => 'Wužywaj slědujucy formular, jolic až coš wěstej IP-adresy abo konkretnemu wužywarjeju pśistup znjemóžniś. Take dejało se pó [[{{MediaWiki:Policy-url}}|směrnicach]] jano staś, aby se wandalizmoju zadorało. Pšosym zapódaj pśicynu za twójo blokěrowanje (na pś. mógu se citěrowaś konkretne boki, źo jo se wandalěrowało).',
'ipaddress'                       => 'IP-adresa',
'ipadressorusername'              => 'IP-adresa abo wužywarske mě',
'ipbexpiry'                       => 'Cas blokěrowanja:',
'ipbreason'                       => 'Pśicyna',
'ipbreasonotherlist'              => 'Druga pśicyna',
'ipbreason-dropdown'              => '*powšykne pśicyny blokěrowanja
** pódawanje njepšawych informacijow
** wulašowanje wopśimjeśa bokow
** pódawanje spamowych eksternych wótkazow  
** pisanje głuposćow na bokach
** pśestupjenje zasady "žedne wósobinske atakěrowanja"
** złowólne wužywanje wjele wužywarskich kontow
** njekorektne wužywarske mě',
'ipbanononly'                     => 'Jano anonymnych wužywarjow blokěrowaś',
'ipbcreateaccount'                => 'Twórjenje wužywarskich kontow znjemóžniś',
'ipbemailban'                     => 'pósłanje e-mailow znjemóžniś',
'ipbenableautoblock'              => 'Awtomatiske blokěrowanje slědneje wót togo wužywarja wužywaneje IP-adresy a wšyknych slědujucych adresow, wót kótarychž wopytajo boki wobźěłaś.',
'ipbsubmit'                       => 'Togo wužywarja blokěrowaś.',
'ipbother'                        => 'Drugi cas:',
'ipboptions'                      => '2 góźinje:2 hours,1 źeń:1 day,3 dny:3 days,1 tyźeń:1 week,2 tyźenja:2 weeks,1 mjasec:1 month,3 mjasece:3 months,6 mjasecy:6 months,1 lěto:1 year,na nimjer:infinite', # display1:time1,display2:time2,...
'ipbotheroption'                  => 'drugi',
'ipbotherreason'                  => 'Hynakša/dalšna pśicyna:',
'ipbhidename'                     => 'Wužywarske mě w změnach a lisćinach schowaś',
'ipbwatchuser'                    => 'Wužywarski a diskusijny bok toś togo wužywarja wobglědowaś',
'ipballowusertalk'                => 'Toś tomu wužywarjeju dowóliś swój diskusijny bok wobźěłaś, mjazytm až jo blokěrowany.',
'ipb-change-block'                => 'Wužywarja z toś tymi nastajenjami znowego blokěrowaś',
'badipaddress'                    => 'IP-adresa jo njekorektna',
'blockipsuccesssub'               => 'Wuspěšnje blokěrowane',
'blockipsuccesstext'              => 'Wužywaŕ/IP-adresa [[Special:Contributions/$1|$1]] jo se blokěrował(a).<br />
Glědaj do [[Special:IPBlockList|lisćiny aktiwnych blokěrowanjow]].',
'ipb-edit-dropdown'               => 'Pśicyny blokěrowanja wobźěłaś',
'ipb-unblock-addr'                => '$1 dopušćiś',
'ipb-unblock'                     => 'Wužywarske mě abo IP-adresu dopušćiś',
'ipb-blocklist-addr'              => 'Eksistěrujuce blokěrowanja za $1',
'ipb-blocklist'                   => 'Wšykne aktualne blokěrowanja pokazaś',
'ipb-blocklist-contribs'          => 'Pśinoski za $1',
'unblockip'                       => 'Wužywarja dopušćiś',
'unblockiptext'                   => 'Z pomocu dołojcnego formulara móžotej IP-adresa abo wužywaŕ zasej se dopušćiś.',
'ipusubmit'                       => 'Toś to blokěrowanje wótpóraś',
'unblocked'                       => 'Wužywaŕ [[User:$1|$1]] jo zasej se dopušćił.',
'unblocked-id'                    => '$1 jo se dopušćił(a).',
'ipblocklist'                     => 'Blokěrowane IP-adrese a wužywarske mjenja',
'ipblocklist-legend'              => 'Blokěrowanego wužywarja pytaś',
'ipblocklist-username'            => 'Wužywarske mě abo IP-adresa:',
'ipblocklist-sh-userblocks'       => 'Kontowe blokěrowanja $1',
'ipblocklist-sh-tempblocks'       => 'nachylne blokěrowanja $1',
'ipblocklist-sh-addressblocks'    => 'Blokěrowanja jadnotliwych IP $1',
'ipblocklist-submit'              => 'Pytaś',
'blocklistline'                   => '$1, $2 jo blokěrował $3 (až do $4)',
'infiniteblock'                   => 'njewobgranicowany',
'expiringblock'                   => 'kóńcy $1',
'anononlyblock'                   => 'jano anonymne',
'noautoblockblock'                => 'awtomatiske blokěrowanje znjemóžnjone',
'createaccountblock'              => 'wutwórjenje wužywarskich kontow znjemóžnjone',
'emailblock'                      => 'Pósłanje e-mailow jo se blokěrowało.',
'blocklist-nousertalk'            => 'njemóžno swójski diskusijny bok wobźěłaś',
'ipblocklist-empty'               => 'Lisćina jo prozna.',
'ipblocklist-no-results'          => 'Póžedana IP-Adresa abo wužywarske mě njejstej blokěrowanej.',
'blocklink'                       => 'blokěrowaś',
'unblocklink'                     => 'dopušćiś',
'change-blocklink'                => 'Blokěrowanje změniś',
'contribslink'                    => 'pśinoski',
'autoblocker'                     => 'Twója IP-adresa jo awtomatiski se blokěrowała, dokulaž jo ju wužywał „$1“. Pśicyna blokěrowanja wužywarja „$1“ jo: „$2“.',
'blocklogpage'                    => 'Protokol blokěrowanjow',
'blocklog-fulllog'                => 'Dopołny protokol blokěrowanjow',
'blocklogentry'                   => '[[$1]] blokěrujo se na $2 $3',
'reblock-logentry'                => 'jo změnił blokěrowańske nastajenja za [[$1]] z casom spadnjenja $2 $3',
'blocklogtext'                    => 'To jo protokol blokěrowanjow a dopušćenjow.
IP-adresy, ako su awtomatiski se blokěrowali, se njepokažu.
Na boce [[Special:IPBlockList|Lisćina blokěrowanych IP-adresow a wužywarskich mjenjow]] jo móžno, akualne blokěrowanja pśeglědowaś.',
'unblocklogentry'                 => 'jo $1 zasej dopušćił',
'block-log-flags-anononly'        => 'jano anonymne',
'block-log-flags-nocreate'        => 'stwórjenje konta jo se znjemóžniło',
'block-log-flags-noautoblock'     => 'awtomatiske blokěrowanje jo deaktiwěrowane',
'block-log-flags-noemail'         => 'e-mailowanje jo blokěrowane',
'block-log-flags-nousertalk'      => 'njejo móžno swójski diskusijny bok wobźěłaś',
'block-log-flags-angry-autoblock' => 'pólěpšone awtomatsike blokěrowanje zmóžnjone',
'range_block_disabled'            => 'Móžnosć administratora, blokěrowaś cełe adresowe rumy, njejo aktiwěrowana.',
'ipb_expiry_invalid'              => 'Pódany cas jo njepłaśecy.',
'ipb_expiry_temp'                 => 'Blokěrowanja schowanych wužywarskich mjenjow deje permanentne byś.',
'ipb_already_blocked'             => '"$1" jo južo blokěrowany.',
'ipb-needreblock'                 => '== Južo zablokěrowany ==
$1 jo južo zablokěrowany. Coš nastajenja změniś?',
'ipb_cant_unblock'                => 'Zmólka: Blokěrowańska ID $1 njejo se namakała. Blokěrowanje jo było južo wótpórane.',
'ipb_blocked_as_range'            => 'Zmólka: IP-adresa $1 njejo direktnje blokěrowana a njeda se wótblokěrowaś. Jo pak ako źěl wobcerka $2 blokěrowana, kótaryž da se wótblokěrowaś.',
'ip_range_invalid'                => 'Njepłaśecy wobłuk IP-adresow.',
'blockme'                         => 'blokěruj mě',
'proxyblocker'                    => 'Blokěrowanje proxy',
'proxyblocker-disabled'           => 'Toś ta funkcija jo znjemóžnjona.',
'proxyblockreason'                => 'Twója IP-adresa jo se blokěrowała, dokulaž jo wócynjony proxy. Pšosym kontaktěruj swójogo seśowego providera abo swóje systemowe administratory a informěruj je wó toś tom móžnem wěstotnem problemje.',
'proxyblocksuccess'               => 'Gótowe.',
'sorbsreason'                     => 'Twója IP-adresa jo w DNSBL we {{GRAMMAR:lokatiw|{{SITENAME}}}} zapisana ako wócynjony proxy.',
'sorbs_create_account_reason'     => 'Twója IP-adresa jo w DNSBL {{GRAMMAR:genitiw|{{SITENAME}}}} ako wócynjony proxy zapisana. Njejo móžno, nowe wužywarske konta załožowaś.',
'cant-block-while-blocked'        => 'Njesmějoš žednych drugich wužywarjow blokěrowaś, mjaztym až ty sy blokěrowany.',

# Developer tools
'lockdb'              => 'Datowu banku zamknuś',
'unlockdb'            => 'Datowu banku zasej spśistupniś',
'lockdbtext'          => 'Zamknjenje datoweje banki znjemóžnijo wšyknym wužywarjam boki wobźěłaś, swóje nastajenja změnjaś, swóje wobglědowańka wobźěłaś a druge źěła wugbaś, kótarež pominaju změnu w datowej bance. Pšosym wobkšuś, až coš něnto datowu banku zamknuś a zasej dopušćiś, gaž sy swóje změny pśewjadł.',
'unlockdbtext'        => 'Spśistupnjenje datoweje banki zmóžnijo wšyknym wužywarjam boki wobźěłaś, swóje nastajenja změnjaś, swóje wobglědowańka wobźěłaś a druge źěła wugbaś, kótarež pominaju změnu w datowej bance. Pšosym wobkšuś, až coš datowu banku zasej spśistupniś.',
'lockconfirm'         => 'Jo, datowu banku com napšawdu zamknuś.',
'unlockconfirm'       => 'Jo, datowu banku com napšawdu zasej spśistupniś.',
'lockbtn'             => 'Datowu banku zamknuś',
'unlockbtn'           => 'Datowu banku zasej spśistupniś',
'locknoconfirm'       => 'Njejsy hyšći wobkšuśił.',
'lockdbsuccesssub'    => 'Datowa banka jo zamknjona.',
'unlockdbsuccesssub'  => 'Datowa banka jo zasej se spśistupniła.',
'lockdbsuccesstext'   => 'Datowa banka jo zamknjona.
<br />Njezabydń ju [[Special:UnlockDB|zasej spśistupniś]], gaž swójo zeźěłajoš.',
'unlockdbsuccesstext' => 'Datowa banka jo zasej pśistupna.',
'lockfilenotwritable' => 'Njejo móžno, blokěrowansku dataju datoweje banki změniś. Coš-lic datowu banku zamknuś abo zasej spśistupniś, dej webowy serwer měś pšawo, do njeje pisaś.',
'databasenotlocked'   => 'Datowa banka njejo zamknjona.',

# Move page
'move-page'                    => '$1 pśesunuś',
'move-page-legend'             => 'Bok pśesunuś',
'movepagetext'                 => "Z pomocu slědujucego formulara móžoš bok pśemjenjowaś, pśi comž se jogo wersije k nowemu mjenjoju pśesuwaju.
Stary titel wordujo dalejpósrědnjeński bok k nowemu titeloju.
Móžoš awtomatiski aktualizěrowaś dalejposrědkowanja, kótarež pokazuju na originalny titel.
Jolic njocoš, pśeglědaj za [[Special:DoubleRedirects|dwójnymi]] abo [[Special:BrokenRedirects|defektnymi daleposrědkowanjami]].
Sy zagronity, až wótkaze wjedu tam, źož maju wjasć.

Źiwaj na to, až se bok '''nje'''pśesuwa, jolic jo južo bok z nowym titelom, snaźkuli jo prozny abo dalejpósrědnjenje a njama stare wobźěłane wersije. To ma groniś, až móžoš bok zasej slědk pśemjenjowaś, jolic cyniš zmólku, a njemóžoš eksistěrujucy bok pśepisaś.

'''WARNOWANJE!'''
To móžo byś drastiska a njewocakowana změna za popularny bok;
pšosym zawěsć, až konsekwency rozmijoš, nježli až pókšacujoš.",
'movepagetalktext'             => "Pśisłušny diskusijny bok se sobu pśesunjo, '''ale nic gaž:'''
* eksistěrujo južo diskusijny bok z toś tym mjenim, abo gaž
* wótwólijoš toś tu funkciju.

W toś tyma padoma dej wopśimjeśe boka manualnje se pśesunuś resp. gromadu wjasć, jolic až to coš.",
'movearticle'                  => 'Bok pśesunuś',
'movenologin'                  => 'Njepśizjawjony(a)',
'movenologintext'              => 'Musyš zregistrěrowany wužywaŕ a [[Special:UserLogin|pśizjawjony]] byś, aby pśesunuł bok.',
'movenotallowed'               => 'Njamaš pšawo pśesuwaś boki.',
'movenotallowedfile'           => 'Njamaš pšawo dataje pśesunuś.',
'cant-move-user-page'          => 'Njamaš pšawo wužywarske boki pśesunuś (mimo pódbokow).',
'cant-move-to-user-page'       => 'Njamaš pšawo bok k wužywarskemu bokoju pśesunuś (z wuwześim k wužywarskemu pódbokoju).',
'newtitle'                     => 'nowy nadpis:',
'move-watch'                   => 'Toś ten bok wobglědowaś',
'movepagebtn'                  => 'Bok pśesunuś',
'pagemovedsub'                 => 'Bok jo se pśesunuł.',
'movepage-moved'               => '<big>\'\'\'Bok "$1" jo se do "$2" pśesunuł.\'\'\'</big>', # The two titles are passed in plain text as $3 and $4 to allow additional goodies in the message.
'movepage-moved-redirect'      => 'Dalejpósrědnjenje jo se napórało.',
'movepage-moved-noredirect'    => 'Napóranje dalejpósrědnjenja jo se pódtłocyło.',
'articleexists'                => 'Bok z takim mjenim južo eksistěrujo abo mě, kótarež sćo wuwzólił jo njepłaśece. Pšosym wuzwól nowe mě.',
'cantmove-titleprotected'      => 'Njamóžoš bok k toś tomu městnoju pśesunuś, dokulaž nowy titel jo pśeśiwo napóranjeju šćitany.',
'talkexists'                   => 'Samy bok jo se pśesunuł, ale pśisłušny diskusijny bok nic, dokulaž eksistěrujo južo taki bok z nowym mjenim. Pšosym pśirownaj wopśimjeśi manualnje.',
'movedto'                      => 'pśesunjony do',
'movetalk'                     => 'Diskusijny bok sobu pśesunuś.',
'move-subpages'                => 'Wše pódboki, jolic eksistěruju, sobu pśesunuś',
'move-talk-subpages'           => 'Wše pódboki diskusijnych bokow, jolic eksistěruju, sobu pśesunuś',
'movepage-page-exists'         => 'Bok $1 južo eksistěrujo a njedajo se awtomatiski pśepisaś.',
'movepage-page-moved'          => 'Bok $1 jo se do $2 pśesunuł.',
'movepage-page-unmoved'        => 'Bok $1 njejo se do $2 pśesunuś dał.',
'movepage-max-pages'           => 'Maksimalna licba $1 {{PLURAL:$1|boka|bokowu|bokow|bokow}} jo se pśesunuła a žedne dalšne wěcej njedaje se awtomatiski pśesunuś.',
'1movedto2'                    => '„[[$1]]“ pśesunjone na „[[$2]]“',
'1movedto2_redir'              => 'Nastawk „[[$1]]“ jo se pśesunuł na „[[$2]]“. Pśi tom jo jadno dalejpósrědnjenje se pśepisało.',
'move-redirect-suppressed'     => 'dakejpósrědnjenje pódtłocone',
'movelogpage'                  => 'Protokol pśesunjenjow',
'movelogpagetext'              => 'How jo lisćina wšyknych pśesunjonych bokow.',
'movereason'                   => 'Pśicyna',
'revertmove'                   => 'nawrośiś',
'delete_and_move'              => 'Wulašowaś a pśesunuś',
'delete_and_move_text'         => '==Celowy bok eksistěrujo - wulašowaś??==

Bok „[[:$1]]“ južo eksistěrujo. Coš jen wulašowaś, aby mógał toś ten bok pśesunuś?',
'delete_and_move_confirm'      => 'Jo, toś ten bok wulašowaś',
'delete_and_move_reason'       => 'wulašowane, aby było městno za pśesunjenje',
'selfmove'                     => 'Wuchadne a celowe mě stej identiskej; njejo móžno, bok na sam se pśesunuś.',
'immobile-source-namespace'    => 'Boki w mjenjowem rumje "$1" njedaju se pśesunuś',
'immobile-target-namespace'    => 'Boki njedaju se do mjenjowego ruma "$1" pśesunuś',
'immobile-target-namespace-iw' => 'Interwiki-wótkaz njejo płaśiwy cel za pśesunjenja bokow.',
'immobile-source-page'         => 'Toś ten bok njedajo se pśesunuś.',
'immobile-target-page'         => 'Njejo móžno na toś ten celowy bok pśesunuś.',
'imagenocrossnamespace'        => 'Dataja njedajo se pśesunuś do mjenjowego ruma, kótarež njejo za dataje.',
'imagetypemismatch'            => 'Nowy datajowy sufiks swójomu typoju njewótpowědujo',
'imageinvalidfilename'         => 'Mě celoweje dataje jo njepłaśiwe',
'fix-double-redirects'         => 'Dalejpósrědnjenja, kótarež wótkazuju na originalny titel, aktualizěrowaś',
'move-leave-redirect'          => 'Daleposrědnjenje zawóstajiś',

# Export
'export'            => 'Boki eksportěrowaś',
'exporttext'        => 'Móžoš tekst a stawizny boka abo skupiny bokow, kótarež su w XML zapisane, eksportěrowaś. Jo móžno je do drugeje wiki importěrowaś pśeź MediaWiki [[Special:Import|bok importěrowanja]].

Za eksportěrowanje bokow zapódaj nadpisma do dołojcnego tekstowogo póla, jadno nadpismo na smužku, a wuzwól nowe a stare wersije z wótkazami stawiznow boka abo jano aktualnu wersiju z informacijami wó slědnjej změnje.

W slědnem padźe móžoš teke wótkaz wužywaś, na pś. [[{{#Special:Export}}/{{MediaWiki:Mainpage}}]] za bok "[[{{MediaWiki:Mainpage}}]]".',
'exportcuronly'     => 'Jano aktualne wersije, bźez stawiznow',
'exportnohistory'   => "----
'''Pokazka:''' Eksportěrowanje cełych stawiznow bokow pśez toś ten formular njejo dla performancowych pśicyn tuchylu móžne.",
'export-submit'     => 'Eksportěrowaś',
'export-addcattext' => 'Pśidaś boki z kategorije:',
'export-addcat'     => 'Dodaś',
'export-download'   => 'Ako XML-dataju składowaś',
'export-templates'  => 'Pśedłogi zapśimjeś',

# Namespace 8 related
'allmessages'               => 'Systemowe zdźělenja',
'allmessagesname'           => 'Mě',
'allmessagesdefault'        => 'Standardny tekst',
'allmessagescurrent'        => 'Aktualny tekst',
'allmessagestext'           => 'How jo lisćina systemowych powěsćow w mjenowem rumje MediaWiki.
Pšosym wobglědaj [http://www.mediawiki.org/wiki/Localisation lokalizaciju MediaWiki] a [http://translatewiki.net translatewiki.net], jolic coš k lokalizaciji MediaWiki pśinosowaś.',
'allmessagesnotsupportedDB' => "'''{{ns:special}}:Allmessages''' njejo tuchylu móžno, dokulaž jo datowa banka offline.",
'allmessagesfilter'         => 'Filter za mjenja powěsćow:',
'allmessagesmodified'       => 'Jano změnjone pokazaś',

# Thumbnails
'thumbnail-more'           => 'Pówětšyś',
'filemissing'              => 'Dataja felujo',
'thumbnail_error'          => 'Zmólka pśi stwórjenju pśeglěda: $1',
'djvu_page_error'          => 'DjVu-bok pśesegujo wobłuk.',
'djvu_no_xml'              => 'Njejo móžno, XML za DjVu-dataju wótwołaś.',
'thumbnail_invalid_params' => 'Njepłaśece parametry pśeglěda',
'thumbnail_dest_directory' => 'Njejo móžno celowy zapis stwóriś.',

# Special:Import
'import'                     => 'Boki importěrowaś',
'importinterwiki'            => 'Transwiki-importěrowanje',
'import-interwiki-text'      => 'Wuzwól wiki a bok za importěrowanje.
Datumy wersijow a wužywarske mjenja pśi tym se njezměniju.
Wšykne transwiki-importowe akcije protokolěruju se w [[Special:Log/import|log-lisćinje importow]].',
'import-interwiki-source'    => 'Žrědłowy wiki/bok:',
'import-interwiki-history'   => 'Importěruj wšykne wersije toś togo boka',
'import-interwiki-submit'    => 'Importěrowaś',
'import-interwiki-namespace' => 'Celowy mjenjowy rum:',
'import-upload-filename'     => 'Datajowe mě:',
'import-comment'             => 'Komentar:',
'importtext'                 => 'Eksportěruj pšosym dataju ze žredlowego wikija z pomocu [[Special:Export|eksporteje funkcije]]. Składuj ju na swójom licadle a nagraj su sem.',
'importstart'                => 'Importěrowanje bokow...',
'import-revision-count'      => '$1 {{PLURAL:$1|wersija|wersiji|wersije}}',
'importnopages'              => 'Boki za importěrowanje njeeksistěruju.',
'importfailed'               => 'Zmólka pśi importěrowanju: $1',
'importunknownsource'        => 'Njeznate źrědło importěrowanja.',
'importcantopen'             => 'Dataja za importěrowanje njejo se dała wócyniś.',
'importbadinterwiki'         => 'Njepłaśecy interwikijowy wótkaz',
'importnotext'               => 'Prozdne abo bźez teksta',
'importsuccess'              => 'Import dokóńcony!',
'importhistoryconflict'      => 'Konflikt wersijow (snaź jo toś ten bok južo raz se importěrował)',
'importnosources'            => 'Za transwikijowe importěrowanje njejsu žrědła definěrowane, direktne stawizny uploadowanja su znjemóžnjone.',
'importnofile'               => 'Žedna dataja za importěrowanje njejo se uploadowała.',
'importuploaderrorsize'      => 'Uploadowanje importoweje dataje jo se njeraźiło. Dataja jo wětša ako dowólona wjelikosć datajow.',
'importuploaderrorpartial'   => 'Uploadowanje importoweje dataje jo se njeraźiło. Dataja jo se jano pó źělach uploadowała.',
'importuploaderrortemp'      => 'Uploadowanje importoweje dataje jo se njeraźiło. Temporarny zapis feluje.',
'import-parse-failure'       => 'Zmólka pśi XML-imporśe:',
'import-noarticle'           => 'Žeden bok za import!',
'import-nonewrevisions'      => 'Wšykne wersije buchu južo pjerwjej importowane.',
'xml-error-string'           => '$1 smužka $2, słup $3, (Byte $4): $5',
'import-upload'              => 'XML-daty nagraś',
'import-token-mismatch'      => 'Zgubjenje posejźeńskich datow. Pšosym wopytaj hyšći raz.',
'import-invalid-interwiki'   => 'Njejo móžno importěrowaś z pódanego wikija.',

# Import log
'importlogpage'                    => 'Log-lisćinu importěrowaś',
'importlogpagetext'                => 'Administratiwne importěrowanje bokow ze stawiznami z drugich wikijow.',
'import-logentry-upload'           => 'Dataja [[$1]] jo pśez uploadowanje se importěrowała.',
'import-logentry-upload-detail'    => '{{PLURAL:$1|$1 wersija|$1 wersiji|$1 wersije}}',
'import-logentry-interwiki'        => 'Dataja $1 jo se importěrowała (transwiki).',
'import-logentry-interwiki-detail' => '{{PLURAL:$1|$1 wersija|$1 wersiji|$1 wersije}} wót $2',

# Tooltip help for the actions
'tooltip-pt-userpage'             => 'Twój wužywarski bok',
'tooltip-pt-anonuserpage'         => 'Wužywarski bok za IP-adresu, z kótarejuž bok wobźěłajoš',
'tooltip-pt-mytalk'               => 'Twój diskusijny bok',
'tooltip-pt-anontalk'             => 'Diskusija wó změnach z tuteje IP-adresy.',
'tooltip-pt-preferences'          => 'Móje pśistajenja',
'tooltip-pt-watchlist'            => 'Lisćina wobglědowańkow',
'tooltip-pt-mycontris'            => 'Lisćina twójich pśinoskow',
'tooltip-pt-login'                => 'Pśizjawjenje njejo obligatoriske, ale lubje witane.',
'tooltip-pt-anonlogin'            => 'Pśizjawjenje njejo obligatoriske, ale lubje witane.',
'tooltip-pt-logout'               => 'Wótzjawiś',
'tooltip-ca-talk'                 => 'Diskusija wó wopśimjeśu boka',
'tooltip-ca-edit'                 => 'Móžoš bok wobźěłaś. Nježlic składujoš, wužywaj pšosym funkciju "pśeglěd".',
'tooltip-ca-addsection'           => 'Nowy wótrězk zachopiś',
'tooltip-ca-viewsource'           => 'Bok jo šćitany. Jo móžno, žrědłowy tekst woglědaś.',
'tooltip-ca-history'              => 'Něgajšne wersije togo boka.',
'tooltip-ca-protect'              => 'Toś ten bok šćitaś',
'tooltip-ca-delete'               => 'Toś ten bok wulašowaś',
'tooltip-ca-undelete'             => 'Zapise pśed wulašowanim boka nawrośiś.',
'tooltip-ca-move'                 => 'Toś ten bok pśesunuś',
'tooltip-ca-watch'                => 'Dodaj toś ten bok do swójeje wobglědowańskeje lisćiny.',
'tooltip-ca-unwatch'              => 'Bok z wobglědowańskeje lisćiny wulašowaś',
'tooltip-search'                  => 'Pśepytaś {{SITENAME}}',
'tooltip-search-go'               => 'Źi direktnje na bok z toś tym mjenim.',
'tooltip-search-fulltext'         => 'Toś ten tekst w bokach pytaś',
'tooltip-p-logo'                  => 'Głowny bok',
'tooltip-n-mainpage'              => 'Glowny bok pokazaś',
'tooltip-n-portal'                => 'Wó portalu, co móžoš cyniś, źo co namakajoš',
'tooltip-n-currentevents'         => 'Slězynowe informacije k aktualnym tšojenjam',
'tooltip-n-recentchanges'         => 'Lisćina aktualnych změnow w(e) {{SITENAME}}.',
'tooltip-n-randompage'            => 'Pśipadny bok',
'tooltip-n-help'                  => 'Pomocny bok pokazaś',
'tooltip-t-whatlinkshere'         => 'Lisćina wšyknych wiki bokow, kótarež how wótkazuju',
'tooltip-t-recentchangeslinked'   => 'Aktualne změny w bokach, na kótarež toś ten bok wótkazujo',
'tooltip-feed-rss'                => 'RSS-feed za toś ten bok',
'tooltip-feed-atom'               => 'Atom-feed za toś ten bok',
'tooltip-t-contributions'         => 'Pśinoski togo wužywarja wobglědowaś',
'tooltip-t-emailuser'             => 'Wužywarjeju e-mail pósłaś',
'tooltip-t-upload'                => 'Dataje nagraś',
'tooltip-t-specialpages'          => 'Lisćina wšyknych specialnych bokow',
'tooltip-t-print'                 => 'Śišćańska wersija boka',
'tooltip-t-permalink'             => 'Stawny wótkaz na toś tu wersiju boka',
'tooltip-ca-nstab-main'           => 'Wopśimjeśe pokazaś',
'tooltip-ca-nstab-user'           => 'Wužywarski bok pokazaś',
'tooltip-ca-nstab-media'          => 'Pokazaś bok medijow/datajow.',
'tooltip-ca-nstab-special'        => 'To jo specialny bok, kótaryž njedajo se wobźěłaś.',
'tooltip-ca-nstab-project'        => 'Portal pokazaś',
'tooltip-ca-nstab-image'          => 'Bok z datajami pokazaś',
'tooltip-ca-nstab-mediawiki'      => 'Systemowy tekst pokazaś',
'tooltip-ca-nstab-template'       => 'Pśedłogu pokazaś',
'tooltip-ca-nstab-help'           => 'Pomocny bok pokazaś',
'tooltip-ca-nstab-category'       => 'Bok kategorijow pokazaś',
'tooltip-minoredit'               => 'Změnu ako drobnu markěrowaś',
'tooltip-save'                    => 'Změny składowaś',
'tooltip-preview'                 => "Pšosym '''pśeglěd změnow''' wužywaś, nježlic až składujoš!",
'tooltip-diff'                    => 'Pokazujo změny teksta w tabelariskej formje.',
'tooltip-compareselectedversions' => 'Wuzwólonej wersiji boka pśirownowaś',
'tooltip-watch'                   => 'Toś ten bok wobglědowańkam dodaś',
'tooltip-recreate'                => 'Bok nawrośiś, lěcrowno jo był wulašowany',
'tooltip-upload'                  => 'Z uploadowanim zachopiś',
'tooltip-rollback'                => '"Roolback" anulěrujo změny slědnego wužywarja na toś tom boku z jadnym kliknjenim.',
'tooltip-undo'                    => 'Anulěrujo toś tu změnu a wócynijo wobźěłański formular w pśeglědowem modusu.
W zespominanju dajo se pśicyna pódaś.',

# Stylesheets
'common.css'   => '/** Na toś tom městnje wustatkujo se CSS na wšykne šaty. */',
'monobook.css' => '/* How zaměstnjony CSS wustatkujo se na wužywarje monobook-šata */',

# Scripts
'common.js'   => '/* Kuždy JavaScript how lodujo se za wšykne wužywarje na kuždem boce. */',
'monobook.js' => '/* Slědujucy JavaScript zacytajo se za wužywarjow, kótarež skin MonoBook wužywaju */',

# Metadata
'nodublincore'      => 'Metadaty Dublin Core RDF su za toś ten serwer deaktiwěrowane.',
'nocreativecommons' => 'Metadaty Creative Commons RDF su za toś ten serwer deaktiwěrowane.',
'notacceptable'     => 'Wiki-serwer njamóžo daty za twój klient wobźěłaś.',

# Attribution
'anonymous'        => '{{PLURAL:$1|Anonymny wužywaŕ|Anonymnej wužywarja|Anonymne wužywarje}} na {{SITENAME}}',
'siteuser'         => '{{SITENAME}}-wužywaŕ $1',
'lastmodifiedatby' => 'Toś ten bok jo slědny raz se wobźěłał $2, $1 góź. wót wužywarja $3.', # $1 date, $2 time, $3 user
'othercontribs'    => 'Bazěrujo na źěle $1',
'others'           => 'druge',
'siteusers'        => '{{SITENAME}} {{PLURAL:$2|wužywaŕ|wužiwarja|wužywarje}} $1',
'creditspage'      => 'Informacija wó boku',
'nocredits'        => 'Njeeksistěruju žedne informacije za toś ten bok.',

# Spam protection
'spamprotectiontitle' => 'Spamowy filter',
'spamprotectiontext'  => 'Bok, kótaryž coš składowaś, jo se wót spamowego filtra blokěrował. To nejskerjej zawinujo wótkaz na eksterne sydło w carnej lisćinje.',
'spamprotectionmatch' => "'''Spamowy filter jo slědujucy tekst namakał: ''$1'''''",
'spambot_username'    => 'MediaWikijowe spamowe rěšenje',
'spam_reverting'      => 'Nawrośijo se slědna wersija, kótaraž njejo wopśimjeła wótkaz na $1.',
'spam_blanking'       => 'Wšykne wersije su wopśimowali wótkaze na $1, do rěcha spórane.',

# Info page
'infosubtitle'   => 'Informacija wó boku',
'numedits'       => 'Licba změnow boka: $1',
'numtalkedits'   => 'Licba změnow diskusijnego boka: $1',
'numwatchers'    => 'Licba  wobglědowarjow: $1',
'numauthors'     => 'Licba awtorow: $1',
'numtalkauthors' => 'Licba diskutěrujucych: $1',

# Skin names
'skinname-standard'    => 'Klasiski',
'skinname-nostalgia'   => 'Nostalgiski',
'skinname-cologneblue' => 'Kölnski Módry',
'skinname-monobook'    => 'MonoBook',
'skinname-myskin'      => 'Mój šat',
'skinname-chick'       => 'Kurjetko',
'skinname-simple'      => 'Jadnorje',
'skinname-modern'      => 'Moderny',

# Math options
'mw_math_png'    => 'Pśecej ako PNG zwobrazniś.',
'mw_math_simple' => 'Jadnory TeX ako HTML, howacej PNG',
'mw_math_html'   => 'Jo-lic móžno ako HTML, howacej PNG',
'mw_math_source' => 'Ako TeX wóstajiś (za tekstowe browsery)',
'mw_math_modern' => 'Pórucyjo se za moderne browsery',
'mw_math_mathml' => 'Jo-lic móžno - MathML (eksperimentelny)',

# Patrolling
'markaspatrolleddiff'                 => 'Ako kontrolěrowane markěrowaś',
'markaspatrolledtext'                 => 'Markěruj toś ten bok ako kontrolěrowany',
'markedaspatrolled'                   => 'jo se ako kontrolěrowany markěrował',
'markedaspatrolledtext'               => 'Wuzwólona wersija jo se markěrowała ako kontrolěrowana.',
'rcpatroldisabled'                    => 'Kontrolěrowanje slědnych změnow jo se znjemóžniło.',
'rcpatroldisabledtext'                => 'Kontrolěrowanje slědnych změnow jo tuchylu se znjemóžniło.',
'markedaspatrollederror'              => 'Markěrowanje ako "kontrolěrowane" njejo móžne.',
'markedaspatrollederrortext'          => 'Musyš wersiju wuzwóliś.',
'markedaspatrollederror-noautopatrol' => 'Njesmějoš swóje změny ako kontrolěrowane markěrowaś.',

# Patrol log
'patrol-log-page'      => 'Protokol kontrolow',
'patrol-log-header'    => 'To jo protokol pśekontrolowanych wersijow.',
'patrol-log-line'      => 'markěrował $1 wót $2 ako kontrolěrowane $3.',
'patrol-log-auto'      => '(awtomatiski)',
'patrol-log-diff'      => 'Wersija $1',
'log-show-hide-patrol' => 'Protokol doglědowanja $1',

# Image deletion
'deletedrevision'                 => 'wulašowana stara wersija: $1',
'filedeleteerror-short'           => 'Zmólka pśi wulašowanju dataje: $1',
'filedeleteerror-long'            => 'Pśi wulašowanju dataje su se zwěsćili zmólki:

$1',
'filedelete-missing'              => 'Dataja „$1“ njamóžo se wulašowaś, dokulaž njeeksistěrujo.',
'filedelete-old-unregistered'     => 'Pódana wersija „$1“ w datowej bance njeeksistěrujo.',
'filedelete-current-unregistered' => 'Pódana dataja „$1“ w datowej bance njeeksistěrujo.',
'filedelete-archive-read-only'    => 'Webserwer njamóžo do archiwowego zapisa „$1“ pisaś.',

# Browsing diffs
'previousdiff' => '← pśedchadna změna',
'nextdiff'     => 'Pśiduca změna →',

# Visual comparison
'visual-comparison' => 'Wizuelne pśirownanje',

# Media information
'mediawarning'         => "'''Glědaj!''' Toś ta sorta datajow móžo wopśimjeś złosny programowy kod. Ześěgnjo-lic a wócynijo-lic se dataja, móžo se Twój kompjuter wobškóźeś.<hr />",
'imagemaxsize'         => "Maksimalna wobrazowa wjelikosć:<br />'' (za boki datajowego wopisanja)''",
'thumbsize'            => 'Rozměra miniaturow:',
'widthheightpage'      => '$1×$2, $3 {{PLURAL:$3|bok|boka|boki|bokow}}',
'file-info'            => '(wjelikosć dataje: $1, MIME-Typ: $2)',
'file-info-size'       => '($1 × $2 pikselow, wjelikosć dataje: $3, MIME-Typ: $4)',
'file-nohires'         => '<small>Wuše wótgranicowanje njeeksistěrujo.</small>',
'svg-long-desc'        => '(dataja SVG, nominalnje: $1 × $2 piksele, wjelikosć dataje: $3)',
'show-big-image'       => 'Połne optiske wótgranicowanje.',
'show-big-image-thumb' => '<small>wjelikosć pśeglěda: $1 × $2 pikselow</small>',

# Special:NewFiles
'newimages'             => 'Nowe dataje',
'imagelisttext'         => "How jo lisćina '''$1''' {{PLURAL:$1|dataje|datajowu|datajow}}, sortěrowane $2.",
'newimages-summary'     => 'Toś ten specialny bok pokazujo wobraze a dataje, kótarež ako slědne su se uploadowali.',
'newimages-legend'      => 'Filter',
'newimages-label'       => 'Datajowe mě (abo źěl z togo):',
'showhidebots'          => '(awtomatiske programy (boty) $1)',
'noimages'              => 'Žedne dataje njejsu se namakali.',
'ilsubmit'              => 'Pytaś',
'bydate'                => 'pó datumje',
'sp-newimages-showfrom' => 'Pokaž nowe dataje wót $1, $2',

# Bad image list
'bad_image_list' => 'Format jo slědujucy:

Jano smužki, kótarež zachopiju z *, se wugódnośiju. Prědny wótkaz na smužce musy wótkaz na njekśětu dataju byś.
Slědujuce wótkaze w tej samej smužce se za wuwześa naglědaju, w kótarychž móžo dataja weto se pokazaś.',

# Metadata
'metadata'          => 'Metadaty',
'metadata-help'     => 'Toś ta dataja wopśimjejo pśidatne informacije, kótarež nejskerjej póchadaju wót digitalneje kamery abo scannera. Jolic dataja bu pozdźej změnjona, njeby mógli někotare detaile změnjonu dataju wótbłyšćowaś.',
'metadata-expand'   => 'rozšyrjone detaile pokazaś',
'metadata-collapse' => 'rozšyrjone detaile schowaś',
'metadata-fields'   => 'Slědujuce póla EXIF-metadatow se pokazuju na bokach, kótarež wopisuju wobraze; dalšne detaile, kótarež normalnje su schowane, mógu se pśidatnje pokazaś.

* make
* model
* datetimeoriginal
* exposuretime
* fnumber
* focallength', # Do not translate list items

# EXIF tags
'exif-imagewidth'                  => 'Šyrokosć',
'exif-imagelength'                 => 'Wusokosć',
'exif-bitspersample'               => 'Bity na komponentu',
'exif-compression'                 => 'Wašnja kompriměrowanja',
'exif-photometricinterpretation'   => 'Zestajenje pikselow',
'exif-orientation'                 => 'Wusměrjenje kamery',
'exif-samplesperpixel'             => 'Licba komponentow',
'exif-planarconfiguration'         => 'Struktura datow',
'exif-ycbcrsubsampling'            => 'Subsamplingowa rata wót Y do C',
'exif-ycbcrpositioning'            => 'Pozicijoněrowanje Y a C',
'exif-xresolution'                 => 'Horicontalne optiske wótgranicowanje',
'exif-yresolution'                 => 'Wertikalne optiske wótgranicowanje',
'exif-resolutionunit'              => 'Měra optiskego wótgranicowanja',
'exif-stripoffsets'                => 'městnosć wobrazowych datow',
'exif-rowsperstrip'                => 'Licba smužkow na rědku',
'exif-stripbytecounts'             => 'Byty na kompriměrowanu rědku',
'exif-jpeginterchangeformat'       => 'Offset k JPEG SOI',
'exif-jpeginterchangeformatlength' => 'Byty JPEG-dataje',
'exif-transferfunction'            => 'Funkcija pśestajenja',
'exif-whitepoint'                  => 'kwalita barwy běłego dypka',
'exif-primarychromaticities'       => 'Kwalita barwy primarnych barwow.',
'exif-ycbcrcoefficients'           => 'YCbCr-koeficienty',
'exif-referenceblackwhite'         => 'Pórik carneje a běłeje referencneje gódnoty',
'exif-datetime'                    => 'Cas składowanja',
'exif-imagedescription'            => 'Mě wobraza',
'exif-make'                        => 'Zgótowaŕ kamery',
'exif-model'                       => 'Model kamery',
'exif-software'                    => 'Softwara',
'exif-artist'                      => 'Awtor',
'exif-copyright'                   => 'Wobsejźaŕ stwóriśelskich pšawow',
'exif-exifversion'                 => 'Wersija Exif',
'exif-flashpixversion'             => 'Pódpěrana wersija Flashpix',
'exif-colorspace'                  => 'Barwowy rum',
'exif-componentsconfiguration'     => 'Wóznam jadnotliwych komponentow',
'exif-compressedbitsperpixel'      => 'Kompriměrowane bity na piksel',
'exif-pixelydimension'             => 'Dopušćona šyrokosć wobraza',
'exif-pixelxdimension'             => 'Dopušćona wusokosć wobraza',
'exif-makernote'                   => 'Noticy zgótowarja',
'exif-usercomment'                 => 'Komentary wužywarja',
'exif-relatedsoundfile'            => 'Pśisłušna zukowa dataja',
'exif-datetimeoriginal'            => 'Datum a cas wutwórjenja datow',
'exif-datetimedigitized'           => 'Datum a cas digitalizěrowanja',
'exif-subsectime'                  => 'Źěły sekundow za datum a cas (1/100 s)',
'exif-subsectimeoriginal'          => 'Źěły sekundow za datum a cas wutwórjenja datow (1/100 s)',
'exif-subsectimedigitized'         => 'Źěły sekundow za datum a cas digitalizěrowanja (1/100 s)',
'exif-exposuretime'                => 'Cas wobswětlenja',
'exif-exposuretime-format'         => '$1 sek ($2)',
'exif-fnumber'                     => 'Blenda',
'exif-exposureprogram'             => 'Program wobswětlenja',
'exif-spectralsensitivity'         => 'Spektralna cuśiwosć',
'exif-isospeedratings'             => 'Cuśiwosć filma abo sensora (ISO)',
'exif-oecf'                        => 'Optoelektroniski pśelicowański faktor (OECF)',
'exif-shutterspeedvalue'           => 'Gódnota wobswětleńskego casa',
'exif-aperturevalue'               => 'Blenda',
'exif-brightnessvalue'             => 'Swětłosć',
'exif-exposurebiasvalue'           => 'Směrnica za wobswětlenje',
'exif-maxaperturevalue'            => 'Nejžwětša blenda',
'exif-subjectdistance'             => 'zdalonosć',
'exif-meteringmode'                => 'Wašnja měrjenja',
'exif-lightsource'                 => 'Žrědło swětła',
'exif-flash'                       => 'Błysk',
'exif-focallength'                 => 'Palna dalokosć',
'exif-subjectarea'                 => 'wobłuk',
'exif-flashenergy'                 => 'mócnosć błyska',
'exif-spatialfrequencyresponse'    => 'Cuśiwosć rumoweje frekwence',
'exif-focalplanexresolution'       => 'horicontalne optiske wótgranicowanje sensora',
'exif-focalplaneyresolution'       => 'wertikalne optiske wótgranicowanje sensora',
'exif-focalplaneresolutionunit'    => 'Jadnotka optiskego wótgranicowanja sensora',
'exif-subjectlocation'             => 'Městno motiwa',
'exif-exposureindex'               => 'Indeks wobswětlenja',
'exif-sensingmethod'               => 'wašnja měrjenja',
'exif-filesource'                  => 'Žrědło dataje',
'exif-scenetype'                   => 'Typ sceny',
'exif-cfapattern'                  => 'Muster CFA',
'exif-customrendered'              => 'Wót wužywarja definěrowane wobźěłanje wobraza',
'exif-exposuremode'                => 'Modus wobswětlenja',
'exif-whitebalance'                => 'Balansa běłosći',
'exif-digitalzoomratio'            => 'digitalne zoomowanje',
'exif-focallengthin35mmfilm'       => 'Palna dalokosć (wótpowědnik za małe wobraze)',
'exif-scenecapturetype'            => 'wašnja nagraśa',
'exif-gaincontrol'                 => 'Regulěrowanje sceny',
'exif-contrast'                    => 'kontrast',
'exif-saturation'                  => 'naseśenje',
'exif-sharpness'                   => 'wótšosć',
'exif-devicesettingdescription'    => 'Nastajenja aparata',
'exif-subjectdistancerange'        => 'Zdalonosć motiwa',
'exif-imageuniqueid'               => 'Jadnorazny ID wobraza',
'exif-gpsversionid'                => 'Wersija taga GPS',
'exif-gpslatituderef'              => 'Pódpołnocna abo pódpołdnjowa šyrina',
'exif-gpslatitude'                 => 'Šyrina',
'exif-gpslongituderef'             => 'Pódzajtšna abo pódwjacorna dliń',
'exif-gpslongitude'                => 'Dliń',
'exif-gpsaltituderef'              => 'Referencna wusokosć',
'exif-gpsaltitude'                 => 'Wusokosć',
'exif-gpstimestamp'                => 'GPS-cas',
'exif-gpssatellites'               => 'Za měrjenje wužywane satelity',
'exif-gpsstatus'                   => 'Status pśidostawaka',
'exif-gpsmeasuremode'              => 'wašnja měrjenja',
'exif-gpsdop'                      => 'dokradnosć měry',
'exif-gpsspeedref'                 => 'Jadnotka spěšnosći',
'exif-gpsspeed'                    => 'Spěšnosć GPS-pśidostawaka',
'exif-gpstrackref'                 => 'Referenca za směr pógibowanja',
'exif-gpstrack'                    => 'směr pógibowanja',
'exif-gpsimgdirectionref'          => 'Referenca směra wobraza',
'exif-gpsimgdirection'             => 'Směr wobraza',
'exif-gpsmapdatum'                 => 'Wužyte geodetiske dataje',
'exif-gpsdestlatituderef'          => 'Referenca šyriny celowego městna',
'exif-gpsdestlatitude'             => 'Šyrina celowego městna',
'exif-gpsdestlongituderef'         => 'Referenca dlini celowego městna',
'exif-gpsdestlongitude'            => 'Dliń abo celowe městno',
'exif-gpsdestbearingref'           => 'Referenca za wusměrjenje',
'exif-gpsdestbearing'              => 'Wusměrjenje',
'exif-gpsdestdistanceref'          => 'Referenca za distancu k celowemu městnu',
'exif-gpsdestdistance'             => 'Distanca k celowemu městnu',
'exif-gpsprocessingmethod'         => 'Mě metody pśeźěłanja GPS',
'exif-gpsareainformation'          => 'Mě wobcerka GPS',
'exif-gpsdatestamp'                => 'Datum GPS',
'exif-gpsdifferential'             => 'Diferencialna korektura GPS',

# EXIF attributes
'exif-compression-1' => 'Njekompriměrowany',

'exif-unknowndate' => 'Njeznaty datum',

'exif-orientation-1' => 'Normalny', # 0th row: top; 0th column: left
'exif-orientation-2' => 'horicontalnje wobrośony', # 0th row: top; 0th column: right
'exif-orientation-3' => 'Pśewobrośony', # 0th row: bottom; 0th column: right
'exif-orientation-4' => 'wertikalnje wobrośony', # 0th row: bottom; 0th column: left
'exif-orientation-5' => 'Wobrośony wó 90° nalěwo a wertikalnje', # 0th row: left; 0th column: top
'exif-orientation-6' => 'Wobrośony wó 90° napšawo', # 0th row: right; 0th column: top
'exif-orientation-7' => 'Wobrośony wó 90° napšawo a wertikalnje', # 0th row: right; 0th column: bottom
'exif-orientation-8' => 'Wobrośony wó 90° nalěwo', # 0th row: left; 0th column: bottom

'exif-planarconfiguration-1' => 'gropny format',
'exif-planarconfiguration-2' => 'płony format',

'exif-xyresolution-i' => '$1 dpi (dypkow na col)',

'exif-componentsconfiguration-0' => 'njeeksistěrujo',

'exif-exposureprogram-0' => 'Njedefiněrowane',
'exif-exposureprogram-1' => 'manualnje',
'exif-exposureprogram-2' => 'Normalny program',
'exif-exposureprogram-3' => 'Priorita blendy',
'exif-exposureprogram-4' => 'Priorita blendy',
'exif-exposureprogram-5' => 'Kreatiwny program (wjelika dłym wótšosći)',
'exif-exposureprogram-6' => 'Aktiwny program (wjelika malsnosć momentoweje bildki)',
'exif-exposureprogram-7' => 'portretowy modus (za closeup-fotografije z njefokusěrowaneju slězynu)',
'exif-exposureprogram-8' => 'wobraze krajiny',

'exif-subjectdistance-value' => '{{PLURAL:$1|$1 meter|$1 metra|$1 metry}}',

'exif-meteringmode-0'   => 'Njeznaty',
'exif-meteringmode-1'   => 'Pśerězna gódnota',
'exif-meteringmode-2'   => 'srjejźa wusměrjone',
'exif-meteringmode-3'   => 'Spot',
'exif-meteringmode-4'   => 'MultiSpot',
'exif-meteringmode-5'   => 'Muster',
'exif-meteringmode-6'   => 'Źělny',
'exif-meteringmode-255' => 'Drugi',

'exif-lightsource-0'   => 'Njeznaty',
'exif-lightsource-1'   => 'Dnjowne swětło',
'exif-lightsource-2'   => 'Fluorescentny',
'exif-lightsource-3'   => 'Žaglawka',
'exif-lightsource-4'   => 'Błysk',
'exif-lightsource-9'   => 'Rědne wjedro',
'exif-lightsource-10'  => 'Mrokawe wjedro',
'exif-lightsource-11'  => 'Seń',
'exif-lightsource-12'  => 'Dnjowe swětło fluorescentne (D 5700 – 7100K)',
'exif-lightsource-13'  => 'Dnjowoběły fluorescentny (N 4600 – 5400K)',
'exif-lightsource-14'  => 'Zymny běły fluorescentny (W 3900 – 4500K)',
'exif-lightsource-15'  => 'Běły fluorescentny (WW 3200 – 3700K)',
'exif-lightsource-17'  => 'Standardne swětło A',
'exif-lightsource-18'  => 'Standardne swětło B',
'exif-lightsource-19'  => 'Standardne swětło C',
'exif-lightsource-24'  => 'ISO studijowe swětło',
'exif-lightsource-255' => 'Druge žrědło swětła',

# Flash modes
'exif-flash-fired-0'    => 'Błysk njejo se zapusćił',
'exif-flash-fired-1'    => 'Błysk jo se zapusćił',
'exif-flash-return-0'   => 'žedna funkcija za nadejźenje refleksije fotobłyska',
'exif-flash-return-2'   => 'Refleksija fotobłyska njejo se nadejšła',
'exif-flash-return-3'   => 'Refleksija fotobłyska jo se nadejšła',
'exif-flash-mode-1'     => 'wunuźone błysknjenje',
'exif-flash-mode-2'     => 'wunuźone błysknjenje pódtłocone',
'exif-flash-mode-3'     => 'awtomatiski modus',
'exif-flash-function-1' => 'Njejo błyskowa funkcija',
'exif-flash-redeye-1'   => 'Modus redukcije cerwjenych wócow',

'exif-focalplaneresolutionunit-2' => 'cole',

'exif-sensingmethod-1' => 'Njedefiněrujobny',
'exif-sensingmethod-2' => 'Jadnochipowy barwowy sensor ruma',
'exif-sensingmethod-3' => 'Dwuchipowy barwowy sensor ruma',
'exif-sensingmethod-4' => 'Tśichipowy barwowy sensor ruma',
'exif-sensingmethod-5' => 'Sekwencielny barwowy sensor ruma',
'exif-sensingmethod-7' => 'Tśilinearny sensor',
'exif-sensingmethod-8' => 'Sekwencielny barwowy linearny sensor',

'exif-scenetype-1' => 'Direktnje fotografěrowany wobraz',

'exif-customrendered-0' => 'Normalne wobźěłanje',
'exif-customrendered-1' => 'Wužywarske wobźěłanje',

'exif-exposuremode-0' => 'Awtomatiske wobswětlenje',
'exif-exposuremode-1' => 'Manuelna blenda',
'exif-exposuremode-2' => 'Awtoblenda',

'exif-whitebalance-0' => 'Awtomatiska rownowaga běłosći',
'exif-whitebalance-1' => 'Manuelna rownowaga běłosći',

'exif-scenecapturetype-0' => 'Standard',
'exif-scenecapturetype-1' => 'Krajina',
'exif-scenecapturetype-2' => 'Portret',
'exif-scenecapturetype-3' => 'Nocna scena',

'exif-gaincontrol-0' => 'Žedne',
'exif-gaincontrol-1' => 'Małe zmócnjenje',
'exif-gaincontrol-2' => 'wjelike zmócnjenje',
'exif-gaincontrol-3' => 'małe wósłabjenje',
'exif-gaincontrol-4' => 'Wjelike wósłabjenje',

'exif-contrast-0' => 'Normalny',
'exif-contrast-1' => 'Słaby',
'exif-contrast-2' => 'Mócny',

'exif-saturation-0' => 'Normalny',
'exif-saturation-1' => 'małe naseśenje',
'exif-saturation-2' => 'wjelike naseśenje',

'exif-sharpness-0' => 'Normalny',
'exif-sharpness-1' => 'Słaby',
'exif-sharpness-2' => 'Mócny',

'exif-subjectdistancerange-0' => 'Njeznaty',
'exif-subjectdistancerange-1' => 'makro',
'exif-subjectdistancerange-2' => 'Bliski rozglěd',
'exif-subjectdistancerange-3' => 'Daloki rozglěd',

# Pseudotags used for GPSLatitudeRef and GPSDestLatitudeRef
'exif-gpslatitude-n' => 'Pódpołnocna šyrina',
'exif-gpslatitude-s' => 'Pódpołdnjowa šyrina',

# Pseudotags used for GPSLongitudeRef and GPSDestLongitudeRef
'exif-gpslongitude-e' => 'Pódzajtšna dliń',
'exif-gpslongitude-w' => 'Pódwjacorna dliń',

'exif-gpsstatus-a' => 'Měrjenje w běgu',
'exif-gpsstatus-v' => 'kompatibelnosć měry',

'exif-gpsmeasuremode-2' => '2-dimensionalne měrjenje',
'exif-gpsmeasuremode-3' => '3-dimensionalne měrjenje',

# Pseudotags used for GPSSpeedRef and GPSDestDistanceRef
'exif-gpsspeed-k' => 'Kilometry na góźinu',
'exif-gpsspeed-m' => 'Mile na góźinu',
'exif-gpsspeed-n' => 'Suki',

# Pseudotags used for GPSTrackRef, GPSImgDirectionRef and GPSDestBearingRef
'exif-gpsdirection-t' => 'Wopšawdny směr',
'exif-gpsdirection-m' => 'Magnetiski směr',

# External editor support
'edit-externally'      => 'Dataje z eksternym programom wobźěłaś',
'edit-externally-help' => '(Za dalšne informacije glědaj [http://www.mediawiki.org/wiki/Manual:External_editors instalaciske instrukcije]).',

# 'all' in various places, this might be different for inflected languages
'recentchangesall' => 'wšykne',
'imagelistall'     => 'wšykne',
'watchlistall2'    => 'wšykne',
'namespacesall'    => 'wšykne',
'monthsall'        => 'wšykne',

# E-mail address confirmation
'confirmemail'             => 'E-mailowu adresu wobkšuśiś.',
'confirmemail_noemail'     => 'W swójich [[Special:Preferences|nastajenjach]] njejsy płaśecu e-mailowu adresu zapódał.',
'confirmemail_text'        => '{{SITENAME}} pomina, až wobkšuśijoš swóju e-mailowu adresu, nježlic až móžoš e-mailowe funkcije wužywaś. Tłocyš-lic na tłocatko, dostanjoš e-mailku, w kótarejž jo wótkaz z wobkšuśenskim gronidłom. Tłocenje na wótkaz wobkšuśijo, až twója e-mailowa adresa jo korektna.',
'confirmemail_pending'     => '<div class="error">Tebje jo južo jadno wobkšuśeńske gronidło se pśimailowało. Sy-lic swójo wužywarske konto akle gano wutwórił, ga pócakaj hyšći žedne minuty na e-mail, nježlic až pominaš nowe gronidło.</div>',
'confirmemail_send'        => 'Wobkšuśeńske gronidło pósłaś',
'confirmemail_sent'        => 'Wobkšuśeńska e-mailka pósłana.',
'confirmemail_oncreate'    => 'Na Twóju adresu jo se wótpósłało wobkšuśeńske gronidło. Toś ten kod njejo notny za pśizjawjenje, ale za aktiwěrowanje e-mailowych funkcijow we wikiju.',
'confirmemail_sendfailed'  => '{{SITENAME}} njejo se mógła twóju wobkšuśensku e-mail pósłaś. Pšosym pśeglědaj swóju e-mailowu adresu na njepłaśiwe znamuška.

E-mailowy program jo wrośił: $1',
'confirmemail_invalid'     => 'Njepłaśece wobkšuśeńske gronidło. Snaź jo kod mjaztym płaśiwosć zgubił.',
'confirmemail_needlogin'   => 'Dejš $1 aby swóju e-mailowu adresu wobkšuśił.',
'confirmemail_success'     => 'Twója e-mailowa adresa jo wobkšuśona, móžoš se pśizjawiś.',
'confirmemail_loggedin'    => 'Twója e-mailowa adresa jo něnto wobkšuśona.',
'confirmemail_error'       => 'Zmólka pśi wobkšuśenju e-mailoweje adresy.',
'confirmemail_subject'     => '{{SITENAME}} - Wobkšuśenje e-mailoweje adrese',
'confirmemail_body'        => 'Něchten, nejskerjej ty z adresy $1, jo na boku {{SITENAME}} wužywarske konto "$2" z toś teju e-mailoweju adresu zregistrěrował.

Aby wobkšuśił, až toś to konto napšawdu śi słuša a aby e-mailowe funkcije na boce {{SITENAME}} aktiwěrował, wócyń toś ten wótkaz w swójim browserje:

$3

Jolic až *njejsy* toś to konto zregistrěrował, slěduj toś tomu wótkazoju, aby wobkśuśenje e-mejloweje adresy anulował: 

$5

Toś ten wobkšuśeński kod płaśi do $4.',
'confirmemail_invalidated' => 'Emailowe wobkšuśenje pśetergnjone',
'invalidateemail'          => 'Emailowe wobkšuśenje pśetergnuś',

# Scary transclusion
'scarytranscludedisabled' => '[Pśidawanje interwiki jo deaktiwěrowane]',
'scarytranscludefailed'   => '[Zapśěgnjenje pśedłogi za $1 njejo se raźiło]',
'scarytranscludetoolong'  => '[URL jo pśedłujki]',

# Trackbacks
'trackbackbox'      => '<div id="mw_trackbacks">
Trackbacki za toś ten bok:<br />
$1
</div>',
'trackbackremove'   => '([$1 wulašowaś])',
'trackbacklink'     => 'Trackback',
'trackbackdeleteok' => 'Trackback jo wuspěšnje wulašowany.',

# Delete conflict
'deletedwhileediting' => "'''Warnowanje''': Toś ten bok se wulašujo, gaž zachopijoš jen wobźěłaś!",
'confirmrecreate'     => "Wužywaŕ [[User:$1|$1]] ([[User talk:$1|diskusija]]) jo bok wulašował, nježli až sy zachopił jen wobźěłaś, pśicyna:
: ''$2''
Pšosym wobkšuśiś, až napšawdu coš ten bok zasej wutwóriś.",
'recreate'            => 'Wótnowótki wutwóriś',

# action=purge
'confirm_purge_button' => 'W pórědku.',
'confirm-purge-top'    => 'Wulašowaś cache togo boka?',
'confirm-purge-bottom' => 'Wuproznijo cache a wunuzijo zwobraznjenje aktualneje wersije.',

# Multipage image navigation
'imgmultipageprev' => '← slědny bok',
'imgmultipagenext' => 'pśiducy bok →',
'imgmultigo'       => 'W pórědku',
'imgmultigoto'     => 'Źi k bokoju $1',

# Table pager
'ascending_abbrev'         => 'górjej',
'descending_abbrev'        => 'dołoj',
'table_pager_next'         => 'Pśiducy bok',
'table_pager_prev'         => 'Pjerwjejšny bok',
'table_pager_first'        => 'Prědny bok',
'table_pager_last'         => 'Slědny bok',
'table_pager_limit'        => 'Pokazaś {{PLURAL:$1|$1 objekt|$1 objekta|$1 objekty}} na bok',
'table_pager_limit_submit' => 'Start',
'table_pager_empty'        => 'Žedne wuslědki',

# Auto-summaries
'autosumm-blank'   => 'Bok jo se wuproznił',
'autosumm-replace' => "Bok narownajo se z: '$1'",
'autoredircomment' => 'Pśesměrowanje na [[$1]]',
'autosumm-new'     => "Jo napórał bok z '$1'",

# Live preview
'livepreview-loading' => 'Lodowanje …',
'livepreview-ready'   => 'Lodowanje … gótowe!',
'livepreview-failed'  => 'Live-pśeglěd njejo móžny. Pšosym normalny pśeglěd wužywaś.',
'livepreview-error'   => 'Kontaktowanje njejo se zglucyło: $1 "$2". Pšosym normalny pśeglěd wužywaś.',

# Friendlier slave lag warnings
'lag-warn-normal' => 'Změny {{PLURAL:$1|slědneje $1 sekundy|slědneju $1 sekundowu|slědnych $1 sekundow|slědnych $1 sekundow}} njepókazuju se w toś tej lisćinje.',
'lag-warn-high'   => 'Dla wusokego wuśěženja serwera datoweje banki jo móžno, až pśinoski, kótarež su nowše ako {{PLURAL:$1|$1 sekunda|sekunźe|sekundy|sekundow}} se snaź na toś tej liśćinje njepokazuju.',

# Watchlist editor
'watchlistedit-numitems'       => 'Twóje wobglědowańka wopśimjeju {{PLURAL:$1|$1 zapisk|$1 zapiska|$1 zapiski}}, bźez diskusijnych bokow.',
'watchlistedit-noitems'        => 'Twóje wobglědowańka su prozne.',
'watchlistedit-normal-title'   => 'Zapise wobźěłaś',
'watchlistedit-normal-legend'  => 'Zapiski z wobglědowańkow wulašowaś',
'watchlistedit-normal-explain' => 'To su zapise w twójich wobglědowańkach. Coš-lic zapise wulašowaś, markěruj kašćik pódla zapisow a tłoc na "zapise wulašowaś". Móžoš swóje wobglědowańka teke w [[Special:Watchlist/raw|lisćinowem formaśe]] wobźěłaś.',
'watchlistedit-normal-submit'  => 'Zapise wulašowaś',
'watchlistedit-normal-done'    => '{{PLURAL:$1 zapis jo|$1 zapisa stej|$1 zapise su}} z twójich wobglědowańkow se {{PLURAL:wulašował|wulašowałej|wulašowali}}.',
'watchlistedit-raw-title'      => 'Same wobglědowańka wobźěłaś',
'watchlistedit-raw-legend'     => 'Same wobglědowańka wobźěłaś',
'watchlistedit-raw-explain'    => 'Zapise, kótarež namakaju se w twójich wobglědowańkach pokazuju se dołojce. Wóni mógu se wobźěłaś pśez to, až do lisćiny se dodawaju resp. z njeje se wulašuju (stawnje jaden zapis na smužku). Gaž sy gótowy, tłoc "Lisćinu aktualizěrowaś".

Móžoš teke [[Special:Watchlist/edit|standardny editor wužywaś]].',
'watchlistedit-raw-titles'     => 'Zapise:',
'watchlistedit-raw-submit'     => 'Lisćinu aktualizěrowaś',
'watchlistedit-raw-done'       => 'Twóje wobglědowańka su se zaktualizěrowali.',
'watchlistedit-raw-added'      => '{{PLURAL:$1|1 zapis jo se dodał|$1 zapisa stej se dodałej|$1 zapise su se dodali}}:',
'watchlistedit-raw-removed'    => '{{PLURAL:$1|1 zapis jo se wulašował|$1 zapisa stej se wulašowałej|$1 zapise su se wulašowali}}:',

# Watchlist editing tools
'watchlisttools-view' => 'Změny wobglědaś',
'watchlisttools-edit' => 'Woblědowańka pokazaś a wobźěłaś',
'watchlisttools-raw'  => 'Wobglědowańka wobźěłaś',

# Iranian month names
'iranian-calendar-m1'  => 'Farwardin',
'iranian-calendar-m2'  => 'Ordibehešt',
'iranian-calendar-m3'  => 'Chordad',
'iranian-calendar-m4'  => 'Tir',
'iranian-calendar-m5'  => 'Mordad',
'iranian-calendar-m6'  => 'Šahriwar',
'iranian-calendar-m7'  => 'Mehr',
'iranian-calendar-m8'  => 'Aban',
'iranian-calendar-m9'  => 'Azar',
'iranian-calendar-m10' => 'Dej',
'iranian-calendar-m11' => 'Bahman',
'iranian-calendar-m12' => 'Esfand',

# Core parser functions
'unknown_extension_tag' => 'Njeznaty tag rozšyrjenja „$1“',
'duplicate-defaultsort' => 'Glědaj: Standardny sortěrowański kluc (DEFAULT SORT KEY) "$2" pśepišo pjerwjej wužyty kluc "$1".',

# Special:Version
'version'                          => 'Wersija', # Not used as normal message but as header for the special page itself
'version-extensions'               => 'Instalowane rozšyrjenja',
'version-specialpages'             => 'Specialne boki',
'version-parserhooks'              => 'Parserowe kokule',
'version-variables'                => 'Wariable',
'version-other'                    => 'Druge',
'version-mediahandlers'            => 'Pśeźěłaki medijow',
'version-hooks'                    => 'Kokule',
'version-extension-functions'      => 'Funkcije rozšyrjenjow',
'version-parser-extensiontags'     => 'Tagi parserowych rozšyrjenjow',
'version-parser-function-hooks'    => 'Parserowe funkcije',
'version-skin-extension-functions' => 'Funkcije za rozšyrjenja šatow',
'version-hook-name'                => 'Mě kokule',
'version-hook-subscribedby'        => 'Aboněrowany wót',
'version-version'                  => 'Wersija',
'version-license'                  => 'Licenca',
'version-software'                 => 'Instalěrowana software',
'version-software-product'         => 'Produkt',
'version-software-version'         => 'Wersija',

# Special:FilePath
'filepath'         => 'Datajowa droga',
'filepath-page'    => 'Dataja:',
'filepath-submit'  => 'Droga',
'filepath-summary' => 'Toś ten specialny bok wróśa dopołnu drogu za dataju. Wobraze se w połnym wótgranicowanju pokazuju, druge datajowe typy se ze zwězanym programom direktnje startuju.

Zapódaj datajowe mě bźez dodanka "{{ns:file}}:".',

# Special:FileDuplicateSearch
'fileduplicatesearch'          => 'Za duplikatnymi datajami pytaś',
'fileduplicatesearch-summary'  => 'Za datajowymi duplikatami na zakłaźe gótnoty hash pytaś.

Zapódaj datajowe mě bźez prefiksa "{{ns:file}}:".',
'fileduplicatesearch-legend'   => 'pytaś duplikata',
'fileduplicatesearch-filename' => 'Datajowe mě:',
'fileduplicatesearch-submit'   => 'Pytaś',
'fileduplicatesearch-info'     => '$1 × $2 Piksel<br />wjelikosć dataja: $3<br />typ MIME: $4',
'fileduplicatesearch-result-1' => 'Dataja "$1" njama identiske duplikaty.',
'fileduplicatesearch-result-n' => 'Dataja "$1" ma {{PLURAL:$2|1 identiski duplikat|$2 identiskej duplikata|$2 identiske duplikaty|$2 identiskich duplikatow}}.',

# Special:SpecialPages
'specialpages'                   => 'Specialne boki',
'specialpages-note'              => '----
* Normalne specialne boki
* <strong class="mw-specialpagerestricted">Specialne boki z wobgranicowanym pśistupom</strong>',
'specialpages-group-maintenance' => 'Wótwardowańske lisćiny',
'specialpages-group-other'       => 'Druge specialne boki',
'specialpages-group-login'       => 'Pśizjawjenje',
'specialpages-group-changes'     => 'Slědne změny a protokole',
'specialpages-group-media'       => 'Medije',
'specialpages-group-users'       => 'Wužywarje a pšawa',
'specialpages-group-highuse'     => 'Cesto wužywane boki',
'specialpages-group-pages'       => 'Lisćiny bokow',
'specialpages-group-pagetools'   => 'Rědy bokow',
'specialpages-group-wiki'        => 'Wikijowe daty a rědy',
'specialpages-group-redirects'   => 'Dalej pósrědnjajuce boki',
'specialpages-group-spam'        => 'Spamowe rědy',

# Special:BlankPage
'blankpage'              => 'Prozny bok',
'intentionallyblankpage' => 'Toś ten bok jo z wótglědom prozny.',

# External image whitelist
'external_image_whitelist' => ' #Wóstaj toś tu smužku rowno tak jo<pre>
#Zapódaj fragmenty regularnych wurazow (jano źěl mjazy //) dołojce
#Toś te budu se pśirunowaś z URL ekseternych wobrazow
#Te, kótarež makaju se, zwobraznuju se ako wobraze, howac pokažo se jano wótkaz k wobrazoju
#Ze smužkami, kótarež zachopiju se z #, wobchadaju ako z komentarami
#To njeźiwa na wjelikopisanje

#Staj wše fragmenty regularnych wurazow nad smužku. Wóstaj toś tu smužku rowno tak jo</pre>',

);

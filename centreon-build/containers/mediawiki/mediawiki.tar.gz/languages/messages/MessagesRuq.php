<?php
/** Megleno-Romanian (Vlăheşte)
 *
 * @ingroup Language
 * @file
 * @comment falls back to Megleno-Romanian (Latin)
 *
 */

$fallback = 'ruq-latn';

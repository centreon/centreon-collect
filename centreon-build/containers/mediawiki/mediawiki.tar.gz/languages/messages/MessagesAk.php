<?php
/** Akan (Akan)
 *
 * See MessagesQqq.php for message documentation incl. usage of parameters
 * To improve a translation please visit http://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Natsubee
 * @author Paa.kwesi
 */

$messages = array(
# User preference toggles
'tog-underline' => 'Twa lenk nyina ase:',

# Dates
'sunday'    => 'Kwasiada',
'monday'    => 'Ɛdwoada',
'tuesday'   => 'Ɛbenada',
'wednesday' => 'Wukuada',
'thursday'  => 'Yawoada',
'friday'    => 'Efiada',
'saturday'  => 'Memeneda',
'january'   => 'Ɔpɛpɔn',
'february'  => 'Ɔgyefuo',
'march'     => 'Ɔbenem',
'april'     => 'Oforisuo',
'may_long'  => 'Kɔtonimma',
'june'      => 'Ayɛwohomumu',
'july'      => 'Kutawonsa',
'august'    => 'Ɔsannaa',
'september' => 'Ɛbɔ',
'october'   => 'Ahinime',
'november'  => 'Obubuo',
'december'  => 'Ɔpenimma',

'search'           => 'Hwehwɛ',
'searchbutton'     => 'Hwehwɛ',
'go'               => 'Kɔ',
'searcharticle'    => 'Kɔ',
'history_short'    => 'Beeme',
'talkpagelinktext' => 'Kasa',
'talk'             => 'Kasa',
'jumptosearch'     => 'hwehwɛ',

# Search results
'powersearch' => 'Hwehwɛ',

# Preferences page
'searchresultshead' => 'Hwehwɛ',

# Recent changes
'hist' => 'beeme',

# Watchlist
'watch' => 'Hwɛ',

);
